document.addEventListener("DOMContentLoaded", () => {
  const saveButton = document.getElementById("save");

  // manifest.json に書いた固定URL（matches と同じにする）
  const targetUrl = "https://opraws-prod.e-koukuuken.com/s/appli/application/search/?search%5Bshortcut%5D=&search%5Bdate%5D=none&search%5B%40date_from%5D%5BDate_Year%5D=2023&search%5B%40date_from%5D%5BDate_Month%5D=10&search%5B%40date_from%5D%5BDate_Day%5D=23&search%5B%40date_to%5D%5BDate_Year%5D=2023&search%5B%40date_to%5D%5BDate_Month%5D=10&search%5B%40date_to%5D%5BDate_Day%5D=23&search%5Bstatus%5D%5B1%5D=1&search%5Bcondition_connect%5D=or&search%5Bconditions%5D%5B0%5D%5Bitem%5D=%E5%BE%80%E8%B7%AF%E4%BE%BF&search%5Bconditions%5D%5B0%5D%5Bvalue%5D=SKY&search%5Bconditions%5D%5B0%5D%5Bexpression%5D=%E3%81%A7%E5%A7%8B%E3%81%BE%E3%82%8B&search%5Bconditions%5D%5B1%5D%5Bitem%5D=%E5%BE%A9%E8%B7%AF%E4%BE%BF&search%5Bconditions%5D%5B1%5D%5Bvalue%5D=SKY&search%5Bconditions%5D%5B1%5D%5Bexpression%5D=%E3%81%A7%E5%A7%8B%E3%81%BE%E3%82%8B&search%5Bsort%5D=reservation_date&search%5Bservice_type%5D=ALL";

  // 保存済み設定復元
  chrome.storage.local.get({ excludeWords: [] }, (data) => {
    data.excludeWords.forEach(word => {
      const checkbox = document.querySelector(`input[value="${word}"]`);
      if (checkbox) checkbox.checked = true;
    });
  });

  saveButton.addEventListener("click", () => {
    const checked = Array.from(document.querySelectorAll("input[type=checkbox]:checked"))
      .map(cb => cb.value);

    chrome.storage.local.set({ excludeWords: checked }, () => {
      console.log("除外条件保存しました:", checked);
    });
    
    // ✅ 新しいタブで固定URLを開く
    chrome.tabs.create({ url: targetUrl });
  });
});
