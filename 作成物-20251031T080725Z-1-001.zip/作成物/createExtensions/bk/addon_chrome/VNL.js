/*
 * VNL airport
 * Check auto submit
 * Check operator edit after auto fill
 * Check affection to other pages in same domain
 * Clear all value after set in form(click button)
 * */

function loginVNL() {
	$('#agencyCode').val(GLB_AGENCY_CODE_VNL);
	$('#agencyId').val(GLB_USER_ID_VNL);
	
    chrome.storage.sync.get('vnl_pwd', function(result){
		var vnl_pwd = GLB_PASSWORD_VNL;
		if (result.vnl_pwd) vnl_pwd = result.vnl_pwd;
		//alert(vnl_pwd);
		$('#password').val(vnl_pwd);
		$("form [type='Submit'][class='buttonLL3 button3']").trigger('click');
    });
}


function searchFromAppliVNL() {
	getItem("VNLMode","VNLMode","setVNLMode");
}

function copyFromAppliVNL($arrAdult, $arrChild) {
		// $divPc = $('#passenger-contact');
        adultCount = 0;
        childCount = 0;
        infantCount = 0;
        //console.log($arrAdult);
        //console.log($arrChild);
        //console.log($arrAdult[0]);
        //console.log($arrChild[0]);
        // 9 adult + child, 6 infant    
        for (p=1;p<=15;p++) {
                //幼児 (2歳未満)
            if (infantCount <= 1) {
                //名前
                getItem('application_infant_list_' + infantCount.toString() + '_last_name_rome','infantLastNames_' + infantCount.toString());
               	getItem('application_infant_list_' + infantCount.toString() + '_first_name_rome','infantFirstNames_' + infantCount.toString());
                
                //性別
               	getItem('inf_sex' + infantCount.toString(),'infantSex_' + infantCount.toString());
                //生年月日
                indexDate = infantCount + 1;
               	getItem('application_infant_list_' + infantCount.toString() + '_birthday', 
               			    'yearSimple_inft_' + indexDate.toString() + '|' + 'monthSimple_inft_' + indexDate.toString() + 
               			    '|' + 'daySimple_inft_' + indexDate.toString()  + '|' + 'compSimpleHid_inft_' + indexDate.toString(), 'YMD_VNL');
                ++infantCount;
         } else {
         		//子供
                index = $arrChild[childCount];
                if (index > -1) {
                    //名前
	                getItem('application_traveller_list_' + index.toString() + '_last_name_rome','childLastNames_' + childCount.toString());
	               	getItem('application_traveller_list_' + index.toString() + '_first_name_rome','childFirstNames_' + childCount.toString());
	                
	                //性別
	               	getItem('sex' + index.toString(),'childGender_' + childCount.toString());
	                //生年月日
	                indexDate = childCount + 1;
	               	getItem('application_traveller_list_' + index.toString() + '_birthday', 
	               			    'yearSimple_chld_' + indexDate.toString() + '|' + 'monthSimple_chld_' + indexDate.toString() + 
	               			    '|' + 'daySimple_chld_' + indexDate.toString()  + '|' + 'compSimpleHid_chld_' + indexDate.toString(), 'YMD_VNL');
	                ++childCount;
				}  else {
                    //大人
	                index = $arrAdult[adultCount];
					if (index > -1) {
		  					//名前
		                getItem('application_traveller_list_' + index.toString() + '_last_name_rome','adultLastNames_' + adultCount.toString());
		               	getItem('application_traveller_list_' + index.toString() + '_first_name_rome','adultFirstNames_' + adultCount.toString());
		                
		                //性別
		               	getItem('sex' + index.toString(),'adultGender_' + adultCount.toString());
		                //生年月日
		                indexDate = adultCount + 1;
		               	getItem('application_traveller_list_' + index.toString() + '_birthday', 
		               			    'yearSimple_adlt_' + indexDate.toString() + '|' + 'monthSimple_adlt_' + indexDate.toString() + 
		               			    '|' + 'daySimple_adlt_' + indexDate.toString()  + '|' + 'compSimpleHid_adlt_' + indexDate.toString(), 'YMD_VNL');
		                ++adultCount;
					}                	
				}
				
				//getItem('application_traveller_list_0_first_name','title','fullnamevnl');
				
			}
        }
        // zipcode
        //getItem('application_zip_code','postalCode');
        getItem('application_zip_code','postalCode','name');
		getItem('application_tel1','phoneNumber','name');
        cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
		firstname = '';
		lastname = '';
		setTimeout(function() {
			xdLocalStorage.getItem(cms_app_id + "_application_traveller_list_0_first_name_rome", function(data) {
				console.log(data.value);
				if (!!data.value) {
					firstname = data.value;
					
					xdLocalStorage.getItem(cms_app_id + "_application_traveller_list_0_last_name_rome", function(data) {
						console.log(data.value);
						if (!!data.value) {
							firstname += " " + data.value;
							xdLocalStorage.getItem(cms_app_id + "_application_traveller_list_0_sex", function(data) {
								console.log(data.value);
								if (!!data.value) {
									if(data.value == 1){
										title = "Mr " + firstname;
									} else {
										title = "Ms " + firstname;
									}
									$("#title").val(title);
								}
							});
						}
					});
				}
			});
		}, 1000);
             
}


function copyFromAppli2VNL() {
		//$('#idOnHold').trigger('click');
		$('#acceptTermsAndConditions').attr('checked', true);
}

// copy to application for VNL 
function copyToAppliVNL() {
	seat = '';
	reserveNo = $(".txt_alnctr").find('.lbl_bld').first().text();
	curTable = $('#travelInfoDiv').find('table .wth_100.margin_10_top_minus').first();
	flightInfo = getCellValueInTable(curTable, 3, 1);
	flightNo = $.trim(flightInfo.replace("JW",""));
	// get dep info
	depAirport = $($('#travelInfoDiv').find('table .wth_100.margin_10_top_minus').first().find('.wth_40')[2]).find('label').first().text();
	depAirport = depAirport.replace(')','').replace('(','').split(' ');
	depAirport = depAirport[0].replace(' ','');
	depDate = $($($('#travelInfoDiv').find('table .wth_100.margin_10_top_minus').first().find('.wth_40')[2]).find('label')[1]).text();
	flightDate = $.trim($.trim(depDate).split(' ')[0]);
	flightDateJP = flightDate.toString().replace('/', "年").replace('/', "月");
	flightDateJP += '日';
	depDate = depDate.match(/([0-9]{2}:[0-9]{2})/);
	depTime = depDate[1].replace(':','/');
	//
	arrAirport = $($('#travelInfoDiv').find('table .wth_100.margin_10_top_minus').first().find('.wth_40')[3]).find('label').first().text();
	arrAirport = arrAirport.replace(')','').replace('(','').split(' ');
	arrAirport = arrAirport[0].replace(' ','');
	arrDate = $($($('#travelInfoDiv').find('table .wth_100.margin_10_top_minus').first().find('.wth_40')[3]).find('label')[1]).text();
	flightArrDate = $.trim($.trim(arrDate).split(' ')[0]);

	arrDate = arrDate.match(/([0-9]{2}:[0-9]{2})/);
	arrTime = arrDate[1].replace(':','/');
	dtmLimitDate = new Date();
	
	dtmLimitDate.setDate(dtmLimitDate.getDate() + 1);
	dtmLimitDate = formatDate(dtmLimitDate);
	ticketType = $.trim($("#travelInfoDiv").find('.lbl_bld').first().text().split('-')[1]);
	// parsing  
	strValue = "";
	strValue += flightDate;
	strValue += "/" + "VNL" + "/" + flightNo;
	strValue += "/" + fixJJPAirportName(depAirport);
	strValue += "/" + fixJJPAirportName(arrAirport);
	strValue += "/" + depTime;
	strValue += "/" + arrTime;
	strValue += "/" + reserveNo;
	strValue += "/" + dtmLimitDate;
	strValue += "/" + seat;
	strValue += "/" + ticketType;

	//2015年05月20日/VNL/915/札幌(千歳)/東京(羽田)
	strText = "";
	strText += flightDateJP;
	strText += "/" + "VNL" + "/" + flightNo;
	strText += "/" + fixJJPAirportName(depAirport);
	strText += "/" + fixJJPAirportName(arrAirport);
	line_no = sessionStorage.getItem('line_no');
	carrier = sessionStorage.getItem('carrier');
	data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
	console.log(data_callback);
	cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));

	setTimeout(function(){
		setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
	}, CMS_TIMEOUT_INMILISECONDS);
}


$( document ).ready(function() {
	 
var domain_name = document.domain;
	 loc = window.location;
 	 if(domain_name=="www.vanilla-air.com") {
		 if(loc.toString().indexOf('reservation/ibe/ibe/login') != -1 && $('body').text().toString().indexOf('ようこそ!') != -1) {
			loginVNL();
 		} else if ($('body').text().toString().indexOf("管理画面") > -1)	{
 			confirm_flag = sessionStorage.getItem('confirm_flag');
 			if(confirm_flag =="confirm"){
 				//予約内容の確認/変更
 				//$($('.wth_60.float.mar_left_5 a')[0]).trigger('click');
 				//$($('.wth_60.float.mar_left_5 a')[0]).trigger('click');
 				//$($('.wth_60.float.mar_left_5 a')[0]).trigger('onclick');
 				//$($('.wth_60.float.mar_left_5 a')[0]).trigger('click');
 				// alert($('.wth_60.float.mar_left_5 a').get(0));
 				$('.wth_60.float.mar_left_5 a').get(0).click();
 			} else {
				setTimeout(function(){
   	    			searchFromAppliVNL();
   	       		}, CMS_TIMEOUT_INMILISECONDS);
			}
		} else if ($('body').text().toString().indexOf("予約内容の確認/変更") > -1 && $('body').text().toString().indexOf("ご予約番号") > -1)	{
 			confirm_flag = sessionStorage.getItem('confirm_flag');
 			if(confirm_flag =="confirm"){
 				line_no = $.trim(sessionStorage.getItem('line_no'));
    	    	cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
    	    	setTimeout(function(){
    	    		getItem('application_ticket_reservation_no' + line_no,"confirmationCode", 'name');
    	    		getItem('application_flight_date_full' + line_no,"wth_90.dateTextbox", 'VNLconfirmdate');
    	    		$('#retrieveEmailAddress').val('vnl@evolableasia.com');
    	    		//$($('.wth_90.dateTextbox').get(0)).val('2018/04/27');
					clearAll(cms_app_id, line_no);
    	    	}, CMS_TIMEOUT_INMILISECONDS);
    	    	console.log('setVNLConfirmation done');
 			}
 		} else if ($('body').text().toString().indexOf("ご搭乗者名は必ず身分証(パスポート)と同じ表記(ヘボン式)でお願いいたします。") > -1) {
			//手配システム予約入力画面が開いていれば顧客情報コピー
		   setTimeout(function(){
		   		getItem('application_traveller_list_adult_child_index',"copyFromApplicationVNL", 'copyFromApplicationVNL');
   	       }, CMS_TIMEOUT_INMILISECONDS);					
		} else if ($('body').text().toString().indexOf("お支払いタイプを選択してください") > -1)	{
		   setTimeout(function(){
   	    		copyFromAppli2VNL();
   	       }, CMS_TIMEOUT_INMILISECONDS);
		} else if ($('body').text().toString().indexOf("ご搭乗手続きの際にご予約番号が必要となります。この旅程表を印刷してお持ちいただくことをお勧めいたします。") > -1) {
			setTimeout(function(){
   	    		copyToAppliVNL();
   	       }, CMS_TIMEOUT_INMILISECONDS);				
		} 
 	}	
});