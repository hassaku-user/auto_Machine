function setFlightInformationFda() {
	var strLimitDate = '',
		strLimitDate2 = '',
		data_callback = '',
		strLimitDate = $('.reservation-date').html(),
		// get dtmLimitDate
		dtmLimitDate = getLimitDateFda();
	// get flight information
	var curTable = $('.table-vaT').eq(0);
	if (typeof curTable != 'undefined') {
		var strValue = "",
		strText = "",
		reservationNo = $('.reservation-number').html(),
		tdList = $(curTable).find('tbody > tr:first > td');

		if (tdList.length > 0) {
			var dtmFlightDate = fixAnaDate($(tdList).eq(1).html());
			// 1799 is min value
			if (dtmFlightDate.getFullYear() != DATE_MIN_VAL) {
				var strLimitDate2 = '';
				if (strLimitDate != '搭乗日当日') {
					strLimitDate2 = formatDate(dtmLimitDate);
				} else {
					var dtmLimitDate2 = new Date(dtmFlightDate.getFullYear(), dtmFlightDate.getMonth(), dtmFlightDate.getDate());
					dtmLimitDate2.setDate(dtmLimitDate2.getDate() - 1);
					strLimitDate2 = formatDate(dtmLimitDate2);
				}
				//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				var tdFlightInfoDept = $(tdList).eq(2);
				var vntDepartureTime = $.trim($(tdFlightInfoDept).find('.time').html()).toString();
				vntDepartureTime = vntDepartureTime.replace(":", "/");

				var tdFlightInfoDest = $(tdList).eq(4);
				var vntArrivalTime = $.trim($(tdFlightInfoDest).find('.time').html()).toString();
				vntArrivalTime = vntArrivalTime.toString().replace(":", "/");

				var strSeat = "普通";
				strValue += formatDate(dtmFlightDate);
				var airLine = $.trim($(tdFlightInfoDept).find('.code').html());

				strValue += "/" + fixAnaAirline(airLine);
				strValue += "/" + fixAnaFlightNo(airLine);
				strValue += "/" + fixJalAirportName($.trim($(tdFlightInfoDept).find('.airport').html()));
				strValue += "/" + fixJalAirportName($.trim($(tdFlightInfoDest).find('.airport').html()));
				strValue += "/" + vntDepartureTime;
				//strValue += "/" + getMinuteString(vntDepartureTime);
				//strValue += "/" + pad(vntArrivalTime[0],2);
				strValue += "/" + vntArrivalTime;
				strValue += "/" + reservationNo;
				strValue += "/" + strLimitDate2;
				strValue += "/" + strSeat;

				var fare = $.trim($(tdList).eq(6).find('.summary span').html());
				fare = fare.toString().replace(/\.|\,|円/gi, "");

				strValue += "/" + fare;
				strText = "";

				strText +=  formatDate(dtmFlightDate);
				strText += "/" + fixAnaAirline(airLine);
				strText += "/" + fixAnaFlightNo(airLine);
				strText += "/" + fixJalAirportName($.trim($(tdFlightInfoDept).find('.airport').html()));
				strText += "/" + fixJalAirportName($.trim($(tdFlightInfoDest).find('.airport').html()));

				var fareDetailTr = $(tdList).eq(6).find('.detail table tbody tr');
				var fareAdult = 0,
					fareChild = 0;

				for (var i= 0; i < fareDetailTr.length; i++) {
					var tds = $(fareDetailTr[i]).find('td');
					if ($.trim($(tds[1]).html()).indexOf('大人') > -1) {
						fareAdult = $.trim($(tds[2]).html()).toString().replace(/\.|\,|円/gi, "");
					} else if ($.trim($(tds[1]).html()).indexOf('小児') > -1) {
						fareChild = $.trim($(tds[2]).html()).toString().replace(/\.|\,|円/gi, "");
					}
				}

				strValue += '/' + fareAdult + '/' + fareChild;
			}
		}


		
		var line_no = sessionStorage.getItem('line_no');
		var carrier = sessionStorage.getItem('carrier');
		
		data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
		console.log('setFlightInformationFda:');
		console.log(data_callback);
	}
	cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
	line_no = $.trim(sessionStorage.getItem('line_no'));
	setTimeout(function(){
		setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
	}, CMS_TIMEOUT_INMILISECONDS);
}

function setTravellerFDA(arrAdult, arrChild){
	adultCount = 0;
	childCount = 0;
	for (p=0;p<=8;p++) {
		index = arrAdult[adultCount];
		if(index > -1){
			getItem('application_traveller_list_' + index.toString() + '_last_name',"passengerInfoAdult[" + adultCount + "].kanaSurName","name");
			getItem('application_traveller_list_' + index.toString() + '_first_name',"passengerInfoAdult[" + adultCount + "].kanaGivenName","name");
			getItem('application_traveller_list_' + index.toString() + '_age',"passengerInfoAdult[" + adultCount + "].age","name");
			getItem('application_traveller_list_' + index.toString() + '_sex',"passengerInfoAdult[" + adultCount + "].gender","radioFDA");
			adultCount++;
		}else{
			index = arrChild[childCount];
			if(index > -1){
				getItem('application_traveller_list_' + index.toString() + '_last_name',"passengerInfoChild[" + childCount + "].kanaSurName","name");
				getItem('application_traveller_list_' + index.toString() + '_first_name',"passengerInfoChild[" + childCount + "].kanaGivenName","name");
				getItem('application_traveller_list_' + index.toString() + '_birthday',"passengerInfoChild[" + childCount + "].dateOfBirth","name");
				getItem('application_traveller_list_' + index.toString() + '_sex',"passengerInfoChild[" + childCount + "].gender","radioFDA");
				childCount++;
			}
		}
	}
}

$( document ).ready(function() {
	var domain_name = document.domain;
	var loc = window.location;
	
	if(domain_name=="www.fujidreamairlines.com"){
		//FDA input
		if(loc.toString().indexOf('bkt/app/RES/reservation/FRIG450DSP.do') != -1 || loc.toString().indexOf('bkt/app/RES/reservation/FRIG452DSP.do') != -1) {
			setTimeout(function(){
				getItem("application_tel1","phoneNo","name");
				getItem("reserve_email","pcMail_local","");
				//getItem("reserve_email","pcMail_domain","mailFDAdomain");
				getItem("reserve_email","pcMail_local_retype","");
				//getItem("reserve_email","pcMail_domain_retype","mailFDAdomain");
				getItem('application_traveller_list_adult_child_index',"listTravellerFDA", 'listTravellerFDA');
				// for(i= 0; i < 6; i++){
					// getItem('application_traveller_list_' + i.toString() + '_last_name',"passengerInfoAdult[" + i + "].kanaSurName","name");
					// getItem('application_traveller_list_' + i.toString() + '_first_name',"passengerInfoAdult[" + i + "].kanaGivenName","name");
					// getItem('application_traveller_list_' + i.toString() + '_age',"passengerInfoAdult[" + i + "].age","name");
					// getItem('application_traveller_list_' + i.toString() + '_sex',"passengerInfoAdult[" + i + "].gender","radioFDA");
				// }
				haveInfant = $('[name="passengerInfoInfant[0].kanaSurName"]');
				if(typeof(haveInfant) != 'undefined'){
					for(i= 0; i < 2; i++){
						getItem('application_infant_list_' + i.toString() + '_last_name',"passengerInfoInfant[" + i + "].kanaSurName","name");
						getItem('application_infant_list_' + i.toString() + '_first_name',"passengerInfoInfant[" + i + "].kanaGivenName","name");
						getItem('application_infant_list_' + i.toString() + '_sex',"passengerInfoInfant[" + i + "].gender","radioFDA");
						getItem('guardian_no_' + i.toString(),"passengerInfoInfant[" + i + "].guardianNo","selectFDA");
						getItem('application_infant_list_' + i.toString() + '_birthday',"passengerInfoInfant[" + i + "].dateOfBirth","name");
					}
				}
				getItem('application_tel1',"id", 'endConfirmFDA');
			}, CMS_TIMEOUT_INMILISECONDS);
		}else if(loc.toString().indexOf('/bkt/app/RES/reservation/FRIG470DSP.do') != -1){ // booking complete
			setTimeout(function() {
				$('.reservation-detail-button').click();
			} , 1500);

			// setFlightInformationFda();
		}else if(loc.toString().indexOf('/bkt/app/RES/top/FRIG410_06BL.do') != -1){
			setTimeout(function(){
				line_no = $.trim(sessionStorage.getItem('line_no'));
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			},500);
			setTimeout(function(){
				Promise.all([
					new Promise(resolve => getItem('application_flight_year' + line_no, resolve)),
					new Promise(resolve => getItem('application_flight_month' + line_no, resolve)),
					new Promise(resolve => getItem('application_flight_day' + line_no, resolve))
				]).then(ymd => {
					let [y, m, d] = (ymd instanceof Array) ? ymd : [];
					ymd = [
						y.value || '',
						('0' + (m.value || '')).substr(-2),
						('0' + (d.value || '')).substr(-2)
					].join('/');
					$('#dateField,#flightDate').val(ymd);
				}).catch(console && console.warn);
				// getItem('application_flight_month' + line_no,"flightMonth", 'selectFDA');
				// getItem('application_flight_day' + line_no,"flightDay", 'selectDateFDA');
				getItem('application_flight_no' + line_no,"flightNo", 'name');
				getItem('application_ticket_reservation_no' + line_no,"pnrNo", 'name');
				getItem('application_last_name' + line_no,"kanaSurname", 'name');
				getItem('application_first_name' + line_no,"kanaGivenName", 'name');
				//getItem('application_ticket_reservation_no' + line_no,"endConfirmSNA", 'endConfirmSNA');
				clearAll(cms_app_id, line_no);
				setTimeout(function() {
					$("input[name='forward_search']").click();
				} , 1500);
			}, CMS_TIMEOUT_INMILISECONDS);
			console.log('setFDAConfirmation done');
		} else if(loc.toString().indexOf('/bkt/app/RES/reservation/FRIG460DSP.do') != -1){ // complete detail
			setTimeout(function() {
				$('button.border-orange').click();
			} , 1500);
		} else if(loc.toString().indexOf('/bkt/app/RES/reservation/FRIG510DSP.do') != -1){ // confirm complete detail
			setFlightInformationFda();
		} else if(loc.toString().indexOf('/bkt/app/RES/top/FRIG410_13BL.do') != -1){ // confirm flight certification
			setTimeout(function(){
				getItem('application_flight_certification_ymd','calFlightDate','select');
				getItem('application_flight_certification_flight_no','flightNo','select');
				getItem('application_flight_certification_ticket_reservation_no','pnrNo','select');
				getItem('application_flight_certification_traveller_last_name','kanaSurname','select');
				getItem('application_flight_certification_traveller_first_name','kanaGivenName','select');
			}, CMS_TIMEOUT_INMILISECONDS);
		}
	} else {
	}
});