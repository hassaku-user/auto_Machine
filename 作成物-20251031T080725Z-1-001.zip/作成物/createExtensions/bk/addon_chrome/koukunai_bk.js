// DEFINE VARIABLE PUBLIC >>>

var CMS_DOMAIN = 'air.tabicapital_dev.net';
var STORAGE_URL = 'https://japanflight.tripstar.co.jp/addon_storage/app/views/storage.php'; // should be https
var DATE_MIN_VAL = 1799;
var CMS_DELIMITER = ";";
var CMS_TIMEOUT = '';
var CMS_TIMEOUT_INMILISECONDS = 2000;
var CHROME_STORAGE = chrome.storage.sync;
// DEFINE LOGIN >>>>
var AG_GLB_ACCOUNT_SMART_TICKET = "masuda@tabicapi.com";
var AG_GLB_PASSWORD_SMART_TICKET = "YRDVR8HR";

var EK_GLB_ACCOUNT_SMART_TICKET = "masuda@e-koukuuken.com";
var EK_GLB_PASSWORD_SMART_TICKET = "4Y78M8VP";

var AC_GLB_ACCOUNT_SMART_TICKET = "airinfo@airticket-center.com";
var AC_GLB_PASSWORD_SMART_TICKET = "SZZDFSS8";

var SG_GLB_ACCOUNT_SMART_TICKET = "ticket_al@tabicapi.com";
var SG_GLB_PASSWORD_SMART_TICKET = "D8FE5QXN";
// VNL
var GLB_AGENCY_CODE_VNL = "EVA222";
var GLB_USER_ID_VNL = "EVA001";
var GLB_PASSWORD_VNL = "eva555555";
// <<< DEFINE LOGIN
//@Thuy >> Edit 2016-1-11
var CMS_DOMAIN="";
getDomain();
$( document ).ready(function() {
  // Handler for .ready() called.
  CMS_DOMAIN = $("#domain_cms").html();
  CMS_DOMAIN = (CMS_DOMAIN == '' || typeof(CMS_DOMAIN) == 'undefined' ? 'air.tabicapital_dev.net' :  CMS_DOMAIN);
  console.log('domain cms get from option is: ' + CMS_DOMAIN);
});
//@Thuy << 2016-1-11
// <<< DEFINE VARIABLE PUBLIC
       xdLocalStorage.init(
          {
              iframeUrl: STORAGE_URL,
              initCallback: function () {
                  //console.log('Got iframe ready');
                  xdLocalStorage.setItem('check', 'no callback');
                  //app_id = $('#application_application_id').val();
                  //xdLocalStorage.setItem('app_id', app_id);
              }
          }
        );

		function setFuncTravellerSky(strDataList, id_div) {
			strDataList = strDataList.split(',');
			for (i = 0; i < strDataList.length; i++)
			{
				if (strDataList[i] != '') 
				{
					if (id_div == 'adult') {
						getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name_rome',"aLastName" + i.toString(),"name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name_rome',"aFirstName" + i.toString(),"name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_age',"aAge" + i.toString(),"name");
						getItem('sex' + strDataList[i].toString(),"aSex" + i.toString(),"radio");
					} else if (id_div == 'child_a') {
						getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name_rome',"caLastName" + i.toString(),"name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name_rome',"caFirstName" + i.toString(),"name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_age',"caAge" + i.toString(),"name");
						getItem('sex' + strDataList[i].toString(),"caSex" + i.toString(),"radio");
					} else if (id_div == 'child_b') {
						getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name_rome',"cLastName" + i.toString(),"name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name_rome',"cFirstName" + i.toString(),"name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_age',"cAge" + i.toString(),"name");
						getItem('sex' + strDataList[i].toString(),"cSex" + i.toString(),"radio");
					} else if (id_div == 'infant') {
						getItem('application_infant_list_' + strDataList[i].toString() + '_last_name_rome',"iLastName" + i.toString(),"name");
						getItem('application_infant_list_' + strDataList[i].toString() + '_first_name_rome',"iFirstName" + i.toString(),"name");
						getItem('application_infant_list_' + strDataList[i].toString() + '_age',"iAge" + i.toString(),"name");
						getItem('inf_sex' + strDataList[i].toString(),"iSex" + i.toString(),"radio");
						getItem('inf_pax' + strDataList[i].toString(),"iAttendant" + i.toString(),"select");
					}
				}
			}			
		}
		
		function setFncTravellerHAC(strDataList, id_div) {
			strDataList = strDataList.split(',');
			for (i = 0; i < strDataList.length; i++)
			{
				if (strDataList[i] != '') 
				{
					if (id_div == 'adult') {
						getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name',"passengerInfoAdult[" + i.toString() + "].kanaSurName","name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name',"passengerInfoAdult[" + i.toString() + "].kanaGivenName","name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_age',"passengerInfoAdult[" + i.toString() + "].age","name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_sex',"passengerInfoAdult[" + i.toString() + "].gender","radio");
					} else if (id_div == 'child') {
						getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name',"passengerInfoChild[" + i.toString() + "].kanaSurName","name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name',"passengerInfoChild[" + i.toString() + "].kanaGivenName","name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_birthday',"passengerInfoChild[" + i.toString() + "].dateOfBirth","name");
						getItem('application_traveller_list_' + strDataList[i].toString() + '_sex',"passengerInfoChild[" + i.toString() + "].gender","radio");

						getItem('sex' + strDataList[i].toString(),"cSex" + i.toString(),"radio");
					} else if (id_div == 'infant') {
						getItem('application_infant_list_' + strDataList[i].toString() + '_last_name_rome',"passengerInfoInfant[" + i.toString() + "].romanSurName","name");
						getItem('application_infant_list_' + strDataList[i].toString() + '_first_name_rome',"passengerInfoInfant[" + i.toString() + "].romanGivenName","name");
						getItem('application_infant_list_' + strDataList[i].toString() + '_birthday',"passengerInfoInfant[" + i.toString() + "].dateOfBirth","name");
						getItem('application_infant_list_' + strDataList[i].toString() + '_sex',"passengerInfoInfant[" + i.toString() + "].gender","radio");
						$("[name='passengerInfoInfant["+ i.toString() +"].guardianNo']").val(1);
					}
				}
			}    
		}    	
		
		// ANA新株
		function setFromAppliSmartTicket(strData, id_div) {
			// strData must not null
			switch (id_div) {
				case 'search_from_flight_info1':
				case 'search_from_flight_info2':
					flight_info_s1 = strData.split('_');
					departureYear = parseInt(flight_info_s1[1].toString());
					departureMonth = parseInt(flight_info_s1[2].toString());
					departureDay = parseInt(flight_info_s1[3].toString());
					departureDate =  pad(departureMonth,2) + pad(departureDay,2);
					departureCity = flight_info_s1[7];
					arrivalCity = flight_info_s1[8];
					seatType = flight_info_s1[10];
					$("#going_date").val(departureDate);
					$("[name='going_dep_apo']").val(departureCity);
					$("[name='going_arr_apo']").val(arrivalCity);
					$('input[type="radio"][name="going_seatkind"][value="' + getSeatType(seatType) + '"]').attr('checked',true);
					break;
				case 'search_flight_flight_info1':
			 	case 'search_flight_flight_info2':
			 		flight_info_s1 = strData.split('_');
			 		airlineID = flight_info_s1[0].toString();
					airlineNo = flight_info_s1[11].toString();
					ticketType = flight_info_s1[9].toString();
					
					departureYear = parseInt(flight_info_s1[1].toString());
					departureMonth = parseInt(flight_info_s1[2].toString());
					departureDay = parseInt(flight_info_s1[3].toString());
					departureDate =  pad(departureMonth,2) + pad(departureDay,2);
					departureCity = flight_info_s1[7];
					arrivalCity = flight_info_s1[8];
					seatType = getSeatType(flight_info_s1[10]);
					$(document).load("http://smart-ticket.biz/agent/inquiry/search_list_ajax", 
				    	{type_flg:'return',
				    	 select_air_company:'1',
				    	 select_data:departureDate,
				    	 select_dep_apo:departureCity,
				    	 select_arr_apo:arrivalCity,
						 select_seatkind:seatType}
				     );
					$( document ).ajaxComplete(function() {
					   console.log('start select');	
					   if (id_div == 'search_flight_flight_info1') {
					   		selectFlight(airlineNo, airlineID, ticketType);
					   } else {
					   		selectFlightReturn(airlineNo, airlineID, ticketType);
					   }
					});					
					//$("body #going01 img").on("load", function (){ 
					  //setTimeout(function(){	
					     
					  //}, CMS_TIMEOUT_INMILISECONDS + 10000);
					//});
					//}, CMS_TIMEOUT_INMILISECONDS);
			 		break;
			 	case 'copy_from_flight_info1':
			 	case 'copy_from_flight_info2':
			 		flight_info_s1 = strData.split('_');
			 		adultCount = parseInt(flight_info_s1[4].toString());
					childCount = parseInt(flight_info_s1[5].toString());
					infantCount = parseInt(flight_info_s1[6].toString());
					//console.log(adultCount + childCount);
					//console.log($('[name="linkselect"]'));
					$('[name="linkselect"]').val(adultCount + childCount);
					for (i=1; i<=adultCount + childCount; i++) {
						$('#search' + pad(i,2)).show();
					}
					for (i=0; i<=5; i++) {
				   		getItem('application_traveller_list_' + i.toString() + '_last_name',"rsv_sei_kana"+ pad((i+1).toString(),2), "name");
				   		getItem('application_traveller_list_' + i.toString() + '_first_name',"rsv_mei_kana"+ pad((i+1).toString(),2), "name");
				   		getItem('application_traveller_list_' + i.toString() + '_age',"rsv_age"+ pad((i+1).toString(),2), 'name');
				   		getItem('application_traveller_list_' + i.toString() + '_sex',"rsv_sex"+ pad((i+1).toString(),2), 'radio');
				    }
					//Tel
					getItem('application_tel1',"rsv_tel01", 'name');					
					getItem('application_common_email',"rsv_mail01", 'name'); //TODO
					// getItem('application_tel1',"rsv_tel01", 'endSetSmartTicket');
			 		break;
		   }
		}
		
		
		function setFromAppliVNL(strData, id_div) {
			// strData must not null
			switch (id_div) {
				case 'search_from_flight_info1':
				case 'search_from_flight_info2':
					departureCity = "";
					departureYear = 0;
					departureMonth = 0;
					departureDay = 0;
					adultCount = 0;
					childCount = 0;
					infantCount = 0;
					// $('#owTripId').trigger('click');
					if (id_div == 'search_from_flight_info1') {
						flight_info_s1 = strData.split('_');
						departureCity = flight_info_s1[7];
						arrivalCity = flight_info_s1[8];
						departureYear = parseInt(flight_info_s1[1]);
						departureMonth = parseInt(flight_info_s1[2]);
						departureDay = parseInt(flight_info_s1[3]);
						departureDate = new Date(departureYear, departureMonth-1, departureDay);
						adultCount = parseInt(flight_info_s1[4]);
						childCount = parseInt(flight_info_s1[5]);
						infantCount = parseInt(flight_info_s1[6]);
						$('#aiRESOrigin').val(departureCity);
						$('#aiRESDestination').focus();
						$('#aiRESDestination').val(arrivalCity);
						$("[id='travelDate#trvDate_1'").focus();
						$("[id='travelDate#trvDate_1'").val(formatDate(departureDate));
						$('#trvDate_1').focus();
						$('#trvDate_1').val(departureDay.toString() + "-" + fixVNLMonth(departureMonth) + "-" + departureYear.toString());
						$('#aiRESAdult').focus();
						$('#aiRESAdult').val(adultCount);
						$('#aiRESChild').focus();
						$('#aiRESChild').val(childCount);
						$('#aiRESInfant').focus();
						$('#aiRESInfant').val(infantCount);
						$('#proceed').focus();			
					} else {
						flight_info_s2 = strData.split('_');
						arrivalYear = parseInt(flight_info_s2[1]);
						arrivalMonth = parseInt(flight_info_s2[2]);
						arrivalDay = parseInt(flight_info_s2[3]);
						arrivalDate = new DateTime(arrivalYear, arrivalMonth-1, arrivalDay);
						$("[id='travelDate#aiRESReturnDate'").focus();			
						$("[id='travelDate#aiRESReturnDate'").val(formatDate(arrivalDate));
						$('#aiRESReturnDate').focus();
						$('#aiRESReturnDate').val(arrivalDay.toString() + "-" + fixVNLMonth(arrivalMonth) + "-" + arrivalYear.toString());
						$('#proceed').focus();
					}		
										
					$('#hidCalLyr').hide();					
					break;
				case 'search_from_flight_info_case_2':
						flight_info_s1 = strData.split('_');
						departureCity = flight_info_s1[7];
						arrivalCity = flight_info_s1[8];
						departureYear = parseInt(flight_info_s1[1]);
						departureMonth = parseInt(flight_info_s1[2]);
						departureDay = parseInt(flight_info_s1[3]);
						departureDate = new Date(departureYear, departureMonth -1, departureDay);
						adultCount = parseInt(flight_info_s1[4]);
						childCount = parseInt(flight_info_s1[5]);
						infantCount = parseInt(flight_info_s1[6]);
						$('#owTripId').trigger('click');
						$('#aiRESOrigin').val(departureCity);
						$('#aiRESDestination').focus();
						$('#aiRESDestination').val(arrivalCity);
						$("[id='travelDate#trvDate_1'").focus();
						$("[id='travelDate#trvDate_1'").val(formatDate(departureDate));
						$('#trvDate_1').focus();
						$('#trvDate_1').val(departureDay.toString() + "-" + fixVNLMonth(departureMonth) + "-" + departureYear.toString());
						$('#aiRESAdult').focus();
						$('#aiRESAdult').val(adultCount);
						$('#aiRESChild').focus();
						$('#aiRESChild').val(childCount);
						$('#aiRESInfant').focus();
						$('#aiRESInfant').val(infantCount);
						$('#proceed').focus();
						$('#hidCalLyr').hide();					
					break;
				case 'search_from_flight_info_case_3':
						flight_info_s2 = strData.split('_');
						departureCity = flight_info_s2[7];
						arrivalCity = flight_info_s2[8];
						departureYear = parseInt(flight_info_s2[1]);
						departureMonth = parseInt(flight_info_s2[2]);
						departureDay = parseInt(flight_info_s2[3]);
						departureDate = new Date(departureYear, departureMonth - 1, departureDay);
						adultCount = parseInt(flight_info_s2[4]);
						childCount = parseInt(flight_info_s2[5]);
						infantCount = parseInt(flight_info_s2[6]);
						$('#owTripId').trigger('click');
						$('#aiRESOrigin').val(departureCity);
						$('#aiRESDestination').focus();
						$('#aiRESDestination').val(arrivalCity);
						$("[id='travelDate#trvDate_1'").focus();
						$("[id='travelDate#trvDate_1'").val(formatDate(departureDate));
						$('#trvDate_1').focus();
						$('#trvDate_1').val(departureDay.toString() + "-" + fixVNLMonth(departureMonth) + "-" + departureYear.toString());
						$('#aiRESAdult').focus();
						$('#aiRESAdult').val(adultCount);
						$('#aiRESChild').focus();
						$('#aiRESChild').val(childCount);
						$('#aiRESInfant').focus();
						$('#aiRESInfant').val(infantCount);
						$('#proceed').focus();		
						$('#hidCalLyr').hide();							
					break;					
			 	case 'doneall':
			 		flight_info_s2 = strData.split('_');
			 		airlineID = flight_info_s1[0].toString();
					airlineNo = flight_info_s1[11].toString();
					ticketType = flight_info_s1[9].toString();
					
					departureYear = parseInt(flight_info_s1[1].toString());
					departureMonth = parseInt(flight_info_s1[2].toString());
					departureDay = parseInt(flight_info_s1[3].toString());
					departureDate =  pad(departureMonth,2) + pad(departureDay,2);
					departureCity = flight_info_s1[7];
					arrivalCity = flight_info_s1[8];
					seatType = getSeatType(flight_info_s1[10]);
					
					$(document).load("http://smart-ticket.biz/agent/inquiry/search_list_ajax", 
				    	{type_flg:'return',
				    	 select_air_company:'1',
				    	 select_data:departureDate,
				    	 select_dep_apo:departureCity,
				    	 select_arr_apo:arrivalCity,
						 select_seatkind:seatType}
				     );
					$( document ).ajaxComplete(function() {
					   console.log('start select');	
					   selectFlight(airlineNo, airlineID, ticketType);
					});					
			 		break;
		   }			
		}
		
		 //@Thuy >> Edit 2016-1-11
        function getDomain()
        {
         CHROME_STORAGE.get(function (obj) {
            var domain_cms = obj['CMS_DOMAIN_STORAGE'];
            domain_cms = (domain_cms == '' || typeof(domain_cms) == 'undefined' ? 'air.tabicapital_dev.net' :  domain_cms);
            //console.log('temp:' + domain_cms);
            if ($('#domain_cms').length > 0 ) {
        		$('#domain_cms').text(domain_cms);
    		}else
    		{
    		 $( "body" ).append( "<p id='domain_cms' style='display:none'>"+domain_cms+"</p>" );	
    		// $( "body" ).append( "<input type='hidden' id='appId_cms'  value='" + app_id + "'>");
    		}
            
          });
        }		
		
		function setValue (key,value) {
            if(key) {
                xdLocalStorage.setItem(key, value, function (data) {
                    if(data.success) {
                        //console.log('Your data has been successfully stored.');
                    } else {
                        //console.log('Ops, could not store your data.');
                    }
                });
            } else {
                //console.log('You must enter a key.');
            }
        }

        function getItem (key,id_div, option) {
            if(key) {
				console.log(key);
                xdLocalStorage.getItem(key, function (data) {
					console.log(data.value + "id:" + id_div);
					if (!!data.value) {
					    domain_name = document.domain;
					    // normalize data before input to merchant
						// ANA only >>>
						if(domain_name=="aswbe-d.ana.co.jp" || domain_name=="rsv.starflyer.jp"
							|| domain_name == "resv.solaseedair.jp" || domain_name=="rsv.airdo.jp"
							|| domain_name == "smart-ticket.biz") {
							if (id_div.toString().indexOf('exCode') != -1 || id_div.toString().indexOf('rsv_sex') != -1) {
								if (data.value == '1') {
									data.value = 'M';
								} else if (data.value == '2') {
									data.value = 'F';
								} else {
									data.value = '';
								}
							} else if (id_div.toString().indexOf('paxInfantForm.infFirstName') != -1) {
								nextVal = id_div.replace("paxInfantForm.infFirstName[", "");
								nextVal = parseInt(nextVal.substring(0,1));
								id_nextVal = "paxInfantForm.parentPaxNo[" + nextVal.toString() +"]";
								nextVal += 1;
								$("[name='"+ id_nextVal +"']").val(nextVal);
							}
					 	}
					 	// HAC
					 	if (domain_name.indexOf('hac-air.co.jp')) {
					 		if (id_div.toString().indexOf('gender') != -1) {
						 		if (data.value == '1') {
									data.value = 'MR';
								} else if (data.value == '2') {
									data.value = 'MS';
								} else {
									data.value = '';
								}
							} else if (id_div.toString().indexOf('].age') != -1 || id_div.toString().indexOf('].dateOfBirth') != -1) {
						 		data.value = data.value.toString().replace('-', '').replace('-', ''); 
							}
					 	}
                        // <<< ANA only
                        // @ThuyTQ
                        // APJC only >>>

                         if(domain_name=="book.flypeach.com") {
                            patt = new RegExp(/^hdTitle_[0-9]{1}$/);
                            res = patt.test(id_div);

                            //APJB
                            patt2 = new RegExp(/^txtTitle_[0-9]{1}$/);
                            res2 = patt2.test(id_div);

							if (res || (id_div=="ctl00_stContactTitle") || res2) {
								if (data.value == '1') {
									data.value = 'MR|M';
								} else if (data.value == '2') {
									data.value = 'MS|F';
								} else {
									data.value = '';
								}
							}
                         }

                        // <<< APJC only
						// console.log('got value: "' + data.value + '" for key: "' + data.key + '"');
					 	switch (option) {
							case 'jalendinput':
								$("[alt=入力内容の確認へ進む]").focus();
								break;
					 		case 'name':
					 		    $("[name='"+ id_div +"']").focus();
					 			$("[name='"+ id_div +"']").val(data.value);
					 			break;
							case 'name_jal':
					 		    $("[name='"+ id_div +"']").focus();
					 			$("[name='"+ id_div +"']").val(data.value);
								$("[name='"+ id_div +"']").focusout();
					 			break;
							case 'radio':
						       $('input[type="radio"][name="' + id_div + '"][value="' + data.value + '"]').attr('checked',true);
						       break;
							case 'select':
								$("[name='"+ id_div +"']").val(data.value);
								break;	
							case 'selSexTitleAdult':
							    strTitle = data.value == 1 ? "MR" : "MS";
							    titleSexEleNames = id_div.split('|');
							    $("[name='"+ titleSexEleNames[0] +"']").val(strTitle);
							    $("[name='"+ titleSexEleNames[1] +"']").val(data.value);
							    break;	
							case 'sexJJP2':
								$("[name='"+ id_div +"']").val(data.value); //jjp 2 change design 20170329
								break;
							case 'selSexTitleChild':
							    strTitle = data.value == 1 ? "MSTR" : "MISS";
							    titleSexEleNames = id_div.split('|');
							    $("[name='"+ titleSexEleNames[0] +"']").val(strTitle);
							    $("[name='"+ titleSexEleNames[1] +"']").val(data.value);
							    break;								    
							case 'selTitle':
							    strTitle = data.value == 1 ? "MR" : "MS";
							    $("[name='"+ id_div +"']").val(strTitle);
							    break;

                            /*@ThuyTQ Edit 2016-03-17 >> */
                            case 'inputName':
							    $(id_div).val(data.value);
							    break;

                            case 'BTN_SEX':
                                if(data.value=="MR")
                                {
                                      if($(id_div).is(':checked') === false) {
                                            $(id_div).filter('[value=male]').attr('checked', true);
                                            $(id_div).filter('[value=male]').parent('label').addClass('checked-s focus-s');
                                      }
                                }else
                                {
                                       if($(id_div).is(':checked') === false) {
                                            $(id_div).filter('[value=female]').attr('checked', true);
                                            $(id_div).filter('[value=female]').parent('label').addClass('checked-s focus-s');
                                       }
                                }

                                //$(".h-adr input:radio[name='genderType']").filter('[value=female]').prop('checked', true)
							    break;

                            case 'BTN_SEX_HIDDEN':
                                if(data.value=="MR")
                                {
                                   type_sex = "M";
                                }else
                                {
                                  type_sex = "F";
                                }
							    $(id_div).val(type_sex);
							    break;

                            /*@ThuyTQ Edit 2016-03-17 << */

							case 'YMD':
							    ymdString = data.value;
							    ymdEleNames = id_div.split('|');
							    if (checkYMDFormat(ymdString)) {
							    	arrYmdVal = ymdString.split('-');
									$("[name='"+ ymdEleNames[0] +"']").val(parseInt(arrYmdVal[0]));
									$("[name='"+ ymdEleNames[1] +"']").val(parseInt(arrYmdVal[1]));
									$("[name='"+ ymdEleNames[2] +"']").val(parseInt(arrYmdVal[2]));
							    }
                                //@ThuyTQ Edit 2016-27-01 >>
                                else
                                {
                                    var str = ymdString.replace(/[^\d]/g,'')
                                	var y = str[0]+str[1]+str[2]+str[3];
                                    var m = str[4]+str[5];
                                    var d = str[6]+str[7];
                                    $("[name='"+ ymdEleNames[0] +"']").val(parseInt(y));
									$("[name='"+ ymdEleNames[1] +"']").val(parseInt(m));
									$("[name='"+ ymdEleNames[2] +"']").val(parseInt(d));
                                }
                                //@ThuyTQ Edit 2016-27-01 <<    
								break;
							case 'YMD_VNL':
							    ymdString = data.value;
							    ymdEleNames = id_div.split('|');
							    if (checkYMDFormat(ymdString)) {
							    	arrYmdVal = ymdString.split('-');
									$("#" + ymdEleNames[0]).val(parseInt(arrYmdVal[0]));
									$("#" + ymdEleNames[1]).focus();
									$("#"+ ymdEleNames[1]).val(parseInt(arrYmdVal[1]));
									$("#" + ymdEleNames[2]).focus();
									$("#"+ ymdEleNames[2]).val(parseInt(arrYmdVal[2]));
									$("#" + ymdEleNames[3]).focus();
									$temp = fixVNLMonth(parseInt(arrYmdVal[1]));
									$temp = $temp.toString().toUpperCase();
									console.log($temp);
									$dateCompi = pad(parseInt(arrYmdVal[2]),2) + '-' +  $temp + '-' + pad(parseInt(arrYmdVal[0]),4);
									$("#"+ ymdEleNames[3]).val($dateCompi);
									$("#" + ymdEleNames[1]).focus();
									//$("#"+ ymdEleNames[0]).trigger('change');
							    }
								break;
                            //@Thuy
                            case 'Y/M/D':

                                ymdString = data.value;
							    if (checkYMDFormat(ymdString)) {
                                    arrYmdVal = ymdString.split('-');
									ymdString = arrYmdVal[0]+"/"+arrYmdVal[1]+"/"+arrYmdVal[2];
									$("#"+ id_div).val(ymdString);
							    }else
                                {
                                    var str = ymdString.replace(/[^\d]/g,'')
                                	var y = str[0]+str[1]+str[2]+str[3];
                                    var m = str[4]+str[5]
                                    var d = str[6]+str[7]
                                    ymdString = y+"/"+m+"/"+d;
                                    console.log(ymdString);
                                    $("#"+ id_div).val(ymdString);
                                }
								break;
                            //@Thuy

							case 'TelMailJJP':
								// by id
								strVal = data.value.toString();
								telNames = id_div.split('|');
								if (strVal.substring(0,1) == "0") {
									strVal = strVal.substring(1);
									$('#' + telNames[0]).val(strVal);
									$('#' + telNames[1]).val(strVal);
									$('#' + telNames[2]).val(strVal);
								}
								//strVal = "cc@tokyo-ogasawarakai.com";
								//$('#ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxEmailAddress').val(strVal);
								//$('#ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxEmailAddressConfirm').val(strVal);
								break;
								
							case 'setTravellerHAC':
								setFncTravellerHAC(data.value, id_div);
								break;	
							case 'setSmartTicket':
								setFromAppliSmartTicket(data.value, id_div);
								break;
							case 'setLoginSmartTicket':
							    switch(data.value) {
							       case 'AG':
							       		$("[name='account']").val(AG_GLB_ACCOUNT_SMART_TICKET);
										$("[name='password']").val(AG_GLB_PASSWORD_SMART_TICKET);
							       		break;
							       case 'EK':
							       		$("[name='account']").val(EK_GLB_ACCOUNT_SMART_TICKET);
										$("[name='password']").val(EK_GLB_PASSWORD_SMART_TICKET);
							       		break;		
							       case 'AC':
							       		$("[name='account']").val(AC_GLB_ACCOUNT_SMART_TICKET);
										$("[name='password']").val(AC_GLB_PASSWORD_SMART_TICKET);
							       		break;
							       case 'SG':
							       		$("[name='account']").val(SG_GLB_ACCOUNT_SMART_TICKET);
										$("[name='password']").val(SG_GLB_PASSWORD_SMART_TICKET);
							       		break;
							    }
							    setValue('isLogInOK', '1');
								$("form [src='http://smart-ticket.biz/agent/images/login_btn.gif']").trigger('click');
								break;
							case 'setLogoutSmartTicket':
								if (data.value != '1') {
									href = $('.logout').first().attr('href');
									location.href = href;
								} 
								break;
							case 'setVNL':
								setFromAppliVNL(data.value, id_div);
								break;
							case 'ADO_attendantNumber':
								id = id_div.replace("attendantNumber", "");
								$("[name='"+id_div+"']").val(id);
								break;
							case 'endSetAnaTraveller':
								$('#consentConfirmFlag').trigger('click');
								break;
							case 'setVNLMode':
								if (data.value == 1) {
									getItem("flight_info1","search_from_flight_info1","setVNL");
									getItem("flight_info2","search_from_flight_info2","setVNL");
								} else if (data.value == 2 || data.value == 3) {
									getItem("flight_info1","search_from_flight_info_case_2","setVNL");
								} 
								break;
							case 'copyFromApplicationJJP':
							    $arrAdultChildIndex = data.value;
							    $arrAdultChildIndex = $arrAdultChildIndex.split(';');
							    $arrAdult = $arrAdultChildIndex[0].split('|');
							    $arrChild = $arrAdultChildIndex[1].split('|');
							 	copyFromApplicationJJP($arrAdult, $arrChild);
								break;
							// 20170329 add more case for change design JJP
							case 'copyFromApplicationJJP1':
							    $arrAdultChildIndex = data.value;
							    $arrAdultChildIndex = $arrAdultChildIndex.split(';');
							    $arrAdult = $arrAdultChildIndex[0].split('|');
							    $arrChild = $arrAdultChildIndex[1].split('|');
							 	copyFromApplicationJJP1($arrAdult, $arrChild);
								break;
							case 'setFlightInformationJJP1':
								depdes = data.value.split('→');
								depAirport = $.trim(depdes[0]);
								arrAirport = $.trim(depdes[1]);
								setFlightInformationJJP1(depAirport,arrAirport);
								break;								
							case 'copyFromApplicationVNL':
							    $arrAdultChildIndex = data.value;
							    $arrAdultChildIndex = $arrAdultChildIndex.split(';');
							    $arrAdult = $arrAdultChildIndex[0].split('|');
							    $arrChild = $arrAdultChildIndex[1].split('|');
							 	copyFromAppliVNL($arrAdult, $arrChild);
								break;								
							// CALLBACK BOOKING ANA
						    case 'parse_call_back_ana':
						       optionId = 'flight_info_' + $('#glbKubunId').val();
							   if ($('#'+ optionId +' option').size() < 2) {
								   strDataCallBack = data.value;
							       strDataCallBack = strDataCallBack.split('|');
							       lastName = $('#application_traveller_list_0_last_name').val();
							       firstName = $('#application_traveller_list_0_first_name').val();
							       strValues = strDataCallBack[0].split(';');
							       strTexts = strDataCallBack[1].split(';');
							       var mySelect = $('#flight_info_' + $('#glbKubunId').val());
							       for (i=0;i<strValues.length;i++) {
							       		strValue = strValues[i];
							       		strText = lastName + '/' + firstName + '/';
							       		strText += strTexts[i];
							       		mySelect.append(
									        $('<option></option>').val(strValue).html(strText)
									    );
							       }
							       $('#glbCurAirport').val('');
				  				   $('#glbKubunId').val('');
							       console.log('merchant_flight_info_callback_ana done');
							   }
						       break;
						    // CALLBACK BOOKING JAL
						    
						    case 'parse_call_back_jal':
						       optionId = 'flight_info_' + $('#glbKubunId').val();
							   if ($('#'+ optionId +' option').size() < 2) {
								   strDataCallBack = data.value;
							       strDataCallBack = strDataCallBack.split('|');
							       //lastName = $('#application_traveller_list_0_last_name').val();
							       //firstName = $('#application_traveller_list_0_first_name').val();
							       strValue = strDataCallBack[0];
							       strText = strDataCallBack[1];
							       var mySelect = $('#flight_info_' + $('#glbKubunId').val());     
						       	   //strValue = strValues[i];
						       	   //strText = lastName + '/' + firstName + '/';
						       	   //strText += strTexts[i];
						       	   mySelect.append(
								        $('<option></option>').val(strValue).html(strText)
								   );							       	
							       $('#glbCurAirport').val('');
				  				   $('#glbKubunId').val('');
							       console.log('merchant_flight_info_callback_jal done');
							   }
						       break;
						    // END CONFIRM ANA

                            // CALLBACK BOOKING APJC
						    case 'parse_call_back_apjc':
						       optionId = 'flight_info_' + $('#glbKubunId').val();
							   if ($('#'+ optionId +' option').size() < 2) {
								   strDataCallBack = data.value;
							       strDataCallBack = strDataCallBack.split('|');
							       lastName = $('#application_traveller_list_0_last_name').val();
							       firstName = $('#application_traveller_list_0_first_name').val();
							       strValues = strDataCallBack[0].split(';');
							       strTexts = strDataCallBack[1].split(';');

							       var mySelect = $('#flight_info_' + $('#glbKubunId').val());
							       for (i=0;i<strValues.length;i++) {
							       		strValue = strValues[i];
							       		strText = lastName + '/' + firstName + '/';
							       		strText += strTexts[i];
							       		mySelect.append(
									        $('<option></option>').val(strValue).html(strText)
									    );
							       }

                                   //check callback 2
                                    var key2 = "merchant_flight_info_callback2";
                                    xdLocalStorage.getItem(key2, function (data) {
					                   if(data.value!="")
                                       {
                                           //set option2
                                           if($('#glbKubunId').val()==0)
                                           {
                                               var option_next = 1;
                                           }else
                                           {
                                               var option_next = 0;
                                           }

                                           var mySelect_next = $('#flight_info_' + option_next);
                                           mySelect_next.append(
									        $('<option></option>').val(strValue).html(strText)
									       );

                                           strDataCallBack2 = data.value;
        							       strDataCallBack2 = strDataCallBack2.split('|');
        							       strValues2 = strDataCallBack2[0].split(';');
        							       strTexts2 = strDataCallBack2[1].split(';');
                                           var mySelect = $('#flight_info_' + $('#glbKubunId').val());
        							       for (i=0;i < strValues2.length;i++) {
        							       		strValue2 = strValues2[i];
        							       		strText2 = lastName + '/' + firstName + '/';
        							       		strText2 += strTexts2[i];
        							       		mySelect.append(
        									        $('<option></option>').val(strValue2).html(strText2)
        									    );
                                                 mySelect_next.append(
        									        $('<option></option>').val(strValue2).html(strText2)
        									     );

        							       }

                                          $('#glbCurAirport').val('');
				  				          $('#glbKubunId').val('');
                                       }else
                                       {
                                          $('#glbCurAirport').val('');
				  				          $('#glbKubunId').val('');
                                       }
                                    })
							       console.log('merchant_flight_info_callback_apjc done');
							   }
						       break;

							case 'setTravellerSky':
							    setFuncTravellerSky(data.value, id_div);
								break;
							case 'setConfirmSky':
						    	$("[name='sky2'] table").find("[name='"+ id_div +"']").val(data.value);
						    	if (id_div == 'firstname') {
						    		$("[name='sky2']").find(".bottomButtonSpace [type='image']").trigger('click');
						    	}
								break;
							
						    case 'endConfirmAna':
						    	$("[name='btnchg_searchZZZZZMappingZZZZZmob_chg_pnr']").trigger('click');
						        break;
						    case 'endCancelADO':
						    	$("[type='submit']").trigger('click');
						        break;								
						    case 'endSearchHAC':
						    	$("[name='forward_next']").trigger('click');
						        break;
						    // END CONFIRM APJC

							case 'endConfirmJal':
							    airlineName = data.value;
							    if (airlineName == 'JTA' || airlineName == 'RAC') {
									$("[name='airline']").val('NU');
							    } else if (airlineName == 'JAL') {
							    	$("[name='airline']").val('JL');
							    } else {
							    	$("[name='airline']").val('JN');
							    }
						    	$("[name='cfmGuestRsvInfoInputForm']").submit();
						        break;	
						    case 'endConfirmSFJ':
						    	//click button 次へ
			    				$("[name='btnSubmit:mapping=success&rt=rt_rsvno&parameter=loc_search'").trigger('click');
			    				break;
			    			case 'endConfirmADO':
								$("[type='checkbox'").prop('checked', true);
							    //$("[name='reservation'").trigger('click');
								break;
							case 'endConfirmSNA':
					           //click button 次へ
					           $("[name='btnrt_searchZZZZZMappingZZZZZmob_rt_pnrinfo'").trigger('click');
					           break;
                            //@Thuy only APJC >>
                            case "endParseAdultAPJB":
                            case "endParseAdultAPJC":
                               $('.PaxAdult:eq('+ id_div +')').trigger('click');
                               break;
                            case "endParseChildrenAPJB":
                            case "endParseChildrenAPJC":
                               $('.PaxChildren:eq('+ id_div +')').trigger('click');
                               break;
                            case "endParseInfantAPJB":
                            case "endParseInfantAPJC":
                               $('.PaxInfant:eq('+ id_div +')').trigger('click');
                               break;
                            //@Thuy Only APJC <<
					 		default:
					 		    $('#'+id_div).val(data.value);
					 		    $('#'+id_div).focus();
					 		    break;	
					 	}
						 
    					 if (typeof(option) != 'undefined' && option.indexOf('Start') != -1) {
						   // $("[name=form_search]").append("<input type='hidden' id='glbCurAirport' name='glbCurAirport' value=''/>");
						   // $("[name=form_search]").append("<input type='hidden' id='glbKubunId' name='glbKubunId' value=''/>");
     					 } 
					}
                });
            } else {
                //console.log('You must enter a key to get.');
            }
        }
        function removeItem (key) {
            if(key) {
                xdLocalStorage.removeItem(key, function (data) {
                  // console.log('Key was removed');
                });
            } else {
                 //console.log('You must enter a key to remove.');
            }
        }
        
        function keyName (index_keyNameInput) {
            if(index_keyNameInput) {
                xdLocalStorage.key(index_keyNameInput, function (data) {
                    return data.key;
                });
            } else {
               // console.log('Key was removed');
            }
        }
        function clearAll () {
            xdLocalStorage.clear(function (data) {
            	$now = new Date();
            	$now = '' + $now.getFullYear() + '-' +
			               pad($now.getMonth() + 1,2) + '-' +
			               pad($now.getDate(),2) + ' ' +
			               pad($now.getHours(),2) + ':' +
			               pad($now.getMinutes(),2) + ':' +
			               pad($now.getSeconds(),2);
                console.log('LocalStorage was cleared at ' + $now);
            });
        }

// common part >>>
	function keydown(e) { 
	    if (e.keyCode == 116) {
	        clearAll();	
	    }
	};
	
	///////////////
	
	///////////////
	var appId = '';
	loc = window.location;
	$( document ).ready(function() {
		// $(document).on("keydown", keydown);
		  domain_name = document.domain;
		   //setFlightInformationAdo111();
		   
		   //return;
		  //@Thuy Edit 2016-25-01
		if (CMS_DOMAIN.indexOf(domain_name) > -1)
		{
		  //if( domain_name== CMS_DOMAIN) {
		    loc = window.location;
		    if(loc.toString().indexOf('/s/appli/application/edit') != -1 || loc.toString().indexOf('/s/appli/application/clone') != -1)  {
		    	// BOOKING >>>>>>
				$("[id^='airline_link_']").click(function(){
					// check click right link
					currentId = this.id;
					// console.log(this.id);
					arrSplitId = currentId.split('_');
					if (arrSplitId.length < 4) {
						return;
					}
					kubun_id = currentId.toString().replace('airline_link_', '');
					kubun_id = kubun_id.substring(0,1);
					$('#glbKubunId').val(arrSplitId[2]);
					$('#glbCurAirport').val(arrSplitId[3]);
					// Set value to merchant parsing >>>>
					clearAll(); 
					// 代表者名 part >>
					
					var adultCount = 0;
					var childCount = 0;
					var childCountA = 0;
					var childCountB = 0;
					var infantCount = 0;
					var adultList = "";
					var childAList = "";
					var childBList = "";
					var infantList = "";
					var childList = "";
					var app_id = "";
					
					//sessionStorage.setItem('cms_app_id', 12345);
					//sessionStorage.getItem('cms_app_id');
					
					app_id = $('#application_application_id').val();
					appId = app_id;
					
					var json_str = '';
					
					json_str = json_str + "{'app_id':'" +  app_id + "',";
					
					 
					for (i=0; i<=8; i++) {
						lname = $('#application_traveller_list_' + i + '_last_name').val();
						fname = $('#application_traveller_list_' + i + '_first_name').val();
						setValue(app_id + '_application_traveller_list_' + i.toString() + '_last_name', lname);
						setValue(app_id + '_application_traveller_list_' + i.toString() + '_first_name', fname);
						nameEleAge = "application[traveller_list][" + i.toString() + "][age]";
						setValue(app_id + '_application_traveller_list_' + i.toString() + '_age', $("[name='"+ nameEleAge +"']").val());
						nameEleSex = "application[traveller_list][" + i.toString() + "][sex]";
						setValue(app_id + '_application_traveller_list_' + i.toString() + '_sex', $("[name='"+ nameEleSex +"']:checked").val());

						// set birthday
						setValue(app_id + '_application_traveller_list_' + i.toString() + '_birthday', fixFormatDate($('#application_traveller_list_' + i.toString() + '_birthday').val()));

						// set romaji
						setValue(app_id + '_application_traveller_list_' + i.toString() + '_first_name_rome', convKata2Romaji(fname, $('#application_traveller_list_' + i.toString() + '_first_name_rome').val()));
						setValue(app_id + '_application_traveller_list_' + i.toString() + '_last_name_rome', convKata2Romaji(lname, $('#application_traveller_list_' + i.toString() + '_last_name_rome').val()));


						// Thanh
						
						json_str = json_str + "{'application_traveller_list_" + i.toString() + "_last_name':'" +  lname + "',";
						json_str = json_str + "{'application_traveller_list_" + i.toString() + "_first_name':'" +  fname + "',";
						json_str = json_str + "{'application_traveller_list_" + i.toString() + "_age':'" +  $("[name='"+ nameEleAge +"']").val() + "',";
						json_str = json_str + "{'application_traveller_list_" + i.toString() + "_age':'" +  $("[name='"+ nameEleSex +"']:checked").val() + "',";
						json_str = json_str + "{'application_traveller_list_" + i.toString() + "_birthday':'" +  fixFormatDate($('#application_traveller_list_' + i.toString() + '_birthday').val()) + "',";
						json_str = json_str + "{'application_traveller_list_" + i.toString() + "_first_name_rome':'" +  convKata2Romaji(fname, $('#application_traveller_list_' + i.toString() + '_first_name_rome').val()) + "',";
						json_str = json_str + "{'application_traveller_list_" + i.toString() + "_last_name_rome':'" +  convKata2Romaji(lname, $('#application_traveller_list_' + i.toString() + '_last_name_rome').val()) + "',";
						
						
						var tmpsex = $('input[name = "application[traveller_list][' + i + '][sex]"]:checked').val();
						
						if(lname !="" && fname !=""){
							if (tmpsex == 1){
								setValue(app_id + "_sex" + i , "M");
								json_str = json_str + "{'sex" + i.toString() + "':'M',";
							} else {
								setValue(app_id + "_sex" + i , "F");
								json_str = json_str + "{'sex" + i.toString() + "':'F',";
							}
						}
						
						var tmpage = $('#application_traveller_list_' + i + '_age').val();
						if(lname != "" && fname != ""){
							if (tmpage >= 12) {
								adultList += i.toString() + ",";
								adultCount++;
							} else if (tmpage >= 8) {
								childAList += i.toString() + ",";
								childList += i.toString() + ",";
								childCountA++;
							} else if (tmpage >= 3) {
								childBList += i.toString() + ",";
								childList += i.toString() + ",";
								childCountB++;
							}
						}
					}
					
					setValue(app_id + '_application_adult_list', adultList);
					setValue(app_id + '_application_child_a_list', childAList);
					setValue(app_id + '_application_child_b_list', childBList);
					setValue(app_id + '_application_child_list', childList);
					
					setValue(app_id + '_application_adult_count', adultCount);
					setValue(app_id + '_application_child_a_count', childCountA);
					setValue(app_id + '_application_child_b_count', childCountB);
					setValue(app_id + '_application_child_count', childCountA + childCountB);
					
					
					setValue(app_id + '_application_traveller_list_adult_child_index', '' + getStringAdultChildIndex());
					
					
					json_str = json_str + "{'application_adult_list':'" +  adultList + "',";
					json_str = json_str + "{'application_child_a_list':'" +  childAList + "',";
					json_str = json_str + "{'application_child_b_list':'" +  childBList + "',";
					json_str = json_str + "{'application_child_list':'" +  childList + "',";
					
					json_str = json_str + "{'application_adult_count':'" +  adultCount + "',";
					json_str = json_str + "{'application_child_a_count':'" +  childCountA + "',";
					json_str = json_str + "{'application_child_b_count':'" +  childCountB + "',";
					json_str = json_str + "{'application_child_count':'" +  lname + "',";
					json_str = json_str + "{'application_traveller_list_adult_child_index':'" +  childCountA + childCountB + "',";
					
					for (i=0; i<=1; i++) {
						inf_lname = $('#application_infant_list_' + i + '_last_name').val();
						inf_fname = $('#application_infant_list_' + i + '_first_name').val();
						setValue(app_id + '_application_infant_list_' + i.toString() + '_first_name', inf_fname);
						setValue(app_id + '_application_infant_list_' + i.toString() + '_last_name', inf_lname);
						// birthday
						setValue(app_id + '_application_infant_list_' + i.toString() + '_birthday', fixFormatDate($('#application_infant_list_' + i + '_birthday').val()));

						// romaji
						setValue(app_id + '_application_infant_list_' + i.toString() + '_first_name_rome', convKata2Romaji(inf_fname, $('#application_infant_list_' + i.toString() + '_first_name_rome').val()));
						setValue(app_id + '_application_infant_list_' + i.toString() + '_last_name_rome', convKata2Romaji(inf_lname, $('#application_infant_list_' + i.toString() + '_last_name_rome').val()));

						nameEleAge = "application[infant_list][" + i.toString() + "][age]";
						setValue(app_id + '_application_infant_list_' + i.toString() + '_age', $("[name='"+ nameEleAge +"']").val());
						nameEleSex = "application[infant_list][" + i.toString() + "][sex]";
						setValue(app_id + '_application_infant_list_' + i.toString() + '_sex', $("[name='"+ nameEleSex +"']:checked").val());
						// ThanhNV >>>

						setValue(app_id + "_inf_lname" + i , inf_lname);
						setValue(app_id + "_inf_fname" + i , inf_fname);
						setValue(app_id + "_inf_age" + i , $('#application_infant_list_' + i + '_age').val());
						var tmpsex = $('input[name = "application[infant_list][' + i + '][sex]"]:checked').val();
						if(inf_lname !="" && inf_fname !=""){
							if (tmpsex == 1){
								setValue(app_id + "_inf_sex" + i , "M");
							} else {
								setValue(app_id + "_inf_sex" + i , "F");
							}
						}
						// ThanhNV
						if(inf_lname !="" && inf_fname !=""){
							infantList += i.toString() + ",";
							infantCount++;
						}
						setValue(app_id + "_inf_pax" + i , i + 1);
					}
					
					
					setValue(app_id + '_reserve_email_jjp', $('#reserve_email_jjp').val()); // 20170419
					setValue(app_id + '_glb_cmslink', $('#cmslink').val());
					setValue(app_id + '_isLogInOK', '0');
					setValue(app_id + '_application_infant_list', infantList);
					setValue(app_id + '_application_infant_count', infantCount);
					setValue(app_id + '_application_tel1', $('#application_tel1').val());
					setValue(app_id + '_application_zip_code', $('#application_zip_code').val().toString().replace('-','').replace('－',''));
					// setValue(app_id + '_application_tel1_not0', $('#application_tel1').val().toString.substring(1));
					arrayMail = $('#reserve_email').val().toString().split('@');
					setValue(app_id + '_reserve_email', $('#reserve_email').val());
					setValue(app_id + '_application_assistMailAccount', arrayMail[0]);
					setValue(app_id + '_application_assistMailDomain', arrayMail[1]);
					setValue(app_id + '_application_sendMailId', '1');
					setValue(app_id + '_application_mail1', $('#application_email').val());
					setValue(app_id + '_application_common_email', $('#mail').val());
					setValue(app_id + '_application_sky_email', $('#sky_mail').val());
					$arrMailYoyaku = $('#sky_mail').val().toString().split('@');
					setValue(app_id + '_application_yoyaku_email_first', $arrMailYoyaku[0]);
					setValue(app_id + '_application_yoyaku_email_next', $arrMailYoyaku[1]);
					// ThanhNV
					setValue(app_id + "_mail", $('#mail').val());
					var tel = $('#application_tel1').val();
					//tel = tel.replace(/[-]/g, ""); 
					tel = tel.split("-").join(""); 
					if(tel == "0334316280"){
						tel1 = "03";
						tel2 = "3431";
						tel3 = "6280";
					} else {
						tel1 = tel.substring(0,3);
						tel2 = tel.substring(3,7);
						tel3 = tel.substring(7);
					}
					setValue(app_id + "_tel", tel1);
					setValue(app_id + "_tel1", tel2);
					setValue(app_id + "_tel2", tel3);
					// <<< ThanhNV
					// <<< 代表者名 part
					// <<< Set value to merchant parsing
					//http://test.ticket-search.net/hung/ANA_booking.html
					// window.open('http://esm.local/jjp/input.html', '_blank');
                    // ThuyTQ >>
                    setValue(app_id + '_application_address2', $('.address_tr').find('#application_address2').val());
                    setValue(app_id + '_application_address3', $('#application_address3').val());
                    setValue(app_id + '_application_address4', $('#application_address4').val());
                    // ThuyTQ <<
                    // SmartTicket ThanhBN add >>> 
                    if ($('#flight_info1').val() != '' && $('#flight_info2').val() != '') {
	                    setValue(app_id + '_flight_info1', $('#flight_info1').val());
	                    setValue(app_id + '_flight_info2', $('#flight_info2').val());
                    	setValue(app_id + '_VNLMode', 1);
                    } else if ($('#flight_info1').val() != '') {
                    	setValue(app_id + '_VNLMode', 2);
						setValue(app_id + '_flight_info1', $('#flight_info1').val());
	                    // setValue(app_id + '_flight_info2', $('#flight_info2').val());                    	
                    } else if ($('#flight_info2').val() != '') {
                    	setValue(app_id + '_flight_info1', $('#flight_info2').val());
                    	setValue(app_id + '_VNLMode', 3);
                    }
                    // <<< SmartTicket ThanhBN add
				});
				// <<<<< BOOKING 
				// CONFIRM
				$(".check_button[value='予約確認']").click(function(){
					onclickFnc = $(this).attr('onclick');
					onclickFnc = onclickFnc.toString().replace('confirmReservation(', '');
					onclickFnc = onclickFnc.substring(0,1);
					$('#glbKubunId').val(onclickFnc);
					
				});
		   }  else if(loc.toString().indexOf('/s/appli/application/confirmReservation') != -1)  {
				setTimeout(function(){
					clearAll();
					dtmNow = new Date();
					intYear = dtmNow.getFullYear();
					airlineName = $('#airline').val().toString().toLowerCase();
					setValue(app_id + '_application_first_name', $('#first_name').val());
					setValue(app_id + '_application_last_name', $('#last_name').val());
					setValue(app_id + '_application_first_name_rome', convKata2Romaji($('#first_name').val(), $('#application_traveller_list_0_first_name_rome').val()));
					setValue(app_id + '_application_last_name_rome', convKata2Romaji($('#last_name').val(), $('#application_traveller_list_0_last_name_rome').val()));					
					setValue(app_id + '_application_airline_name', $('#airline').val());
					setValue(app_id + '_application_flight_no', $('#flight_no').val());
					setValue(app_id + '_application_flight_year', $('#year').val());
					setValue(app_id + '_application_flight_month', $('#month').val());
					setValue(app_id + '_application_flight_day', $('#day').val());
					setValue(app_id + '_application_flight_date', '' + pad(parseInt($('#month').val()),2) + pad(parseInt($('#day').val()),2));
					setValue(app_id + '_application_flight_date_full', $('#year').val() + '-' + pad(parseInt($('#month').val()),2) + '-' + pad(parseInt($('#day').val()),2));
					setValue(app_id + '_application_ticket_reservation_no', $('#ticket_reservation_no').val());
					if (airlineName == 'jta' || airlineName == 'rac' || airlineName == 'jac') {
						airlineName = 'jal';
					}
					href = $('#' + airlineName + '_link').attr('href');
					location.href = href;
				}, CMS_TIMEOUT_INMILISECONDS);
			} 
		  }		
		  //@Thuy edit 2016-26-01 >>  
		  else
		  { 
		  
		  	$( "body" ).append( "<p id='domain_cmstest' style='display:none'>"+domain_cms+"</p>" + "<input type='hidden' id='appId_cms'  value='testttt34'>");	
    		$( "body" ).append( "<input type='hidden' id='appId_cms'  value='" + appId + "'>");
    		
		  	loc = window.location;
		    if(loc.toString().indexOf('/s/appli/application/edit') != -1 || loc.toString().indexOf('/s/appli/application/clone') != -1)  
		    {
		    	clearAll();			    
		    }
		  }
		  //@Thuy edit 2016-26-01 <<  
	});
	
	window.addEventListener('focus', function() {
	  // check by domain
	   domain_name = document.domain;
	    
	    //call again CMS domain
	    getDomain();
		
		setTimeout(function(){
		// Handler for .ready() called.
		CMS_DOMAIN = $("#domain_cms").html();
		CMS_DOMAIN = (CMS_DOMAIN == '' || typeof(CMS_DOMAIN) == 'undefined' ? 'air.tabicapital_dev.net' :  CMS_DOMAIN);
		console.log('Call domain again: ' + CMS_DOMAIN);
		
	  //@Thuy Edit 2016-25-01
	  if (CMS_DOMAIN.indexOf(domain_name) > -1) {
		  loc = window.location;
		  if(loc.toString().indexOf('/s/appli/application/edit') != -1 || loc.toString().indexOf('/s/appli/application/clone') != -1) {
		  	
		  		if($('#glbCurAirport').length > 0 )
		  		{
		  			airPortName = $('#glbCurAirport').val().toString().toUpperCase();
		  		}else
		  		{
		  			airPortName ="";
		  		}				

				switch(airPortName) {
					case 'ANA':
					case 'JJP':
					case 'SKY':
					case 'HAC':
					case 'VNL':
					case 'ANANEW':
				  		setCallBackANA();
				  		break;
				  	case 'JAL':
				  	case 'SFJ':
				  	case 'SNA':
				  	case 'ADO':
				  		setCallBackJAL();
				  		break;
                    /*ThuyTQ 2016-02-03 add >> */
                    case 'APJC':
                        setCallBackAPJC();
                        break;
                    /*ThuyTQ 2016-02-03 add << */
			  	}
			  	if (airPortName != '') {
			  		console.log('setCallBackANA done');
			  	}	  	
		  		
		  }
		}
		//@Thuy Edit 2016-1-26 check Inactive clear all 
		else
		{
		   
		    loc = window.location;
		    if(loc.toString().indexOf('/s/appli/application/edit') != -1 || loc.toString().indexOf('/s/appli/application/clone') != -1) {
			    clearAll();			    	    
			}    
		}
		}, 500);
		//@Thuy << 2016-1-26
	});
// <<< common part