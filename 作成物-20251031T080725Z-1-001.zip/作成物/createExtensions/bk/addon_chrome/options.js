function restore_options() {
  chrome.storage.sync.get({
    'CMS_DOMAIN_STORAGE': 'air.tabicapital.net'
  }, function(items) {
       //console.log(items.CMS_DOMAIN_STORAGE);       
       setTimeout(function() { 
       var str_content_domain = "";
        str_content_domain+='<div class="action_content">';
        str_content_domain+='<button class="active_all">Active All</button>';
        str_content_domain+='<button class="inactive_all">Inactive All</button>';
        str_content_domain+='</div>';
       	str_content_domain+='<div class="item">http://<span class="cms_set" id="cms1"><a target="_blank" href="http://opraws_dev.tabicapital.net/s/appli/">air.tabicapital.net</a></span><button class="detete" key="cms1">Delete</button> <button class="default" key="cms1">Active</button><span class="active">&#42; Active</span></div>';  	
	    str_content_domain+='<div class="item">http://<span class="cms_set" id="cms2"><a target="_blank" href="http://opraws_dev.e-koukuuken.com/s/appli/">opr.e-koukuuken.com</a></span><button class="detete" key="cms2">Delete</button> <button class="default" key="cms2">Active</button><span class="active">&#42; Active</span></div>';
	    str_content_domain+='<div class="item">http://<span class="cms_set" id="cms3"><a target="_blank" href="http://at-center.tabicapital.net/s/appli/">at-center.tabicapital.net</a></span><button class="detete" key="cms3">Delete</button> <button class="default" key="cms3">Active</button><span class="active">&#42; Active</span> </div>';
	    str_content_domain+='<div class="item">http://<span class="cms_set" id="cms4"><a target="_blank" href="http://airlink.tabicapital.net/s/appli/">airlink.tabicapital.net</a></span> <button class="detete" key="cms4">Delete</button><button class="default" key="cms4">Active</button><span class="active">&#42; Active</span></div>';
	    str_content_domain+='<div class="item">http://<span class="cms_set" id="cms5"><a target="_blank" href="http://ado-tourist.tabicapital.net/s/appli/">ado-tourist.tabicapital.net</a></span> <button class="detete" key="cms5">Delete</button><button class="default" key="cms5">Active</button><span class="active">&#42; Active</span></div>';		
	    str_content_domain+='<div class="item">https://<span class="cms_set" id="cms6"><a target="_blank" href="https://opraws-prod.e-koukuuken.com/s/appli/">opraws-prod.e-koukuuken.com</a></span> <button class="detete" key="cms6">Delete</button><button class="default" key="cms6">Active</button><span class="active">&#42; Active</span></div>';		
	    str_content_domain+='<div class="item">https://<span class="cms_set" id="cms7"><a target="_blank" href="https://opraws-prod.tabicapital.net/s/appli/">opraws-prod.tabicapital.net</a></span> <button class="detete" key="cms7">Delete</button><button class="default" key="cms7">Active</button><span class="active">&#42; Active</span></div>';		
       chrome.storage.sync.get({
		    'content_domain_option': str_content_domain
		  }, function(items) {
		       //console.log(items.content_domain_option);
		       if(items.content_domain_option!="")
		       {
		       	 $('#content_domain').html(items.content_domain_option);
		       }else
		       {
		       	 $('#content_domain').html(str_content_domain);
		       }
	     });
	    
      }, 750);  
  });
}

document.addEventListener('DOMContentLoaded', restore_options);

//set cms domain strorage
$( ".default" ).live('click', function(e){ 
    	
  $(this).text("Inactive");
  $(this).addClass("inactive");  
  $(this).removeClass( "default" ); 
   	
  var key = $(this).attr("key");
  //console.log(key);
  var value = $("#"+key+" a").text();
  //console.log(value);  
  $("#"+key).parent().find( ".active" ).addClass( "current" );
  
  //paser domain active
  var str_value = "";
  var key_value ="";
  var key_value_content = "";
  
  //console.log($("span.current").length);
  $(".current").each(function( index ) {
        key_value_content = $(this).parent().find("a").text();
                
        if(key_value_content!=""){
        	str_value+=key_value_content+"||";
        }
  });  
  
  chrome.storage.local.remove('CMS_DOMAIN_STORAGE', function(){
  	 //console.log("remove CMS_DOMAIN_STORAGE old success");	    
  });
  
  chrome.storage.sync.set({
    'CMS_DOMAIN_STORAGE': str_value
  }, function() {
    //$('#status').text('Options saved.');
    console.log("Update CMS_DOMAIN_STORAGE new success:"+str_value);    
    
  
  setTimeout(function() {
     var content_domain = $('#content_domain').html();
     chrome.storage.local.remove('content_domain_option', function(){
  	 //console.log("remove content_domain_option old success");	    
   });
      
   chrome.storage.sync.set({
    'content_domain_option': content_domain
  }, function() {    
    //console.log("Update content_domain_option new success"); 
  });    
    
   
      //$('#status').text('');
    }, 750);
  });  
});

//Delete
$(".detete").live('click', function(e){ 
  $(this).parent().remove();
  
  //paser domain active
  var str_value = "";
  var key_value ="";
  var key_value_content = "";
  
  //console.log($("span.current").length);
  $(".current").each(function( index ) {
        key_value_content = $(this).parent().find("a").text();
                
        if(key_value_content!=""){
        	str_value+=key_value_content+"||";
        }
  });  
  
  chrome.storage.local.remove('CMS_DOMAIN_STORAGE', function(){
  	 //console.log("remove CMS_DOMAIN_STORAGE old success");	    
  });
  
  chrome.storage.sync.set({
    'CMS_DOMAIN_STORAGE': str_value
  }, function() {
      //$('#status').text('Options saved.');
      console.log("Update CMS_DOMAIN_STORAGE new success:"+str_value);
	  setTimeout(function() {     
	   var content_domain = $('#content_domain').html();
	   chrome.storage.local.remove('content_domain_option', function(){
	  	 //console.log("remove content_domain_option old success");	    
	   });
	      
	   chrome.storage.sync.set({
	    'content_domain_option': content_domain
	  }, function() {    
	    //console.log("Update content_domain_option new success"); 
	  });
	  }, 750);   
  });
});

//inactive
$(".inactive").live('click', function(e){
  $(this).text("Active");
  $(this).addClass("default");  
  $(this).removeClass( "inactive" ); 
   	
  var key = $(this).attr("key");
  //console.log(key);
  var value = $("#"+key).text();
  //console.log(value);
  
  $("#"+key).parent().find( ".active" ).removeClass( "current" );
  
  //paser domain active
  var str_value = "";
  var key_value ="";
  var key_value_content = "";
  
  //console.log($("span.current").length);
  $(".current").each(function( index ) {
        key_value_content = $(this).parent().find("a").text();
                
        if(key_value_content!=""){
        	str_value+=key_value_content+"||";
        }
  });  
  
  chrome.storage.local.remove('CMS_DOMAIN_STORAGE', function(){
  	 //console.log("remove CMS_DOMAIN_STORAGE old success");	    
  });
  
  chrome.storage.sync.set({
    'CMS_DOMAIN_STORAGE': str_value
  }, function() {
      //$('#status').text('Options saved.');
      console.log("Update CMS_DOMAIN_STORAGE new success:"+str_value);    
  
	  setTimeout(function() {     
	   var content_domain = $('#content_domain').html();
	   chrome.storage.local.remove('content_domain_option', function(){
	  	 //console.log("remove content_domain_option old success");	    
	   });
	      
	   chrome.storage.sync.set({
	    'content_domain_option': content_domain
	  }, function() {    
	    //console.log("Update content_domain_option new success"); 
	  });
	  }, 750);   
  });
});

//active_all
$( ".active_all" ).live('click', function(e){ 
    	
  $(".default").text("Inactive");
  $(".default").addClass("inactive");  
  $(".default").removeClass( "default" );
  $(".active").addClass( "current" );
  
  //paser domain active
  var str_value = "";
  var key_value ="";
  var key_value_content = "";
  
  //console.log($("span.current").length);
  $(".current").each(function( index ) {
        key_value_content = $(this).parent().find("a").text();
        if(key_value_content!=""){
        	str_value+=key_value_content+"||";
        }
  });  
  
  chrome.storage.local.remove('CMS_DOMAIN_STORAGE', function(){
  	 //console.log("remove CMS_DOMAIN_STORAGE old success");	    
  });
  
  chrome.storage.sync.set({
    'CMS_DOMAIN_STORAGE': str_value
  }, function() {
    //$('#status').text('Options saved.');
    console.log("Update CMS_DOMAIN_STORAGE new success:"+str_value);    
    
  
  setTimeout(function() {
     var content_domain = $('#content_domain').html();
     chrome.storage.local.remove('content_domain_option', function(){
  	 //console.log("remove content_domain_option old success");	    
   });
      
   chrome.storage.sync.set({
    'content_domain_option': content_domain
  }, function() {    
    //console.log("Update content_domain_option new success"); 
  });    
  
    }, 750);
  });  
});

//inactive_all
$(".inactive_all").live('click', function(e){
  $(".inactive").text("Active");
  $(".inactive").addClass("default");  
  $(".inactive").removeClass( "inactive" );
  $( ".active" ).removeClass( "current" );
  
  //paser domain active
  var str_value = "";
  var key_value ="";
  var key_value_content = "";
  
  
  
  chrome.storage.local.remove('CMS_DOMAIN_STORAGE', function(){
  	 //console.log("remove CMS_DOMAIN_STORAGE old success");	    
  });
  
  chrome.storage.sync.set({
    'CMS_DOMAIN_STORAGE': ''
  }, function() {
      //$('#status').text('Options saved.');
      console.log("Update CMS_DOMAIN_STORAGE new success:"+str_value);    
  
	  setTimeout(function() {     
	   var content_domain = $('#content_domain').html();
	   chrome.storage.local.remove('content_domain_option', function(){
	  	 //console.log("remove content_domain_option old success");	    
	   });
	      
	   chrome.storage.sync.set({
	    'content_domain_option': content_domain
	  }, function() {    
	    //console.log("Update content_domain_option new success"); 
	  });
	  }, 750);   
  });
});


//Add
$( "#add" ).live('click', function(e){
   var cms = $.trim($('#cms').val());
   var id_rand = Math.floor((Math.random() * 100) + 50);
   if(cms!="")
   {
   $('#status').text('');	
   var stt = $("#content_domain .item").length;
   stt++;   
   var str = '<div class="item"><span class="cms_set" id="cms'+stt.toString()+id_rand.toString()+'"><a target="_blank" href="'+cms+'/s/appli/">'+cms+'</a></span><button class="detete" key="cms'+stt.toString()+id_rand.toString()+'">Delete</button> <button class="default" key="cms'+stt.toString()+id_rand.toString()+'">Active</button><span class="active">&#42; Active</span></div>';
   
   $( "#content_domain" ).append(str); 
   
   setTimeout(function() {   
	   var content_domain = $('#content_domain').html();
	   chrome.storage.local.remove('content_domain_option', function(){
	  	 //console.log("remove content_domain_option old success");	    
	   });
	      
	   chrome.storage.sync.set({
	    'content_domain_option': content_domain
	  }, function() {    
	    //console.log("Update content_domain_option new success"); 
	  });  
  }, 750);
  }else
  {
  	$('#status').text('Please enter Domain.');
  }      
   
});

//Save VNL Password
$( "#save_vnl" ).live('click', function(e){
	var vnl_pwd = $.trim($('#vnl_pwd').val());
	chrome.storage.sync.set({
		'vnl_pwd': vnl_pwd
	}, function() {
		console.log("Update VNL PWD : " + vnl_pwd);    
	});
});

//追加
$( "#save_apj" ).live('click', function(e){
	var apj_add = $.trim($('#apj_add').val());
	chrome.storage.sync.set({
		'apj_add': apj_add
	}, function() {
		console.log("Update APJ ADDRESS : " + apj_add);    
	});
});