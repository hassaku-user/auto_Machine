/*
 * APJB2B airport
 * Check auto submit
 * Check operator edit after auto fill
 * Check affection to other pages in same domain
 * Clear all value after set in form(click button)
 * Auther: ThuyTQ
 * */

function SetVarGlobal()
{
   xdLocalStorage.getItem("application_traveller_list_adult_child_index", function(data) {
		console.log(data.value);
		if (!!data.value) {
			$("body").append("<input type='hidden' id='application_traveller_list_adult_child_index' name='application_traveller_list_adult_child_index' value='" + data.value + "'>");	
		}else
		{
			$("body").append("<input type='hidden' id='application_traveller_list_adult_child_index' name='application_traveller_list_adult_child_index' value=''>");
		}
		
	});
	
	xdLocalStorage.getItem("flight_info1", function(data) {
		console.log(data.value);
		if (!!data.value) {
			$("body").append("<input type='hidden' id='flight_info1' name='flight_info1' value='" + data.value + "'>");	
		}else
		{
			$("body").append("<input type='hidden' id='flight_info1' name='flight_info1' value=''>");
		}
	});
	
	xdLocalStorage.getItem("flight_info2", function(data) {
		console.log(data.value);
		if (!!data.value) {
			$("body").append("<input type='hidden' id='flight_info2' name='flight_info2' value='" + data.value + "'>");	
		}else
		{
			$("body").append("<input type='hidden' id='flight_info2' name='flight_info2' value=''>");
		}
	});	
}

/// <summary>
/// 日本語
/// </summary>
/// <param name="doc"></param>
function changeLangToJP()
{
	try
	{		 
   	  	 $('#hddlang').val("ja-jp");										
		 $('#prechange').val(1);					
		 $("#aspnetForm").submit();
	}
	catch (ex)
	{
		return;
		//throw ex;
	}
}

/// <summary>
/// ログイン
/// </summary>
/// <param name="doc"></param>
function login()
{
	try
	{
		var agency_code = "B2BJPTCC";
		var user_id = "sasanuma0120";
		var password = "pass1234*";
		$("#txtCompany").val(agency_code);
		$("#txtAdminName").val(user_id);
		$("#txtPassword").val(password);
		//$(".buttonContent a").trigger( "click" );		
	
	}
	catch (ex)
	{
		return;
		//throw ex;
	}
}

/// <summary>
/// 空席照会する
/// </summary>
/// <param name="docAppli"></param>
/// <param name="doc"></param>
function searchFromAppli()
{
	try
	{

		var departureCity = "";
		var arrivalCity = "";

		var departureYear = 0;
		var departureMonth = 0;
		var departureDay = 0;
		var arrivalYear = 0;
		var arrivalMonth = 0;
		var arrivalDay = 0;

		var adultCount = 0;
		var childCount = 0;
		var infantCount = 0;

		departureDate = DATE_MIN_VAL;
		arrivalDate = DATE_MIN_VAL;

		var flight_info_s1;
		var flight_info_s2;
		var application_traveller_list_adult_child_index =  $("#application_traveller_list_adult_child_index").val();
		var flight_info1 = $("#flight_info1").val();
		var flight_info2 = $("#flight_info2").val();
        
        //alert (application_traveller_list_adult_child_index+"flight_info1:"+flight_info1 +"flight_info2:"+ flight_info2);
		var sel = null;        
        
		if (flight_info2 != "")
		{
			flight_info1 = flight_info2;
		}
		flight_info_s1 = flight_info1.split('_');            
		departureCity = flight_info_s1[7];
		arrivalCity = flight_info_s1[8];

		departureYear = parseInt(flight_info_s1[1]);
		departureMonth = parseInt(flight_info_s1[2]);
		departureDay = parseInt(flight_info_s1[3]);
		departureDate = pad(departureYear,4) + pad(departureMonth,2);

		adultCount = parseInt(flight_info_s1[4]);
		childCount = parseInt(flight_info_s1[5]);
		infantCount = parseInt(flight_info_s1[6]);

		//片道
		rtow = $("#rd2").val();
		if (rtow != null)
		{
			$("#rd2").trigger( "click" );			
		}

		//出発地
		$("#uxOrigin").val(departureCity);
		//到着地
		$("#uxDest").val(arrivalCity);

		//出発日
		sel = $("#ddlMY_1").val();		//201506
		if (sel != null)
		{
			$("#ddlMY_1").val(departureDate);				
			$("#ddlMY_1").trigger('change');
		}
		sel = $("#ddlDate_1").val();	//07
		if (sel != null)
		{
			
			$("#ddlDate_1").val(departureDay.toString());				
			 $("#ddlDate_1").trigger('change');
		}
		
		//出発日
		sel = $("#ddlMY_2").val();		//201506
		if (sel != null)
		{
			$("#ddlMY_2").val(departureDate);				
			$("#ddlMY_2").trigger('change');
		}
		sel = $("#ddlDate_2").val();	//07
		if (sel != null)
		{
			
			$("#ddlDate_2").val(departureDay.toString());				
			 $("#ddlDate_2").trigger('change');
		}

		//大人
		$("#optAdult").val(adultCount.toString());
		//小児
		$("#optChild").val(childCount.toString());
		
		//乳幼児 
		$("#optInfant").val(infantCount.toString());
		
		
		
	}
	catch (ex)
	{
		return;
		//throw ex;
	}
}

function copyFromAppli()
{
	var strValue = "";
	var inp = null;
	var sel = null;
	var adultCount = 0,
	    childCount = 0,
	    infantCount = 0;
	var adultCount_index = null,
	    childCount_index = null;
	//get
	var str = $("#application_traveller_list_adult_child_index").val();
	
	if (str != '' && typeof (str) != 'undefined') {
		var res = str.split(";");
		if (res[0]) {
			adultCount_index = res[0].toString().split("|");
			adultCount = adultCount_index.length;
			console.log(adultCount_index + "=>adultCount:" + adultCount);

		}
		if (res[1]) {
			childCount_index = res[1].toString().split("|");
			childCount = childCount_index.length;
			console.log(childCount_index + "=>childCount:" + childCount);
		}
	}
	
	var i = 0;
	var j = 0;
	var l = 0;
    
	$(".Paxicon ul").each(function(index) {
		var className = $(this).attr('class');
		
		if (className != null) {
			
			if (className == "PaxAdult") {

				setTimeout(function() {
					if (adultCount_index[i]) {
						getItem('application_traveller_list_' + adultCount_index[i].toString() + '_birthday', "txtBirthDate_" + (i + 1).toString(), 'Y/M/D');
						getItem('application_traveller_list_' + adultCount_index[i].toString() + '_sex', "txtTitle_" + (i + 1).toString());
						getItem('application_traveller_list_' + adultCount_index[i].toString() + '_last_name_rome', "txtLastname_" + (i + 1).toString());
						getItem('application_traveller_list_' + adultCount_index[i].toString() + '_first_name_rome', "txtName_" + (i + 1).toString());
						//optionend
						getItem('application_traveller_list_' + adultCount_index[i].toString() + '_first_name_rome', i, 'endParseAdultAPJB');
						i++;
					}
				}, CMS_TIMEOUT_INMILISECONDS);

			} else if (className == "PaxChildren") {
				setTimeout(function() {

					if (childCount_index[j]) {
						getItem('application_traveller_list_' + childCount_index[j].toString() + '_birthday', "txtBirthDate_" + (i + 1).toString(), 'Y/M/D');
						getItem('application_traveller_list_' + childCount_index[j].toString() + '_sex', "txtTitle_" + (i + 1).toString());
						getItem('application_traveller_list_' + childCount_index[j].toString() + '_last_name_rome', "txtLastname_" + (i + 1).toString());
						getItem('application_traveller_list_' + childCount_index[j].toString() + '_first_name_rome', "txtName_" + (i + 1).toString());
						//optionend
						getItem('application_traveller_list_' + l.toString() + '_first_name_rome', j, 'endParseChildrenAPJB');
						i++;
						j++;
					}

				}, CMS_TIMEOUT_INMILISECONDS);

			} else if (className == "PaxInfant") {
				setTimeout(function() {

					getItem('application_infant_list_' + l.toString() + '_birthday', "txtBirthDate_" + (i + 1).toString(), 'Y/M/D');
					getItem('application_infant_list_' + l.toString() + '_sex', "txtTitle_" + (i + 1).toString());
					getItem('application_infant_list_' + l.toString() + '_last_name_rome', "txtLastname_" + (i + 1).toString());
					getItem('application_infant_list_' + l.toString() + '_first_name_rome', "txtName_" + (i + 1).toString());
					//optionend
					getItem('application_infant_list_' + l.toString() + '_first_name_rome', l, 'endParseInfantAPJB');
					i++;
					l++;

				}, CMS_TIMEOUT_INMILISECONDS);

			}
		}// end if null
	});
	
}


        /// <summary>
		/// 手配者連絡先詳細
		/// </summary>
		/// <param name="docAppli"></param>
		/// <param name="doc"></param>
		function copyFromAppli2()
		{
			try
			{
				var strValue = "";

				//代表搭乗者情報を使用する
				$("#chkLeadPassenger").trigger( "click" );				
				setTimeout(function() {
                    //PCメールアドレス
					strValue = "cc@tokyo-ogasawarakai.com";				
					$("#uxEmail").val(strValue);					
					getItem('application_tel1', "uxHomePhone");			

				}, CMS_TIMEOUT_INMILISECONDS);				

			}
			catch (ex)
			{
				return;
			}
		}


$(document).ready(function() {
	var domain_name = document.domain;
	var loc = window.location;
	
	if (domain_name == "book.flypeach.com") {
		
	   var body = $('.Wrapper');		
	    
	   if ($("#content .WrapperBody .WrapperBookingLoginBox .PleaseLogin .PleaseLoginContent").text().indexOf("Login") > -1)
	   {
			 changeLangToJP();			
	   }
	   
	   if (body.text().indexOf("ユーザーログイン") > -1)
	   {		     
		     login();
	   }
	   
	   if (body.text().indexOf("アカウント情報") > -1)
	   {			
		 
		 setTimeout(function() {
		 	SetVarGlobal();
		 }, CMS_TIMEOUT_INMILISECONDS);
		 
		 setTimeout(function() {		 		 	
			searchFromAppli();
		 }, CMS_TIMEOUT_INMILISECONDS+200);
				
	   }  
	  
	    
	    $("a[href='javascript:loadHome();']").live('click', function(e){
		     
			 setTimeout(function() {		 		 	
				searchFromAppli();
			 }, CMS_TIMEOUT_INMILISECONDS + 200);
		    
		});
		
		$("a[href='javascript:selectFlight();']").live('click', function(e){
			 setTimeout(function() {		 		 	
				copyFromAppli();
			 }, CMS_TIMEOUT_INMILISECONDS+200);
		   	    
		});
		
		$("a[href='javascript:SavePassengerDetails('FALSE');']").live('click', function(e){			
			 setTimeout(function() {		 		 	
				copyFromAppli2();
			 }, CMS_TIMEOUT_INMILISECONDS+200);
		   	    
		});
		
		
	}
}); 