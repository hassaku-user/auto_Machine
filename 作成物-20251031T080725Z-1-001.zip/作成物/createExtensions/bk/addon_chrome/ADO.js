﻿function setFlightInformationAdo() {
		var strLimitDate = '';
		var strLimitDateText = '';
		var data_callback = '';
		
		//curTable = getTableByTextContain('購入期限');
		//if (typeof(curTable[0]) != 'undefined') {
		//strLimitDate = getCellValueInTable(curTable, 1, 2);
		strLimitDate = $($(".fs-xl.text-center")[0]).text().replace('購入期限　','');
		//}
		//strLimitDate = fixAnaDate(strLimitDateText);
		//strLimitDate = formatDate(strLimitDate);//2016/01/09
		// dtmLimitDate = getLimitDateCom('購入期限');
		dtmLimitDate = formatDate(getLimitDateComFromDateAdo(strLimitDate));
		strValue = "";
		strText = "";
		dtmFlightDate = $($(".bt-content")[0]).attr('data-date').toString().replace("-", "/").replace("-", "/")
		oldArray = $($(".bt-content")[1]).text().split(" ");
		var newArray = oldArray.filter(function(v){return v!==''});
		airline = $.trim(newArray[0]);
		flightno = $.trim(newArray[1]);
		
		dep = $.trim(newArray[2]);
		des = $.trim(newArray[4]);
		deptime = $.trim(newArray[5]).replace(':', '/');
		destime = $.trim(newArray[7]).replace(':', '/');
		$arrTExt = $.trim($('.table-stripe').find('[data-th="利用運賃"]').text()).split(" ");
		ticket_type = $.trim($arrTExt[0]);
		reserno = $('.bg-blue.fs-lg').text();
		var str1 = $('.bt-content').text()
		var txt1 = str1.replace(/[0-9]{4}年/,"");
		var txt1 = txt1.split('）');
		dtmFlightDateJP =	txt1[0] + "）";	
		seat = "普通";
		//value=//2009/03/31/JAL/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
		//text =//3月30日（月）/JAL/548/札幌(千歳)/東京(羽田)
		strValue = dtmFlightDate + "/" + airline +"/" + flightno + "/" + dep + "/" + des;
		strText = dtmFlightDateJP + "/" + airline +"/" + flightno + "/" + dep + "/" + des;
		strValue += "/"+ deptime  + "/" + destime + "/" + reserno + "/"+ dtmLimitDate + "/" + seat;
		strValue += "/"+ ticket_type;
		
		line_no = sessionStorage.getItem('line_no');
		carrier = sessionStorage.getItem('carrier');
		data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
		
		console.log(data_callback);
		cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
		setTimeout(function(){
			setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
		}, CMS_TIMEOUT_INMILISECONDS);
	}

	$( document ).ready(function() {
		var domain_name = document.domain;
		var loc = window.location;
		if(domain_name=="www.airdo.jp"){
			//ADO input
			if(loc.toString().indexOf('/ap/rsv/book/input.html?fid') != -1) {
				setTimeout(function(){
					
					for(i= 0; i < 6; i++){
						getItem('application_traveller_list_' + i.toString() + '_last_name',"lastName" + (i + 1),"name");
						getItem('application_traveller_list_' + i.toString() + '_first_name',"FirstName" + (i + 1),"name");
						getItem('application_traveller_list_' + i.toString() + '_age',"age" + (i + 1),"name");
						getItem('sex' + i.toString(),"sex" + (i + 1),"radio");
						if (i == 0) {
							getItem('reserve_email_jjp',"mailaddress1","name");
						}
					}
					for(i= 0; i < 2; i++){
						getItem('application_infant_list_' + i.toString() + '_last_name',"infantLastName" + (i+1),"name");
						getItem('application_infant_list_' + i.toString() + '_first_name',"infantName" + (i+1),"name");
						getItem('application_infant_list_' + i.toString() + '_age',"infantAge" + (i+1),"select");
						getItem('inf_sex' + i.toString(),"infantSex" + (i+1),"radio");
						getItem('inf_sex' + i.toString(),"attendantNumber" + (i+1),"ADO_attendantNumber");
					}
					getItem("application_tel1","telNumber","name");
					//getItem('application_assistMailAccount',"contactForm.rsvMailAccount", 'name');
					//getItem('application_assistMailDomain',"contactForm.rsvMailDomain", 'name');
				}, CMS_TIMEOUT_INMILISECONDS);
			}
			//ADO Complete
			if(loc.toString().indexOf('ap/rsv/reservation/detail.html?psid') != -1) {
				setFlightInformationAdo();
				console.log('setFlightInformationAdo done');
			}
			//ADO confirm
			if(loc.toString().indexOf('ap/rsv/book/confirm.html?fid') != -1)  {
				setTimeout(function(){
	    	    		//getItem('application_flight_month',"searchForm.selectedEmbMonth", 'name');
						//getItem('application_flight_day',"searchForm.selectedEmbDay", 'name');
						//getItem('application_flight_no',"searchForm.flightNumber", 'name');
						//getItem('application_ticket_reservation_no',"searchForm.reserveNumber", 'name');
						//getItem('application_last_name',"searchForm.lastName", 'name');
	    	    		//getItem('application_first_name',"searchForm.firstName", 'name');
	    	    		getItem('application_tel1',"fid", 'endConfirmADO');
	    	    }, CMS_TIMEOUT_INMILISECONDS);
	    	    console.log('setSFJConfirmation done');
			} 
			//ADO cancel
			if(loc.toString().indexOf('ap/rsv/reservation/search.html') != -1)  {
				setTimeout(function(){
					line_no = $.trim(sessionStorage.getItem('line_no'));
					cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				},500);
				setTimeout(function(){
	    	    		getItem('application_flight_date_full' + line_no,"date-out");
						getItem('application_flight_date_full' + line_no,"boardingDate", 'name');
						// getItem('application_flight_day' + line_no,"searchForm.selectedEmbDay", 'name');
						getItem('application_flight_no' + line_no,"flightNumber", 'name');
						getItem('application_ticket_reservation_no' + line_no,"reservationNumber", 'name');
						getItem('application_last_name' + line_no,"paxLastName", 'name');
	    	    		getItem('application_first_name' + line_no,"paxFirstName", 'name');
	    	    		getItem('application_first_name' + line_no,"fid", 'endCancelADO');
	    	    		clearAll(cms_app_id, line_no);
						// setTimeout(function() {
							// $(".btn.btn-yellow").click();
						// } , 1500);
	    	    }, CMS_TIMEOUT_INMILISECONDS);
	    	    console.log('setSFJConfirmation done');
			} 
			// ADO flight Certification
			if(loc.toString().indexOf('ap/myairdo/cus005/cus005001') != -1)  {
				setTimeout(function(){
					getItem('application_flight_certification_year','depYear','select');
					getItem('application_flight_certification_month','depMonth','select');
					getItem('application_flight_certification_day','depDay','select');
					getItem('application_flight_certification_flight_no','airlineNo','select');
					getItem('application_flight_certification_ticket_reservation_no','reserveNo','select');
					getItem('application_flight_certification_traveller_last_name','lastNameKana','select');
					getItem('application_flight_certification_traveller_first_name','firstNameKana','select');
				},
				 CMS_TIMEOUT_INMILISECONDS);
			}
		} else {
		}
	});
