﻿$(document).ready(function () {
    var domain_name = document.domain;
    var loc = window.location;

    if (domain_name == "www.amx.co.jp") {
        if (loc.pathname == '/') {
            setTimeout(function () {
                setSearchFormAmx();
            }, CMS_TIMEOUT_INMILISECONDS);
        } else if (loc.pathname.indexOf('/booking/axpc0030') !== -1) {
            setTimeout(function () {
                setPassengerFormAmx();
            }, CMS_TIMEOUT_INMILISECONDS);
        } else if (loc.pathname.indexOf('/booking/axpc0020/next') !== -1) {
            setSessionStorageAmx();
        } else if (loc.pathname == '/booking/axpc0020/') {
            var hash = window.location.hash;
            sessionStorage.setItem('amx_hash_original', hash);
        } else if (loc.pathname.indexOf('/booking/axpc0040/reserve') !== -1) {
            // set final flight info
            setFlightInformationAmx();
        } else if (loc.pathname.indexOf('/booking/axpc0040') !== -1) {
            // set temporary flight info to session
            setFlightInformationAmxSession();
            setTimeout(function () {
                $('input[name="formBean.isAgree"]').get(0).click();
            }, 500);
        }
    }
});

function setPassengerFormAmx() {
    for (var i = 0; i < 6; i++) {
        getItem('application_traveller_list_' + i.toString() + '_last_name_rome', "formBean.passengerList[" + i + "].surName", "name");
        getItem('application_traveller_list_' + i.toString() + '_first_name_rome', "formBean.passengerList[" + i + "].givenName", "name");
        getItem('application_traveller_list_' + i.toString() + '_age', "formBean.passengerList[" + i + "].age", "name");
        getItemStorageAmx('application_traveller_list_' + i.toString() + '_sex', "gender_" + i, "sex");
    }
    for (var i = 0; i < 2; i++) {
        getItem('application_infant_list_' + i.toString() + '_last_name_rome', "formBean.infantList[" + i + "].surName", "name");
        getItem('application_infant_list_' + i.toString() + '_first_name_rome', "formBean.infantList[0].givenName", "name");
        getItemStorageAmx('application_infant_list_' + i.toString() + '_sex', "infgender_" + i, "sex");
        getItemStorageAmx('application_infant_list_' + i.toString() + '_birthday', "formBean.infantList[" + i + "].dateOfBirth", "birthday");
    }
    $('input[name="formBean.pnrContact_Address_EmailAddress"]').val('rsv_dom@airtrip.jp');
    getItem('application_tel1', "formBean.pnrContact_Address_PhoneNumber", "name");
    getItemStorageAmx('application_zip_code', "formBean.pnrContact_Address_ZipCode", "zip_code");
    setTimeout(function () {
        var applicant = $('input[name="formBean.passengerList[0].surName"]').val();
        applicant += ' ' + $('input[name="formBean.passengerList[0].givenName"]').val();
        $('input[name="formBean.pnrContact_LocalName"]').val(applicant);
    }, CMS_TIMEOUT_INMILISECONDS);
}

function setSearchFormAmx() {
    var line_no = parseInt($.trim(sessionStorage.getItem('line_no')));
    getItemStorageAmx('flight_info' + (line_no + 1), '', 'search');
    getItemStorageAmx('application_adult_count', '', 'adult_count');
    getItemStorageAmx('application_child_count', '', 'child_count');
    getItemStorageAmx('application_infant_count', '', 'infant_count');

    var hash = window.location.hash;
    sessionStorage.setItem('amx_hash_original', hash);

    setTimeout(function () {
        $('.under_right a').get(0).click();
    }, CMS_TIMEOUT_INMILISECONDS);
}

function setSessionStorageAmx() {
    var hash = sessionStorage.getItem('amx_hash_original');
    var fligh_info = hash.split('_');
    console.log('************fligh_info************' + fligh_info);
    sessionStorage.setItem('cms_app_id', fligh_info[0]);
    sessionStorage.setItem('line_no', fligh_info[1]);
    sessionStorage.setItem('carrier', fligh_info[2]);
    sessionStorage.setItem('confirm_flag', fligh_info[3]);
    sessionStorage.setItem('person_cnt', fligh_info[4]);
    sessionStorage.setItem('name_rome', fligh_info[5]);
}

function setFlightInformationAmx() {
    var dataCallback = '';

    var strLimitDate = $('.kanryou_box_r table td.pay_txt01_2').text().trim(),
        reserNo = $('.kanryou_box_l span.pay_txt04').text().trim(),
        seat = '',
        ticketType = '';

    var strValue = $.trim(sessionStorage.getItem('amx_str_value')),
        strText = $.trim(sessionStorage.getItem('amx_str_text'));

    strValue += "/" + reserNo + "/" + formatDate(new Date(strLimitDate)) + "/" + seat + "/" + ticketType;

    var cms_app_id = $.trim(sessionStorage.getItem('cms_app_id')),
        line_no = $.trim(sessionStorage.getItem('line_no')),
        carrier = $.trim(sessionStorage.getItem('carrier'));

    dataCallback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
    console.log(dataCallback);

    setTimeout(function () {
        setValue(cms_app_id + '_merchant_flight_info_callback' + line_no, dataCallback);
    }, CMS_TIMEOUT_INMILISECONDS);

    sessionStorage.removeItem('amx_str_value');
    sessionStorage.removeItem('amx_str_text');
    sessionStorage.removeItem('amx_hash_original');
}

function setFlightInformationAmxSession() {
    var tableFlight = $('table')[0];
    var rowFlightDetail = $(tableFlight).find('tr:eq(1) td');

    var flightDate = $($(rowFlightDetail)[0]).text().trim(),
        flightNum = $($(rowFlightDetail)[2]).text().trim(),
        airline = flightNum.substring(0, 3),
        flightNo = flightNum.substring(3),
        airport = $($(rowFlightDetail)[1]).text().trim().split('⇒'),
        dep = airport[0].trim(),
        des = airport[1].trim(),
        hourDep = $($(rowFlightDetail)[3]).text().trim().replace(":", "/"),
        hourDes = $($(rowFlightDetail)[4]).text().trim().replace(":", "/");

    var strValue = formatDate(new Date(flightDate)) + "/" + airline + "/" + flightNo + "/" + dep + "/" + des;
    var strText = strValue;
    strValue += "/" + hourDep + "/" + hourDes;
    sessionStorage.setItem('amx_str_value', strValue);
    sessionStorage.setItem('amx_str_text', strText);
}

function getItemStorageAmx(item, element, option) {
    var cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
    var key = cms_app_id + '_' + item;

    xdLocalStorage.getItem(key, function (data) {
        if (!!data.value) {
            switch (option) {
                case 'adult_count':
                    $('.srcAdt').click();
                    $('.srcAdt li[data-value="' + data.value + '"]').click();
                    break;
                case 'child_count':
                    $('.srcCld').click();
                    $('.srcCld li[data-value="' + data.value + '"]').click();
                    break;
                case 'infant_count':
                    $('.srcInf').click();
                    $('.srcInf li[data-value="' + data.value + '"]').click();
                    break;
                case 'sex':
                    let amxSexVal = 1;
                    if (data.value == 1) {
                        amxSexVal = 0;
                    }
                    $('input[type="radio"][name="' + element + '"][value="' + amxSexVal + '"]').click();
                    break;
                case 'birthday':
                    var part = data.value.split('-');
                    $('select[name="' + element + '_y"]').val(part[0]);
                    $('select[name="' + element + '_m"]').val(parseInt(part[1]));
                    $('select[name="' + element + '_d"]').val(parseInt(part[2]));
                    break;
                case 'zip_code':
                    var zip = data.value.replace(' ', '');
                    $('input[name="' + element + '"]').val(zip);
                    break;
                case 'search':
                    var part = data.value.split("_");
                    $('select[name="form_origin"]').val(part[7]);
                    setTimeout(function () {
                        $('.srcDest li[data-value="' + part[8] + '"]').click();
                    }, 500);
                    $('input[type="radio"][name="form_tripType"][value="OW"]').click();
                    $('input[name="form_travelFrom"]').val(part[1] + '/' + part[2] + '/' + part[3]);
                    var monthEn = fixVNLMonth(parseInt(part[2]));
                    $('#hid_travelFrom').val(part[3] + '-' + monthEn + '-' + part[1]); // '30-Nov-2022'
                    break;
            }
        }
    })
}
