// DEFINE VARIABLE PUBLIC >>>

var CMS_DOMAIN = 'opraws-dev.e-koukuuken.com';
var STORAGE_URL = 'https://japanflight.tripstar.co.jp/addon_storage/app/views/storage.php'; // should be https
//var STORAGE_URL = 'https://japanflight.tabi-air.com/addon_storage/app/views/storage.php';
var DATE_MIN_VAL = 1799;
var CMS_DELIMITER = ";";
var CMS_TIMEOUT = '';
var CMS_TIMEOUT_INMILISECONDS = 2000;
var CHROME_STORAGE = chrome.storage.sync;
var STORAGE_LOCAL = chrome.storage.local;
// DEFINE LOGIN >>>>
var AG_GLB_ACCOUNT_SMART_TICKET = "masuda@tabicapi.com";
var AG_GLB_PASSWORD_SMART_TICKET = "YRDVR8HR";

var EK_GLB_ACCOUNT_SMART_TICKET = "masuda@e-koukuuken.com";
var EK_GLB_PASSWORD_SMART_TICKET = "4Y78M8VP";

var AC_GLB_ACCOUNT_SMART_TICKET = "airinfo@airticket-center.com";
var AC_GLB_PASSWORD_SMART_TICKET = "SZZDFSS8";

var SG_GLB_ACCOUNT_SMART_TICKET = "ticket_al@tabicapi.com";
var SG_GLB_PASSWORD_SMART_TICKET = "D8FE5QXN";

var AX_GLB_ACCOUNT_SMART_TICKET = "amex_travel_online@airtrip.jp";
var AX_GLB_PASSWORD_SMART_TICKET = "Up2mCEsf";

var BTM_GLB_ACCOUNT_SMART_TICKET = "tomozawa.miho@pikapaka.co.jp";
var BTM_GLB_PASSWORD_SMART_TICKET = "1KP3ERGV";

// VNL
var GLB_AGENCY_CODE_VNL = "EVA222";
var GLB_USER_ID_VNL = "EVA001";
var GLB_PASSWORD_VNL = "eva555555";
// SKY Satellite
var SKY_SATELLITE_ID = "860418";
var SKY_SATELLITE_PASSWORD = "562422";
var SKY_SATELLITE_ARC = "EVOLA";

var BTM_SKY_SATELLITE_ID = "861327";
var BTM_SKY_SATELLITE_PASSWORD = "210901";
var BTM_SKY_SATELLITE_ARC = "SKT290";
// <<< DEFINE LOGIN
//@Thuy >> Edit 2016-1-11
var CMS_DOMAIN = "";
var CMS_DOMAIN1 = "";
var SERVICE = "";

var MAIL_BOOKING_ANA_JAL = 'rsv_dom@airtrip.jp';
getDomain();
setTimeout(function () {
    $(document).ready(function () {
        // Handler for .ready() called.
        CMS_DOMAIN = $("#domain_cms").html();
        CMS_DOMAIN = (CMS_DOMAIN == '' || typeof (CMS_DOMAIN) == 'undefined' ? 'air.tabicapital_dev.net' : CMS_DOMAIN);
        console.log('domain cms get from option is: ' + CMS_DOMAIN);
    });
}, 300);
//@Thuy << 2016-1-11
// <<< DEFINE VARIABLE PUBLIC
loc1 = window.location;
domain_name1 = "http://" + document.domain + "/s/appli/";
domain_name2 = "https://" + document.domain + "/s/appli/";
if (loc1 == domain_name1 || loc1 == domain_name2) {
} else {
    xdLocalStorage.init(
        {
            iframeUrl: STORAGE_URL,
            initCallback: function () {
                //console.log('Got iframe ready');
                xdLocalStorage.setItem('check', 'no callback');
                //app_id = $('#application_application_id').val();
                //xdLocalStorage.setItem('app_id', app_id);
            }
        }
    );
}

function setFuncTravellerSky(strDataList, id_div) {
    strDataList = strDataList.split(',');
    for (i = 0; i < strDataList.length; i++) {
        if (strDataList[i] != '') {
            if (id_div == 'adult') {
                getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name_rome', "aLastName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name_rome', "aFirstName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_age', "aAge" + i.toString(), "name");
                getItem('sex' + strDataList[i].toString(), "aSex" + i.toString(), "radio");
            } else if (id_div == 'child_a') {
                getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name_rome', "caLastName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name_rome', "caFirstName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_age', "caAge" + i.toString(), "name");
                getItem('sex' + strDataList[i].toString(), "caSex" + i.toString(), "radio");
            } else if (id_div == 'child_b') {
                getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name_rome', "cLastName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name_rome', "cFirstName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_age', "cAge" + i.toString(), "name");
                getItem('sex' + strDataList[i].toString(), "cSex" + i.toString(), "radio");
            } else if (id_div == 'infant') {
                getItem('application_infant_list_' + strDataList[i].toString() + '_last_name_rome', "iLastName" + i.toString(), "name");
                getItem('application_infant_list_' + strDataList[i].toString() + '_first_name_rome', "iFirstName" + i.toString(), "name");
                getItem('application_infant_list_' + strDataList[i].toString() + '_age', "iAge" + i.toString(), "name");
                getItem('inf_sex' + strDataList[i].toString(), "iSex" + i.toString(), "radio");
                getItem('inf_pax' + strDataList[i].toString(), "iAttendant" + i.toString(), "select");
            }
        }
    }
}

//Sky Satellite
function setFuncTravellerSkySatellite(strDataList, id_div) {
    strDataList = strDataList.split(',');
    for (i = 0; i < strDataList.length; i++) {
        if (strDataList[i] != '') {
            if (id_div == 'adult') {
                getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name_rome', "adultLastName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name_rome', "adultFirstName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_age', "adultAge" + i.toString(), "name");
                getItem('sex' + strDataList[i].toString(), "adultSex" + i.toString(), "radio");
            } else if (id_div == 'child_a') {
                getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name_rome', "childALastName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name_rome', "childAFirstName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_age', "childAAge" + i.toString(), "name");
                getItem('sex' + strDataList[i].toString(), "childASex" + i.toString(), "radio");
            } else if (id_div == 'child_b') {
                getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name_rome', "childLastName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name_rome', "childFirstName" + i.toString(), "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_age', "childAge" + i.toString(), "name");
                getItem('sex' + strDataList[i].toString(), "childSex" + i.toString(), "radio");
            } else if (id_div == 'infant') {
                getItem('application_infant_list_' + strDataList[i].toString() + '_last_name_rome', "infantLastName" + i.toString(), "name");
                getItem('application_infant_list_' + strDataList[i].toString() + '_first_name_rome', "infantFirstName" + i.toString(), "name");
                getItem('application_infant_list_' + strDataList[i].toString() + '_age', "infantAge" + i.toString(), "name");
                getItem('inf_sex' + strDataList[i].toString(), "infantSex" + i.toString(), "radio");
                $("[name='infantAttendance_sb" + i.toString() + "']").val(i.toString());
            }
        }
    }
}

function setFncTravellerHAC(strDataList, id_div) {
    strDataList = strDataList.split(',');
    for (i = 0; i < strDataList.length; i++) {
        if (strDataList[i] != '') {
            if (id_div == 'adult') {
                getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name', "passengerInfoAdult[" + i.toString() + "].kanaSurName", "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name', "passengerInfoAdult[" + i.toString() + "].kanaGivenName", "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_age', "passengerInfoAdult[" + i.toString() + "].age", "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_sex', "passengerInfoAdult[" + i.toString() + "].gender", "radio");
            } else if (id_div == 'child') {
                getItem('application_traveller_list_' + strDataList[i].toString() + '_last_name', "passengerInfoChild[" + i.toString() + "].kanaSurName", "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_first_name', "passengerInfoChild[" + i.toString() + "].kanaGivenName", "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_birthday', "passengerInfoChild[" + i.toString() + "].dateOfBirth", "name");
                getItem('application_traveller_list_' + strDataList[i].toString() + '_sex', "passengerInfoChild[" + i.toString() + "].gender", "radio");

                getItem('sex' + strDataList[i].toString(), "cSex" + i.toString(), "radio");
            } else if (id_div == 'infant') {
                getItem('application_infant_list_' + strDataList[i].toString() + '_last_name_rome', "passengerInfoInfant[" + i.toString() + "].romanSurName", "name");
                getItem('application_infant_list_' + strDataList[i].toString() + '_first_name_rome', "passengerInfoInfant[" + i.toString() + "].romanGivenName", "name");
                getItem('application_infant_list_' + strDataList[i].toString() + '_birthday', "passengerInfoInfant[" + i.toString() + "].dateOfBirth", "name");
                getItem('application_infant_list_' + strDataList[i].toString() + '_sex', "passengerInfoInfant[" + i.toString() + "].gender", "radio");
                $("[name='passengerInfoInfant[" + i.toString() + "].guardianNo']").val(1);
            }
        }
    }
}

//Sky Satellite
function setFromAppliSkySatellite(strData, id_div) {
    // strData must not null
    flight_info_s1 = strData.split('_');
    departureYear = parseInt(flight_info_s1[1].toString());
    departureMonth = parseInt(flight_info_s1[2].toString());
    departureDay = parseInt(flight_info_s1[3].toString());
    departureDate = pad(departureMonth, 2) + pad(departureDay, 2);
    departureCity = flight_info_s1[7];
    arrivalCity = flight_info_s1[8];
    seatType = flight_info_s1[10];

    $("[name='new_month'] option").removeAttr('selected');
    $("[name='new_month']").val(departureMonth);
    var changeEvent = document.createEvent("HTMLEvents");
    changeEvent.initEvent("change", true, true);
    document.getElementsByName("new_month")[0].dispatchEvent(changeEvent);
    $("[name='new_day']").val(departureDay);
    //console.log(departureCity + "-" + arrivalCity);

    $('#reserve1').focus();
    //$('#reserve1').val(departureCity).change();
    $('#reserve1 option[value=' + departureCity + ']').attr('selected', 'selected');

    $('#reserve2').focus();
    //$('#reserve1').val(arrivalCity).change();
    $('#reserve2 option[value=' + arrivalCity + ']').attr('selected', 'selected');
    select_arr = $('#reserve2').find(":selected").val();
    if (select_arr != arrivalCity) {
        if (arrivalCity == "HND") {
            $("#reserve2").append(new Option("羽田", "HND"));
        } else if (arrivalCity == "CTS") {
            $("#reserve2").append(new Option("新千歳", "CTS"));
        } else if (arrivalCity == "SDJ") {
            $("#reserve2").append(new Option("仙台", "SDJ"));
        } else if (arrivalCity == "IBR") {
            $("#reserve2").append(new Option("茨城", "IBR"));
        } else if (arrivalCity == "NGO") {
            $("#reserve2").append(new Option("中部", "NGO"));
        } else if (arrivalCity == "UKB") {
            $("#reserve2").append(new Option("神戸", "UKB"));
        } else if (arrivalCity == "NGS") {
            $("#reserve2").append(new Option("長崎", "NGS"));
        } else if (arrivalCity == "FUK") {
            $("#reserve2").append(new Option("福岡", "FUK"));
        } else if (arrivalCity == "KOJ") {
            $("#reserve2").append(new Option("鹿児島", "KOJ"));
        } else if (arrivalCity == "ASJ") {
            $("#reserve2").append(new Option("奄美大島", "ASJ"));
        } else if (arrivalCity == "OKA") {
            $("#reserve2").append(new Option("那覇", "OKA"));
        }
        $('#reserve2 option[value=' + arrivalCity + ']').attr('selected', 'selected');
    }
    //console.log(select_arr);

    setTimeout(function () {
        $("[name='next']").trigger('click');
    }, CMS_TIMEOUT_INMILISECONDS - 100);
}

//Sky Satellite
function setSkyConfirmSatellite(strData, id_div) {
	// strData must not null
    flight_info_s1 = strData.split('_');
    departureYear = parseInt(flight_info_s1[1].toString());
    departureMonth = parseInt(flight_info_s1[2].toString());
    departureDay = parseInt(flight_info_s1[3].toString());
    flight_no = flight_info_s1[4].toString();
    reservation_no = flight_info_s1[5].toString();
    lname = flight_info_s1[6].toString();
    fname = flight_info_s1[7].toString();
	if(id_div =='caller'){
		$("[name='caller']").val(lname);
		return true;
	}
	$("[name='inq_year']").val(departureYear);
	$("[name='inq_month'] option").removeAttr('selected');
    $("[name='inq_month']").val(departureMonth);
    var changeEvent = document.createEvent("HTMLEvents");
    changeEvent.initEvent("change", true, true);
    document.getElementsByName("inq_month")[0].dispatchEvent(changeEvent);
    $("[name='inq_day']").val(departureDay);
    $("[name='inq_flightNo']").val(flight_no);
    $("[name='inq_reserveNo']").val(reservation_no);
    $("[name='inq_lastname']").val(lname);
    $("[name='inq_firstname']").val(fname);
	setTimeout(function () {
        $("[name='inq_check']").trigger('click');
    }, CMS_TIMEOUT_INMILISECONDS - 100);
}

// ANA新株
function setFromAppliSmartTicket(strData, id_div) {
    // strData must not null
    switch (id_div) {
        case 'search_from_flight_info1':
        case 'search_from_flight_info2':
            flight_info_s1 = strData.split('_');
            departureYear = parseInt(flight_info_s1[1].toString());
            departureMonth = parseInt(flight_info_s1[2].toString());
            departureDay = parseInt(flight_info_s1[3].toString());
            departureDate = pad(departureMonth, 2) + pad(departureDay, 2);
            departureCity = flight_info_s1[7];
            arrivalCity = flight_info_s1[8];
            seatType = flight_info_s1[10];
            $("#going_date").val(departureDate);
            $("[name='going_dep_apo']").val(departureCity);
            $("[name='going_arr_apo']").val(arrivalCity);
            $('input[type="radio"][name="going_seatkind"][value="' + getSeatType(seatType) + '"]').attr('checked', true);
            break;
        case 'search_flight_flight_info1':
        case 'search_flight_flight_info2':
            flight_info_s1 = strData.split('_');
            airlineID = flight_info_s1[0].toString();
            airlineNo = flight_info_s1[11].toString();
            ticketType = flight_info_s1[9].toString();

            departureYear = parseInt(flight_info_s1[1].toString());
            departureMonth = parseInt(flight_info_s1[2].toString());
            departureDay = parseInt(flight_info_s1[3].toString());
            departureDate = pad(departureMonth, 2) + pad(departureDay, 2);
            departureCity = flight_info_s1[7];
            arrivalCity = flight_info_s1[8];
            seatType = getSeatType(flight_info_s1[10]);
            $(document).load("http://smart-ticket.biz/agent/inquiry/search_list_ajax",
                {
                    type_flg: 'return',
                    select_air_company: '1',
                    select_data: departureDate,
                    select_dep_apo: departureCity,
                    select_arr_apo: arrivalCity,
                    select_seatkind: seatType
                }
            );
            $(document).ajaxComplete(function () {
                console.log('start select');
                if (id_div == 'search_flight_flight_info1') {
                    selectFlight(airlineNo, airlineID, ticketType);
                } else {
                    selectFlightReturn(airlineNo, airlineID, ticketType);
                }
            });
            //$("body #going01 img").on("load", function (){
            //setTimeout(function(){

            //}, CMS_TIMEOUT_INMILISECONDS + 10000);
            //});
            //}, CMS_TIMEOUT_INMILISECONDS);
            break;
        case 'copy_from_flight_info1':
        case 'copy_from_flight_info2':
            flight_info_s1 = strData.split('_');
            adultCount = parseInt(flight_info_s1[4].toString());
            childCount = parseInt(flight_info_s1[5].toString());
            infantCount = parseInt(flight_info_s1[6].toString());
            //console.log(adultCount + childCount);
            //console.log($('[name="linkselect"]'));
            $('[name="linkselect"]').val(adultCount + childCount);
            for (i = 1; i <= adultCount + childCount; i++) {
                $('#search' + pad(i, 2)).show();
            }
            for (i = 0; i <= 5; i++) {
                getItem('application_traveller_list_' + i.toString() + '_last_name', "rsv_sei_kana" + pad((i + 1).toString(), 2), "name");
                getItem('application_traveller_list_' + i.toString() + '_first_name', "rsv_mei_kana" + pad((i + 1).toString(), 2), "name");
                getItem('application_traveller_list_' + i.toString() + '_age', "rsv_age" + pad((i + 1).toString(), 2), 'name');
                getItem('application_traveller_list_' + i.toString() + '_sex', "rsv_sex" + pad((i + 1).toString(), 2), 'radio');
            }
            //Tel
            getItem('application_tel1', "rsv_tel01", 'name');
            getItem('application_common_email', "rsv_mail01", 'name'); //TODO
            // getItem('application_tel1',"rsv_tel01", 'endSetSmartTicket');
            break;
    }
}

function setFromAppliTravelagent(strData, id_div, properties) {
    let airports = properties.airports;
    if (id_div == 'Search-CriteriaBox') {
        // apj_2020_9_19_1_0_0_NRT_KIX
        let flight_info_s1 = strData.split('_');

        let depAirportObject = null;
        let destAirportObject = null;
        for (const property in airports) {
            if (airports[property].Code == flight_info_s1[7]) {
                depAirportObject = airports[property];
                break;
            }
        }
        for (const property in airports) {
            if (airports[property].Code == flight_info_s1[8]) {
                destAirportObject = airports[property];
                break;
            }
        }

        $('#Search-CriteriaBox #oneway').click();
        $('#Search-CriteriaBox .booking-form .normal_search .departure').click();

        let depAirportDropdown = $('#Search-CriteriaBox .booking-form .normal_search .departureAirports ul').find('li');
        if (depAirportDropdown.length > 0) {
            for (let i = 0; i < depAirportDropdown.length; i++) {
                if ($(depAirportDropdown[i]).text() == depAirportObject.Name) {
                    $(depAirportDropdown[i]).click();
                    break;
                }
            }
        }

        setTimeout(function () {
            let destAirportDropdown = $('#Search-CriteriaBox .booking-form .normal_search .arrivalAirports ul').find('li');
            if (destAirportDropdown.length > 0) {
                for (let i = 0; i < destAirportDropdown.length; i++) {
                    if ($(destAirportDropdown[i]).text() == destAirportObject.Name) {
                        $(destAirportDropdown[i]).click();
                        break;
                    }
                }
            }

        }, 1000);

        const depDay = ("0" + flight_info_s1[3]).slice(-2);
        const depMonth = ("0" + flight_info_s1[2]).slice(-2);
        const depDate = flight_info_s1[1] + '-' + depMonth + '-' + depDay;

        setTimeout(function () {
            $("[id=departureDatepicker]").val(depDate).trigger('change');
            let changeEvent = document.createEvent("HTMLEvents");
            changeEvent.initEvent("change", true, true);
            document.querySelector('[id="departureDatepicker"]').dispatchEvent(changeEvent);
        }, 1000);

        setTimeout(function () {
            const adultCount = parseInt(flight_info_s1[4]);
            const childCount = parseInt(flight_info_s1[5]);
            const infantCount = parseInt(flight_info_s1[6]);

            let changeEvent = document.createEvent("HTMLEvents");
            changeEvent.initEvent("change", true, true);
            for (let i = 0; i < adultCount - 1; i++) {
                $('#passengersDropdown .passengers_adult a.add-button')[0].click();
                document.querySelector('#passengersDropdown .passengers_adult a.add-button').dispatchEvent(changeEvent);
            }

            for (let i = 0; i < childCount; i++) {
                $('#passengersDropdown .passengers_child a.add-button')[0].click();
                document.querySelector('#passengersDropdown .passengers_child a.add-button').dispatchEvent(changeEvent);
            }

            for (let i = 0; i < infantCount; i++) {
                $('#passengersDropdown .passengers_infant a.add-button')[0].click();
                document.querySelector('#passengersDropdown .passengers_infant a.add-button').dispatchEvent(changeEvent);
            }

            if (infantCount > 0) {
                $('#_PopupTermsCondition a.custom_btn')[0].click();
            }
            const passengersDropdown = $("#Search-CriteriaBox .booking-form .passengers_container .global_dropdown_select").parent()[0];
            $(passengersDropdown).click();

        }, 2000);

        const searchBtn = $('#Search-CriteriaBox .booking-form .passengers_container').find('input[type=submit]');
        setTimeout(function () {
            $(searchBtn)[0].click();
        }, 3000);
    }
}

function setFromAppliVNL(strData, id_div) {
    // strData must not null
    switch (id_div) {
        case 'search_from_flight_info1':
        case 'search_from_flight_info2':
            departureCity = "";
            departureYear = 0;
            departureMonth = 0;
            departureDay = 0;
            adultCount = 0;
            childCount = 0;
            infantCount = 0;
            // $('#owTripId').trigger('click');
            if (id_div == 'search_from_flight_info1') {
                flight_info_s1 = strData.split('_');
                departureCity = flight_info_s1[7];
                arrivalCity = flight_info_s1[8];
                departureYear = parseInt(flight_info_s1[1]);
                departureMonth = parseInt(flight_info_s1[2]);
                departureDay = parseInt(flight_info_s1[3]);
                departureDate = new Date(departureYear, departureMonth - 1, departureDay);
                adultCount = parseInt(flight_info_s1[4]);
                childCount = parseInt(flight_info_s1[5]);
                infantCount = parseInt(flight_info_s1[6]);
                $('#aiRESOrigin').val(departureCity);
                $('#aiRESDestination').focus();
                $('#aiRESDestination').val(arrivalCity);
                $("[id='travelDate#trvDate_1'").focus();
                $("[id='travelDate#trvDate_1'").val(formatDate(departureDate));
                $('#trvDate_1').focus();
                $('#trvDate_1').val(departureDay.toString() + "-" + fixVNLMonth(departureMonth) + "-" + departureYear.toString());
                $('#aiRESAdult').focus();
                $('#aiRESAdult').val(adultCount);
                $('#aiRESChild').focus();
                $('#aiRESChild').val(childCount);
                $('#aiRESInfant').focus();
                $('#aiRESInfant').val(infantCount);
                $('#aiRESCurrency').focus();
                $('#aiRESCurrency').val('JP');
                $('#proceed').focus();
            } else {
                flight_info_s2 = strData.split('_');
                arrivalYear = parseInt(flight_info_s2[1]);
                arrivalMonth = parseInt(flight_info_s2[2]);
                arrivalDay = parseInt(flight_info_s2[3]);
                arrivalDate = new DateTime(arrivalYear, arrivalMonth - 1, arrivalDay);
                $("[id='travelDate#aiRESReturnDate'").focus();
                $("[id='travelDate#aiRESReturnDate'").val(formatDate(arrivalDate));
                $('#aiRESReturnDate').focus();
                $('#aiRESReturnDate').val(arrivalDay.toString() + "-" + fixVNLMonth(arrivalMonth) + "-" + arrivalYear.toString());
                $('#proceed').focus();
            }

            $('#hidCalLyr').hide();
            break;
        case 'search_from_flight_info_case_2':
            flight_info_s1 = strData.split('_');
            departureCity = flight_info_s1[7];
            arrivalCity = flight_info_s1[8];
            departureYear = parseInt(flight_info_s1[1]);
            departureMonth = parseInt(flight_info_s1[2]);
            departureDay = parseInt(flight_info_s1[3]);
            departureDate = new Date(departureYear, departureMonth - 1, departureDay);
            adultCount = parseInt(flight_info_s1[4]);
            childCount = parseInt(flight_info_s1[5]);
            infantCount = parseInt(flight_info_s1[6]);
            $('#owTripId').trigger('click');
            $('#aiRESOrigin').val(departureCity);
            $('#aiRESDestination').focus();
            $('#aiRESDestination').val(arrivalCity);
            $("[id='travelDate#trvDate_1'").focus();
            $("[id='travelDate#trvDate_1'").val(formatDate(departureDate));
            $('#trvDate_1').focus();
            $('#trvDate_1').val(departureDay.toString() + "-" + fixVNLMonth(departureMonth) + "-" + departureYear.toString());
            $('#aiRESAdult').focus();
            $('#aiRESAdult').val(adultCount);
            $('#aiRESChild').focus();
            $('#aiRESChild').val(childCount);
            $('#aiRESInfant').focus();
            $('#aiRESInfant').val(infantCount);
            $('#aiRESCurrency').focus();
            $('#aiRESCurrency').val('JP');
            $('#proceed').focus();
            $('#proceed').trigger('click');
            $('#hidCalLyr').hide();
            break;
        case 'search_from_flight_info_case_3':
            flight_info_s2 = strData.split('_');
            departureCity = flight_info_s2[7];
            arrivalCity = flight_info_s2[8];
            departureYear = parseInt(flight_info_s2[1]);
            departureMonth = parseInt(flight_info_s2[2]);
            departureDay = parseInt(flight_info_s2[3]);
            departureDate = new Date(departureYear, departureMonth - 1, departureDay);
            adultCount = parseInt(flight_info_s2[4]);
            childCount = parseInt(flight_info_s2[5]);
            infantCount = parseInt(flight_info_s2[6]);
            $('#owTripId').trigger('click');
            $('#aiRESOrigin').val(departureCity);
            $('#aiRESDestination').focus();
            $('#aiRESDestination').val(arrivalCity);
            $("[id='travelDate#trvDate_1'").focus();
            $("[id='travelDate#trvDate_1'").val(formatDate(departureDate));
            $('#trvDate_1').focus();
            $('#trvDate_1').val(departureDay.toString() + "-" + fixVNLMonth(departureMonth) + "-" + departureYear.toString());
            $('#aiRESAdult').focus();
            $('#aiRESAdult').val(adultCount);
            $('#aiRESChild').focus();
            $('#aiRESChild').val(childCount);
            $('#aiRESInfant').focus();
            $('#aiRESInfant').val(infantCount);
            $('#aiRESCurrency').focus();
            $('#aiRESCurrency').val('JP');
            $('#proceed').focus();
            $('#hidCalLyr').hide();
            break;
        case 'doneall':
            flight_info_s2 = strData.split('_');
            airlineID = flight_info_s1[0].toString();
            airlineNo = flight_info_s1[11].toString();
            ticketType = flight_info_s1[9].toString();

            departureYear = parseInt(flight_info_s1[1].toString());
            departureMonth = parseInt(flight_info_s1[2].toString());
            departureDay = parseInt(flight_info_s1[3].toString());
            departureDate = pad(departureMonth, 2) + pad(departureDay, 2);
            departureCity = flight_info_s1[7];
            arrivalCity = flight_info_s1[8];
            seatType = getSeatType(flight_info_s1[10]);

            $(document).load("http://smart-ticket.biz/agent/inquiry/search_list_ajax",
                {
                    type_flg: 'return',
                    select_air_company: '1',
                    select_data: departureDate,
                    select_dep_apo: departureCity,
                    select_arr_apo: arrivalCity,
                    select_seatkind: seatType
                }
            );
            $(document).ajaxComplete(function () {
                console.log('start select');
                selectFlight(airlineNo, airlineID, ticketType);
            });
            break;
    }
}

function checkMileageBTM(index) {
    var checkMileage = false;
    var isJAL = false;
    var isANA = false;
    if ($('select[name="application[service_type]"]').val() == 99) {
        if ($('#application_flight_list_' + index + '_airline_id_text').val() == 'ANA') {
            isANA = true;
        }

        if ($('#application_flight_list_' + index + '_airline_id_text').val() == 'JAL' || $('#application_flight_list_' + index + '_airline_id_text').val() == 'JTA' || $('#application_flight_list_' + index + '_airline_id_text').val() == 'JAC' || $('#application_flight_list_' + index + '_airline_id_text').val() == 'RAC') {
            isJAL = true;
        }

        for (i = 0; i <= 8; i++) {
            if ($('#application_traveller_list_' + i + '_ana_mileage_no').val() != '' && isANA) {
                checkMileage = 'ANA';
                break;
            }

            if ($('#application_traveller_list_' + i + '_jal_mileage_no').val() != '' && isJAL) {
                checkMileage = 'JAL';
                break;
            }
        }
    }
    return checkMileage;
}

//@Thuy >> Edit 2016-1-11
function getDomain() {
    CHROME_STORAGE.get(function (obj) {
        var domain_cms = obj['CMS_DOMAIN_STORAGE'];
        domain_cms = (domain_cms == '' || typeof (domain_cms) == 'undefined' ? 'https://opraws-dev.e-koukuuken.com' : domain_cms);
        console.log('temp:' + domain_cms);
        if ($('#domain_cms').length > 0) {
            $('#domain_cms').text(domain_cms);
			console.log('*******domain_cms*********:' + domain_cms);
        } else {
            $("body").append("<p id='domain_cms' style='display:none'>" + domain_cms + "</p>");
            //$( "body" ).append( "<input type='hidden' id='appId_cms'  value='" + app_id + "'>");
			app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			console.log('*******app_id*********:' + app_id);
            $( "body" ).append( "<input type='hidden' id='appId_cms'  value='" + app_id + "'>");
        }

    });
}

function setValue(key, value) {
    if (key) {
        xdLocalStorage.setItem(key, value, function (data) {
            if (data.success) {
                //console.log('Your data has been successfully stored.' + value);
            } else {
                //console.log('Ops, could not store your data.');
            }
        });
    } else {
        //console.log('You must enter a key.');
    }
}

function getValue(key) {
    if (key) {
        console.log(key);
        var a = xdLocalStorage.getItem(key, function (data) {
            //console.log(data);
            return data;
        })

        return a;
    } else {
        //console.log('You must enter a key.');
    }
}

function getItem(key, id_div, option, properties = null) {
    if (key) {

        var cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
        //var cms_app_id_new = $.trim(sessionStorage.getItem('cms_app_id_new'));
		//if(cms_app_id_new != "")
		//	cms_app_id = "#" + cms_app_id_new;
//alert("cms_app_id" + cms_app_id);
        if (cms_app_id != "") {
            key = cms_app_id + "_" + key;
        }

        xdLocalStorage.getItem(key, $.isFunction(id_div) ? id_div : function (data) {
            //console.log(key);
            //console.log(data.value + "id:" + id_div);
            if (!!data.value) {
				
                domain_name = document.domain;
                // normalize data before input to merchant
                // ANA only >>>
                if (domain_name == "aswbe-d.ana.co.jp" || domain_name == "rsv.starflyer.jp"
                    || domain_name == "resv.solaseedair.jp" || domain_name == "rsv.airdo.jp"
                    || domain_name == "smart-ticket.biz" || domain_name == "rsv.ibexair.co.jp") {
                    if (id_div.toString().indexOf('exCode') != -1 || id_div.toString().indexOf('rsv_sex') != -1) {
                        if (data.value == '1') {
                            data.value = 'M';
                        } else if (data.value == '2') {
                            data.value = 'F';
                        } else {
                            data.value = '';
                        }
                    } else if (id_div.toString().indexOf('paxInfantForm.infFirstName') != -1) {
                        nextVal = id_div.replace("paxInfantForm.infFirstName[", "");
                        nextVal = parseInt(nextVal.substring(0, 1));
                        id_nextVal = "paxInfantForm.parentPaxNo[" + nextVal.toString() + "]";
                        nextVal += 1;
                        $("[name='" + id_nextVal + "']").val(nextVal);
                    }
                }
                // HAC
                if (domain_name.indexOf('hac-air.co.jp')) {
                    if (id_div.toString().indexOf('gender') != -1) {
                        if (data.value == '1') {
                            data.value = 'MR';
                        } else if (data.value == '2') {
                            data.value = 'MS';
                        } else {
                            data.value = '';
                        }
                    } else if (id_div.toString().indexOf('].age') != -1 || id_div.toString().indexOf('].dateOfBirth') != -1) {
                        data.value = data.value.toString().replace('-', '').replace('-', '');
                    }
                }
                // <<< ANA only
                // @ThuyTQ
                // APJC only >>>

                if (domain_name == "book.flypeach.com") {
                    patt = new RegExp(/^hdTitle_[0-9]{1}$/);
                    res = patt.test(id_div);

                    //APJB
                    patt2 = new RegExp(/^txtTitle_[0-9]{1}$/);
                    res2 = patt2.test(id_div);

                    if (res || (id_div == "ctl00_stContactTitle") || res2) {
                        if (data.value == '1') {
                            data.value = 'MR|M';
                        } else if (data.value == '2') {
                            data.value = 'MS|F';
                        } else {
                            data.value = '';
                        }
                    }
                }

                // <<< APJC only
                // console.log('got value: "' + data.value + '" for key: "' + data.key + '"');
                switch (option) {
                    case 'mileage_ana':
                        if (data.value == 'ANA') {
                            $('#buttonPassenger').trigger('click');

                            setTimeout(function () {
                                $('#tabPassenger .section .btnArrowNext input').get(1).click();
                            }, CMS_TIMEOUT_INMILISECONDS);
                        }
                    case 'mileage_no_ana':
                        $('.customerName').each(function (index) {
                            arrData = data.value;
                            arrData = arrData.split('@');
                            arrName = arrData[0];
                            arrNo = arrData[1];
                            if ($.trim($(this).text()) == arrName + '様') {
                                if (arrNo) {
                                    $('select[name="paxPc:' + index + ':carrierCode"]').val('NH');
                                    $("[name='" + 'paxPc:' + index + ':userId' + "']").focus();
                                    $("[name='" + 'paxPc:' + index + ':userId' + "']").val(arrNo);
                                }
                            }
                        })
                    case 'mileage_jal':
                        if (data.value == 'JAL') {
                            setTimeout(function () {
                                $('.btn-03').get(0).click();
                            }, CMS_TIMEOUT_INMILISECONDS);
                        }
                    case 'mileage_no_jal':

                        arrData = data.value;
                        arrData = arrData.split('@');
                        arrName = arrData[0];
                        arrNo = arrData[1];
                        if (arrNo) {
                            console.log($('input[type="radio"][name="selectedAirline' + (parseInt(id_div) + 1) + '"][value="JMB"]'));
                            $('input[type="radio"][name="selectedAirline' + (parseInt(id_div) + 1) + '"][value="JMB"]').attr('checked', true);
                            $("[name='memberNo']").eq(id_div).focus();
                            $("[name='memberNo']").eq(id_div).val(arrNo);
                        }
                    case 'jalendinput':
                        $("[alt=入力内容の確認へ進む]").focus();
                        break;
                    case 'mailANA':
                        $("[name='" + id_div + "']").focus();
                        $("[name='" + id_div + "']").val(MAIL_BOOKING_ANA_JAL);
                        break;
                    case 'name':
                        $("[name='" + id_div + "']").focus();
                        $("[name='" + id_div + "']").val(data.value);
                        break;
                    case 'mailSNAaccount':
                        $("[name='" + id_div + "']").focus();
                        mailArr = data.value.split('@');
                        $("[name='" + id_div + "']").val(mailArr[0]);
                        break;
                    case 'mailSNAdomain':
                        $("[name='" + id_div + "']").focus();
                        mailArr = data.value.split('@');
                        $("[name='" + id_div + "']").val(mailArr[1]);
                        break;
                    case 'mailFDAaccount':
                        $("[name='" + id_div + "']").focus();
                        mailArr = data.value.split('@');
                        $("[name='" + id_div + "']").val(mailArr[0]);
                        break;
                    case 'mailFDAdomain':
                        $("[name='" + id_div + "']").focus();
                        mailArr = data.value.split('@');
                        $("[name='" + id_div + "']").val(mailArr[1]);
                        break;
                    case 'VNLconfirmdate':
                        $($('.' + id_div).get(0)).focus();
                        $($('.' + id_div).get(0)).val(data.value.replace(/-/g, '/'));
                        $($('.' + id_div).get(0)).focusout();
                    case 'name_jal':
                        $("[name='" + id_div + "']").focus();
                        $("[name='" + id_div + "']").val(data.value);
                        $("[name='" + id_div + "']").focusout();
                        break;
                    case 'radio':
                        $('input[type="radio"][name="' + id_div + '"][value="' + data.value + '"]').attr('checked', true);
                        break;
                    case 'select':
                        $("[name='" + id_div + "']").val(data.value);
                        break;
                    case 'selSexTitleAdult':
                        strTitle = data.value == 1 ? "MR" : "MS";
                        titleSexEleNames = id_div.split('|');
                        $("[name='" + titleSexEleNames[0] + "']").val(strTitle);
                        $("[name='" + titleSexEleNames[1] + "']").val(data.value);
                        break;
                    case 'sexJJP2':
                        $("[name='" + id_div + "']").val(data.value); //jjp 2 change design 20170329
                        break;
                    case 'selSexTitleChild':
                        strTitle = data.value == 1 ? "MSTR" : "MISS";
                        titleSexEleNames = id_div.split('|');
                        $("[name='" + titleSexEleNames[0] + "']").val(strTitle);
                        $("[name='" + titleSexEleNames[1] + "']").val(data.value);
                        break;
                    case 'selTitle':
                        strTitle = data.value == 1 ? "MR" : "MS";
                        $("[name='" + id_div + "']").val(strTitle);
                        break;
                    case 'selectTelephoneSNA':
                        $("[name='" + id_div + "']").val('K')
                        break;
                    case 'radioFDA':
                        $('input[type="radio"][name="' + id_div + '"][value="' + data.value + '"]').click();
                        break;
                    case 'radioSexORC':
                        let orcSexValue = 'F';
                        if (data.value == 1) {
                            orcSexValue = 'M';
                        }
                        $('input[type="radio"][name="' + id_div + '"][value="' + orcSexValue + '"]').click();
                        break;
                    case 'infCountOrc':
                        for (var i = 0; i < data.value; i++) {
                            $('select[name="' + id_div + '[' + i + ']"]').val(1);
                        }
                        break;
                    case 'selectFDA':
                        $("[name='" + id_div + "']").val(data.value).trigger('change');
                        var changeEvent = document.createEvent("HTMLEvents");
                        changeEvent.initEvent("change", true, true);
                        document.querySelector('[name="' + id_div + '"]').dispatchEvent(changeEvent);
                        break;
                    case 'selectDateFDA':
                        $("[name='" + id_div + "']").val(pad(parseInt(data.value), 2));
                        break;
                    case 'endConfirmFDA':
                        $("[type='checkbox']").click();
                        //$("[name='reservation'").trigger('click');
                        break;
                    case 'listTravellerFDA':
                        arrAdultChildIndex = data.value;
                        arrAdultChildIndex = arrAdultChildIndex.split(';');
                        arrAdult = arrAdultChildIndex[0].split('|');
                        arrChild = arrAdultChildIndex[1].split('|');
                        setTravellerFDA(arrAdult, arrChild);
                        break;
                    /*@ThuyTQ Edit 2016-03-17 >> */
                    case 'inputName':
                        $(id_div).val(data.value);
                        break;

                    case 'BTN_SEX':
                        if (data.value == "MR") {
                            if ($(id_div).is(':checked') === false) {
                                $(id_div).filter('[value=male]').attr('checked', true);
                                $(id_div).filter('[value=male]').parent('label').addClass('checked-s focus-s');
                            }
                        } else {
                            if ($(id_div).is(':checked') === false) {
                                $(id_div).filter('[value=female]').attr('checked', true);
                                $(id_div).filter('[value=female]').parent('label').addClass('checked-s focus-s');
                            }
                        }

                        //$(".h-adr input:radio[name='genderType']").filter('[value=female]').prop('checked', true)
                        break;

                    case 'BTN_SEX_HIDDEN':
                        if (data.value == "MR") {
                            type_sex = "M";
                        } else {
                            type_sex = "F";
                        }
                        $(id_div).val(type_sex);
                        break;

                    /*@ThuyTQ Edit 2016-03-17 << */

                    case 'YMD':
                        ymdString = data.value;
                        ymdEleNames = id_div.split('|');
                        if (checkYMDFormat(ymdString)) {
                            arrYmdVal = ymdString.split('-');
                            $("[name='" + ymdEleNames[0] + "']").val(parseInt(arrYmdVal[0]));
                            $("[name='" + ymdEleNames[1] + "']").val(parseInt(arrYmdVal[1]));
                            $("[name='" + ymdEleNames[2] + "']").val(parseInt(arrYmdVal[2]));
                        }
                        //@ThuyTQ Edit 2016-27-01 >>
                        else {
                            var str = ymdString.replace(/[^\d]/g, '')
                            var y = str[0] + str[1] + str[2] + str[3];
                            var m = str[4] + str[5];
                            var d = str[6] + str[7];
                            $("[name='" + ymdEleNames[0] + "']").val(parseInt(y));
                            $("[name='" + ymdEleNames[1] + "']").val(parseInt(m));
                            $("[name='" + ymdEleNames[2] + "']").val(parseInt(d));
                        }
                        //@ThuyTQ Edit 2016-27-01 <<
                        break;
                    case 'YMD_VNL':
                        ymdString = data.value;
                        ymdEleNames = id_div.split('|');
                        if (checkYMDFormat(ymdString)) {
                            arrYmdVal = ymdString.split('-');
                            $("#" + ymdEleNames[0]).val(parseInt(arrYmdVal[0]));
                            $("#" + ymdEleNames[1]).focus();
                            $("#" + ymdEleNames[1]).val(parseInt(arrYmdVal[1]));
                            $("#" + ymdEleNames[2]).focus();
                            $("#" + ymdEleNames[2]).val(parseInt(arrYmdVal[2]));
                            $("#" + ymdEleNames[3]).focus();
                            $temp = fixVNLMonth(parseInt(arrYmdVal[1]));
                            $temp = $temp.toString().toUpperCase();
                            console.log($temp);
                            $dateCompi = pad(parseInt(arrYmdVal[2]), 2) + '-' + $temp + '-' + pad(parseInt(arrYmdVal[0]), 4);
                            $("#" + ymdEleNames[3]).val($dateCompi);
                            $("#" + ymdEleNames[1]).focus();
                            //$("#"+ ymdEleNames[0]).trigger('change');
                        }
                        break;
                    //@Thuy
                    case 'Y/M/D':

                        ymdString = data.value;
                        if (checkYMDFormat(ymdString)) {
                            arrYmdVal = ymdString.split('-');
                            ymdString = arrYmdVal[0] + "/" + arrYmdVal[1] + "/" + arrYmdVal[2];
                            $("#" + id_div).val(ymdString);
                        } else {
                            var str = ymdString.replace(/[^\d]/g, '')
                            var y = str[0] + str[1] + str[2] + str[3];
                            var m = str[4] + str[5]
                            var d = str[6] + str[7]
                            ymdString = y + "/" + m + "/" + d;
                            console.log(ymdString);
                            $("#" + id_div).val(ymdString);
                        }
                        break;
                    //@Thuy

                    case 'TelMailJJP':
                        // by id
                        strVal = data.value.toString();
                        telNames = id_div.split('|');
                        if (strVal.substring(0, 1) == "0") {
                            strVal = strVal.substring(1);
                            $('#' + telNames[0]).val(strVal);
                            $('#' + telNames[1]).val(strVal);
                            $('#' + telNames[2]).val(strVal);
                        }
                        //strVal = "cc@tokyo-ogasawarakai.com";
                        //$('#ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxEmailAddress').val(strVal);
                        //$('#ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxEmailAddressConfirm').val(strVal);
                        break;

                    case 'setTravellerHAC':
                        setFncTravellerHAC(data.value, id_div);
                        break;
                    case 'setSmartTicket':
                        setFromAppliSmartTicket(data.value, id_div);
                        break;
                    case 'setLoginSmartTicket':
                        switch (data.value) {
                            case 'AG':
                                $("[name='account']").val(AG_GLB_ACCOUNT_SMART_TICKET);
                                $("[name='password']").val(AG_GLB_PASSWORD_SMART_TICKET);
                                break;
                            case 'EK':
                                $("[name='account']").val(EK_GLB_ACCOUNT_SMART_TICKET);
                                $("[name='password']").val(EK_GLB_PASSWORD_SMART_TICKET);
                                break;
                            case 'AC':
                                $("[name='account']").val(AC_GLB_ACCOUNT_SMART_TICKET);
                                $("[name='password']").val(AC_GLB_PASSWORD_SMART_TICKET);
                                break;
                            case 'SG':
                                $("[name='account']").val(SG_GLB_ACCOUNT_SMART_TICKET);
                                $("[name='password']").val(SG_GLB_PASSWORD_SMART_TICKET);
                                break;
                            case 'AX':
                                $("[name='account']").val(AX_GLB_ACCOUNT_SMART_TICKET);
                                $("[name='password']").val(AX_GLB_PASSWORD_SMART_TICKET);
                                break;
							case 'BTM':
                                $("[name='account']").val(BTM_GLB_ACCOUNT_SMART_TICKET);
                                $("[name='password']").val(BTM_GLB_PASSWORD_SMART_TICKET);
                                break;
                        }
                        setValue(cms_app_id + '_isLogInOK', '1');
                        $("form [src='http://smart-ticket.biz/agent/images/login_btn.gif']").trigger('click');
                        break;
                    case 'setLogoutSmartTicket':
                        if (data.value != '1') {
                            href = $('.logout').first().attr('href');
                            location.href = href;
                        }
                        break;

                    //SKY Satellite
                    case 'setLoginSkySatellite':
                        var arc = SKY_SATELLITE_ARC,
                            uid = SKY_SATELLITE_ID,
                            pwd = SKY_SATELLITE_PASSWORD;
                        if (data.value == 'BTM') {
                            arc = BTM_SKY_SATELLITE_ARC; 
                            uid = BTM_SKY_SATELLITE_ID;
                            pwd = BTM_SKY_SATELLITE_PASSWORD;
                        }
                        $("[name='arc']").val(arc);
                        $("[name='userid']").val(uid);
                        $("[name='password']").val(pwd);
                        
                        setValue(cms_app_id + '_isLogInOK', '1');
                        $("[name='attestation']").trigger('click');
                        break;
                    case 'setSkySatellite':
                        setFromAppliSkySatellite(data.value, id_div);
                        break;
					case 'setSkyConfirmSatellite':
                        setSkyConfirmSatellite(data.value, id_div);
                        break;
                    case 'setTravellerSkySatellite':
                        setFuncTravellerSkySatellite(data.value, id_div);
                        break;

                    case 'setVNL':
                        setFromAppliVNL(data.value, id_div);
                        break;
                    case 'ADO_attendantNumber':
                        id = id_div.replace("attendantNumber", "");
                        $("[name='" + id_div + "']").val(id);
                        break;
                    case 'endSetAnaTraveller':
                        $('#consentConfirmFlag').trigger('click');
                        break;
                    case 'setVNLMode':
                        if (data.value == 1) {
                            getItem("flight_info1", "search_from_flight_info1", "setVNL");
                            getItem("flight_info2", "search_from_flight_info2", "setVNL");
                        } else if (data.value == 2 || data.value == 3) {
                            getItem("flight_info1", "search_from_flight_info_case_2", "setVNL");
                        }
                        break;
                    case 'copyFromApplicationJJP':
                        $arrAdultChildIndex = data.value;
                        $arrAdultChildIndex = $arrAdultChildIndex.split(';');
                        $arrAdult = $arrAdultChildIndex[0].split('|');
                        $arrChild = $arrAdultChildIndex[1].split('|');
                        copyFromApplicationJJP($arrAdult, $arrChild);
                        break;
                    // 20170329 add more case for change design JJP
                    case 'copyFromApplicationJJP1':
                        $arrAdultChildIndex = data.value;
                        $arrAdultChildIndex = $arrAdultChildIndex.split(';');
                        $arrAdult = $arrAdultChildIndex[0].split('|');
                        $arrChild = $arrAdultChildIndex[1].split('|');
                        copyFromApplicationJJP1($arrAdult, $arrChild);
                        break;
                    case 'setFlightInformationJJP1':
                        depdes = data.value.split('→');
                        depAirport = $.trim(depdes[0]);
                        arrAirport = $.trim(depdes[1]);
                        setFlightInformationJJP1(depAirport, arrAirport);
                        break;
                    case 'copyFromApplicationVNL':
                        $arrAdultChildIndex = data.value;
                        $arrAdultChildIndex = $arrAdultChildIndex.split(';');
                        $arrAdult = $arrAdultChildIndex[0].split('|');
                        $arrChild = $arrAdultChildIndex[1].split('|');
                        copyFromAppliVNL($arrAdult, $arrChild);
                        break;
                    // CALLBACK BOOKING ANA
                    case 'merchant_flight_info_callback':
                        strDataCallBack = data.value;
                        strDataCallBack = strDataCallBack.split('|');
                        glbKubunId = strDataCallBack[2];
                        airport = strDataCallBack[3];
                        optionId = 'flight_info_' + glbKubunId;
                        if ($('#' + optionId + ' option').size() < 2) {
                            strDataCallBack = data.value;
                            strDataCallBack = strDataCallBack.split('|');
                            lastName = $('#application_traveller_list_0_last_name').val();
                            firstName = $('#application_traveller_list_0_first_name').val();
                            strValues = strDataCallBack[0].split(';');
                            strTexts = strDataCallBack[1].split(';');
                            app_id = $('#application_application_id').val();
							
							//SJO roundtrip check
							arr_strTexts = strTexts[0].split('/');
							console.log('********arr_strTexts************ ' + arr_strTexts);
							if(parseInt(arr_strTexts[0]) == 2 ){
								line_no = parseInt(glbKubunId) + 1;
								var mySelect1 = $('#flight_info_' + line_no);
								strValue = strValues[1];
                                strText = lastName + '/' + firstName + '/';
                                strText += strTexts[1];
                                mySelect1.append(
                                    $('<option></option>').val(strValue).html(strText)
                                );
							}
							
                            var mySelect = $('#flight_info_' + glbKubunId);
                            for (i = 0; i < strValues.length; i++) {
                                strValue = strValues[i];
                                strText = lastName + '/' + firstName + '/';
                                strText += strTexts[i];
                                mySelect.append(
                                    $('<option></option>').val(strValue).html(strText)
                                );

                                clearAll(app_id, glbKubunId);
                            }
                            console.log('merchant_flight_info_callback ' + 'carrier:' + airport + ' line_no:' + glbKubunId);
                        }
                        break;
                    case 'merchant_flight_info_callback_linkpayment':
                        //call back to cms 03
                        var hash_payment = data.value.split('#');
                        var url_payment = hash_payment[0];
                        var fligh_info = hash_payment[1].split('_');
                        var line_no = fligh_info[1];
                        var app_id = fligh_info[0];
                        //置換前
                        /*memo = $('#memo_text').val() + "\n" + url_payment;
                        $('#memo_text').val(memo);*/
                        //置換後
                        //console.log(line_no);
                        //console.log(line_no.indexOf('-'));

                        chrome.storage.sync.get('apj_add', function (result) {
                            var usemail = "cc@tokyo-ogasawarakai.com";
                            if (result.apj_add) {
                                usemail = result.apj_add;
                            }
                            if (line_no.indexOf('-') != -1) {
                                var line = line_no.split('-');
                                var memo = "区間" + (line[0] * 1 + 1) + "+区間" + (line[1] * 1 + 1) + ":" + usemail + "\n" + url_payment + "\n購入期限:" + fligh_info[3] + "\n\n" + $('#memo_text').val();
                            } else {
                                var memo = "区間" + (line_no * 1 + 1) + ":" + "\n" + url_payment + "\n" + usemail + "\n" + fligh_info[3] + "\n\n" + $('#memo_text').val();
                            }
                            $('#memo_text').val(memo);
                            //$('#memo_text').after('<textarea id="tmp" style="display:none;"></textarea>');
                            //$('#tmp').val(memo);
                        });
                        //ここまで
                        if (line_no.indexOf('-') != -1) {
                            line = line_no.split('-');
                            $('#application_flight_list_' + line[0] + '_lcc_kessai').val(url_payment);
                            $('#application_flight_list_' + line[1] + '_lcc_kessai').val(url_payment);
                        } else {
                            $('#application_flight_list_' + line_no + '_lcc_kessai').val(url_payment);
                        }
						console.log('***callback_linkpayment done*** ' + url_payment);
                        clearById('_merchant_flight_info_callback_linkpayment', app_id, line_no);
                        break;
                    case 'setTravellerSky':
                        setFuncTravellerSky(data.value, id_div);
                        break;
					case 'merchant_confirm_info_callback_skyconfirm':
						var hash_rsv = data.value.split('_');
						console.log('*********data.value***********hash_rsv done*** ' + hash_rsv[0]);
						var receipt_no_old = $('#' + hash_rsv[1]+'_ticket_receipt_no_0').val();
						console.log('*********receipt_no_old***********receipt_no_old done*** ' + receipt_no_old);
						$('#' + hash_rsv[1]+'_ticket_receipt_no_0').val(hash_rsv[0]);
						if(hash_rsv[0] != '' && receipt_no_old != hash_rsv[0]){
							var today = new Date();
							var date = today.getFullYear() + '/' + (today.getMonth()+1) + '/' + today.getDate() + ' ' + today.getHours() + ':' + today.getMinutes();
							var memo = "▼" + date + "\n" +  "区間" + (hash_rsv[1] * 1 + 1) + ":SKY手動発券" + "\n" + "承認番号：" + hash_rsv[0] + "\n\n" + $('#memo_text').val();
							$('#memo_text').val(memo);
							$("#bt_updateEdit2").trigger('click');
						}
						xdLocalStorage.removeItem(hash_rsv[2]+'_merchant_confirm_info_callback_rsv'+ hash_rsv[1], function (data) {});
						break;
                    case 'setConfirmSky':
                        $("[name='sky2'] table").find("[name='" + id_div + "']").val(data.value);

                        var changeEvent = document.createEvent("HTMLEvents");
                        changeEvent.initEvent("change", true, true);
                        document.querySelector("[name='sky2'] [name='month']").dispatchEvent(changeEvent);

                        if (id_div == 'firstname') {
                            $("[name='sky2']").find(".bottomButtonSpace [type='image']").trigger('click');
                        }
                        break;

                    case 'endConfirmAna':
                        $("[name='btnchg_searchZZZZZMappingZZZZZmob_chg_pnr']").trigger('click');
                        break;
                    case 'endCancelADO':
                        $("[type='submit']").trigger('click');
                        break;
                    case 'endSearchHAC':
                        $("[name='forward_next']").trigger('click');
                        break;
                    // END CONFIRM APJC

                    case 'endConfirmJal':
                        airlineName = data.value;
                        if (airlineName == 'JTA' || airlineName == 'RAC') {
                            $("[name='carrierCode']").val('NU');
                        } else if (airlineName == 'JAL') {
                            $("[name='carrierCode']").val('JL');
                        } else {
                            $("[name='carrierCode']").val('JC');
                        }
                        $("[name='reserveSearch']").submit();
                        break;
                    case 'endConfirmSFJ':
                        //click button 次へ
                        $("[name='btnSubmit:mapping=success&rt=rt_rsvno&parameter=loc_search'").trigger('click');
                        break;
                    case 'endConfirmIBX':
                        $("[name='btnSubmit:mapping=success'").trigger('click');
                        break;
                    case 'endConfirmADO':
                        $("[type='checkbox'").prop('checked', true);
                        //$("[name='reservation'").trigger('click');
                        break;
                    case 'endConfirmSNA':
                        //click button 次へ
                        $("[name='consentConfirmFlag'").trigger('click');
                        break;
                    //@Thuy only APJC >>
                    case "endParseAdultAPJB":
                    case "endParseAdultAPJC":
                        $('.PaxAdult:eq(' + id_div + ')').trigger('click');
                        break;
                    case "endParseChildrenAPJB":
                    case "endParseChildrenAPJC":
                        $('.PaxChildren:eq(' + id_div + ')').trigger('click');
                        break;
                    case "endParseInfantAPJB":
                    case "endParseInfantAPJC":
                        $('.PaxInfant:eq(' + id_div + ')').trigger('click');
                        break;
                    case 'setSearchTravelagent':
                        setFromAppliTravelagent(data.value, id_div, properties);
                        break;
                    case 'Booking_Passengers_Birthday_TravelAgent':
                        if (data.value != '--') {
                            let birthday = data.value;
                            birthday = birthday.replace(/-/g, '/');
                            $('[name=' + id_div + ']').val(birthday);
                            $('[name=' + id_div + ']').focus();
                            var changeEvent = document.createEvent("HTMLEvents");
                            changeEvent.initEvent("change", true, true);
                            document.querySelector("[name='" + id_div + "']").dispatchEvent(changeEvent);
                        }
                        break;
                    case 'Booking_Passengers_Title_TravelAgent':
                        let title = 'MS';
                        if (data.value == 1) {
                            title = 'MR';
                        }
                        let titleSelect = $('#' + id_div).parent().find('select');
                        if (titleSelect.length > 0) {
                            titleSelect.val(title);
                        }
                        $('#' + id_div).val(title);
                        break;
                    case 'Booking_Passengers_Title_Infant_TravelAgent':
                        let titleInfant = 'MISS';
                        if (data.value == 1) {
                            titleInfant = 'MSTR';
                        }
                        let titleInfantSelect = $('#' + id_div).parent().find('select');
                        if (titleInfantSelect.length > 0) {
                            titleInfantSelect.val(titleInfant);
                        }
                        $('#' + id_div).val(titleInfant);
                        break;
					case 'pnr_jjp'://jjp reactjs render form
						var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
						nativeInputValueSetter.call(document.querySelector("[name='" + id_div +"']"), data.value);
						document.querySelector("[name='" + id_div +"']").dispatchEvent(new Event('input', { bubbles: true}));
						break;
					case 'pnr_apj_id'://apj reactjs render form
						//$('#' + id_div).focus();
						//$('#' + id_div).val(data.value);
						var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
						nativeInputValueSetter.call(document.querySelector("#" + id_div), data.value);
						document.querySelector("#" + id_div ).dispatchEvent(new Event('input', { bubbles: true}));
						
						//nativeInputValueSetter.call(document.querySelector('[id^="'+ id_div +'"]'), data.value);
						//document.querySelector('[id^="'+ id_div +'"]').dispatchEvent(new Event('input', { bubbles: true}));
						
						console.log(id_div + "*********************" + data.value);
						break;
					case 'pnr_jjp_btn':
						document.querySelector('.' + id_div).click();
						break;
					case 'login_sjo':
							//var str_val = '';
							//if(id_div == 'UserNameInput'){
							//	str_val = 'td-airivory@his-world.com';
							//} else {
							//	str_val = '543972';
							//}
							////$('input[name="'+ id_div +'"]').val(str_val);
							//var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
							//nativeInputValueSetter.call(document.querySelector("[name='" + id_div +"']"), str_val);
							//document.querySelector("[name='" + id_div +"']").dispatchEvent(new Event('input', { bubbles: true}));
							//console.log("***id_div*****" + id_div + "**str_val**" + str_val);
						break;
					case 'searchSJOHIS':
                        flight_info_s1 = data.value.split('_');
						$("#adultNum").val(flight_info_s1[4]);
						$("#childNum").val(flight_info_s1[5]);
						$("#infantNum").val(flight_info_s1[6]);
						$("#OriCityCode").val(flight_info_s1[7]);
						$("#DestCityCode").val(flight_info_s1[8]);
						$("#FLY_TIME").val(flight_info_s1[1] + '-' + pad(flight_info_s1[2],2) + '-' + pad(flight_info_s1[3],2));
						$('#btnSearch').trigger('click');
                        break;
					case 'data-name':
						if(id_div=='Nationality'){
							if(data.value == '')
								data.value = 'JPN';
						}
						line_no = parseInt(properties);
						if(line_no == 99){
							$("[data-name='" + id_div + "']").val(data.value);
							//$("[data-name='" + id_div + "']").focus();
							//$("[data-name='" + id_div + "']").parent().addClass('current');
							
							console.log($(id_div + '*********properties-if*********'+ properties + '*****' + data.value));
							
							$("[data-name='" + id_div + "']").blur();
							$("[data-name='" + id_div + "']").change();
							//$("[data-name='" + id_div + "']").trigger('click');
							$("[data-name='" + id_div + "']").focus();
							$("[data-name='" + id_div + "']").trigger('keyup');
							$("[data-name='" + id_div + "']").keyup();
							
						} else if(line_no < 99) {
							str = ".passenger-item[data-index='" + line_no + "'] input[data-name='" + id_div + "']";
							console.log('*********str*********'+ str + '*****' + data.value);
							//var laststr = key.substr(key.length - 1);//
							//var elm = $(".passenger-item").find("[data-index='" + properties + "'];
							//$(".passenger-item[data-index='" + properties + "'] > input[data-name='" + id_div + "']").focus();
							//$(".passenger-item[data-index='" + line_no + "'] input[data-name='" + id_div + "']").val(data.value);
							//$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").focus();
							//$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item span.c-placeholder").addClass('active');
							//$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item span.c-placeholder").text('input');
							//$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").trigger('click');
							
							$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").focus();
							if(id_div == 'Birthday'){
								console.log(key + '***********************' + data.value);
								tmp = data.value;
								str_birtday = tmp.split('-');
								
								$(".passenger-item[data-index='" + line_no + "'] .J-year").trigger('click');
								$(".passenger-item[data-index='" + line_no + "'] .J-year").addClass('hasVal');
								$(".passenger-item[data-index='" + line_no + "'] .J-year").text(parseInt(str_birtday[0]));
								
								$(".passenger-item[data-index='" + line_no + "'] .J-month").trigger('click');
								$(".passenger-item[data-index='" + line_no + "'] .J-month").addClass('hasVal');
								$(".passenger-item[data-index='" + line_no + "'] .J-month").text(parseInt(str_birtday[1]));
								
								$(".passenger-item[data-index='" + line_no + "'] .J-date").trigger('click');
								$(".passenger-item[data-index='" + line_no + "'] .J-date").addClass('hasVal');
								$(".passenger-item[data-index='" + line_no + "'] .J-date").text(parseInt(str_birtday[2]));
								//$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").focus();
							}
							
							var nindex = line_no * 2;
							var gindex = nindex + 1;
							if(id_div == 'Gender'){
								$(".u-select-list").eq(gindex).toggle();
							}
							$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").val(data.value);
							
							//if(id_div == 'Birthday'){
								//$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").focusout();
								//$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").blur();
								
							//}
							
							if(id_div == 'Gender'){
								$(".u-select-direct").eq(gindex).trigger('click');
								//if(data.value == '2'){
								//	$(".u-select-view").eq(gindex).html('女');
								//	$(".u-select-view").eq(gindex).attr('title','女');
								//} else {
								//	$(".u-select-view").eq(gindex).html('男');
								//	$(".u-select-view").eq(gindex).attr('title','男');
								//}
								////$(".u-select-view").eq(gindex).trigger('click');
								//$(".u-select-view").eq(gindex).blur();
								//$(".u-select-view").eq(gindex).change();
								//$(".u-select-list").eq(gindex).css('display','none');
								var txt = '男';
								if(data.value == '2'){
									 txt = '女';
								}
								$(".u-select-view").eq(gindex).html(txt);
								$(".u-select-list").eq(gindex).toggle();
								//$(".u-select").eq(gindex).mouseout();
								
							}
							if(id_div == 'Nationality'){
								$(".u-select-view").eq(nindex).html('日本');
								$(".u-select-view").eq(nindex).attr('title','日本');
								$(".u-select-view").eq(nindex).trigger('click');
								$(".u-select-view").eq(nindex).blur();
								$(".u-select-view").eq(nindex).trigger('keyup');
								$(".u-select-view").eq(nindex).keyup();
								$(".u-select .u-select-active").eq(nindex).mouseout();
								$(".u-select .u-select-active").eq(nindex).mouseover();
								$(".u-select-list").eq(nindex).hide();
								
								//$(".u-select").eq(nindex).toggle(
								//	function() {
								//		$( this ).addClass( "active u-select-active" );
								//		$(".u-select-view").eq(nindex).html('日本');
								//		$(".u-select-view").eq(nindex).attr('title','日本');
								//	}, function() {
								//		$( this ).removeClass( "active u-select-active" );
								//	}
								//);
							}
							
							$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").change();
							$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").trigger('click');
							$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").focus();
							$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").trigger('keyup');
							$(".passenger-item[data-index='" + line_no + "'] .passenger-form .inp-item input[data-name='" + id_div + "']").keyup();
							
						}
                        break;
					case 'appId_cms'://set reserveNo sjo to localstorage
						var appid_lineno = data.value.split('-');
						console.log( appid_lineno + '******appid_lineno*********' + data.value + '*********reserveNo*********' + properties);
						if(appid_lineno.length > 1){
							cms_app_id = appid_lineno[0];
							line_no = appid_lineno[1].split('_');//0_98
							//step01
							//properties is reserveNo
							setValue(cms_app_id +'_sjo_callback_reserveNo' + line_no[0], properties + "-" + appid_lineno[1]);
						}
						break;
					case 'merchant_flight_info_callback_reserveNo':
                        //call back to cms to set reserveNo
						//step03
						xdLocalStorage.removeItem("app_id_SJO_lineno", function (data) {});
                        let str_arr = data.value.split('-');
						let reserveNo = str_arr[0];
						let lineno = str_arr[1].split('_');
						if (lineno.length > 1){
							//application_flight_list_0_ticket_reservation_no
							line_no1 = parseInt(lineno[0]) + 1;
							$('#application_flight_list_' + lineno[0] + '_ticket_reservation_no').val(reserveNo);
							$('#application_flight_list_' + line_no1 + '_ticket_reservation_no').val(reserveNo);
						} else {
							$('#application_flight_list_' + lineno[0] + '_ticket_reservation_no').val(reserveNo);
						}
                        removeItem('app_id_SJO_lineno');
                        break;
                    case 'id_jal':
                        $('#' + id_div).val(data.value);
                        $('#' + id_div).focus();
						console.log(id_div + '**********' + data.value);
                        break;
					case 'id_jal_span':
						if(id_div =='date'){
							var weekday = ["日","月","火","水","木","金","土"];
							var date_str = data.value.replace(/-/g, '/');
							var date = new Date(date_str);
							//var date = data.value.substring(0,4) + '/ ' + data.value.substring(5,7)+ '/ ' + data.value.substring(8,10);
							dayofw = weekday[date.getDay()];
							properties =  data.value.substring(5,7) + '月' + data.value.substring(8,10) + '日（' + dayofw + '）';
						}
						$('#' + id_div).html(properties);
						//console.log(id_div + '**********' + properties);
                        break;
                    case 'id_jal_date_calendar':
                        var weekday = ["日","月","火","水","木","金","土"];
                        var date_str = data.value.replace(/-/g, '/');
                        var date = new Date(date_str);
                        dayofw = weekday[date.getDay()];
                        var array_date = data.value.split("/");
                        text_display_date =  array_date[1] + '月' + array_date[2] + '日（' + dayofw + '）';
                        $('.' + id_div).html(text_display_date);
                        if (properties == 'board') {
                            $("input[name=boardYear]").val(array_date[0]);
                            $("input[name=boardMonth]").val(array_date[1]);
                            $("input[name=boardDay]").val(array_date[2]);
                        }
                        break;
                    case 'id_ana_date':
                        var weekday = ["日","月","火","水","木","金","土"];
                        var date_str = data.value.replace(/-/g, '/');
                        var date = new Date(date_str);
                        dayofw = weekday[date.getDay()];
                        var array_date = data.value.split("/");
                        properties = array_date[0] + '年' + array_date[1] + '月' + array_date[2] + '日(' + dayofw + ')';
                        $('#' + id_div).val(properties);
                        break;
                    case 'id_jal_new':
                        $('#' + id_div).val(data.value);
                        $('#' + id_div)[0].dispatchEvent(new Event("input", { bubbles: true }));
                        //$('#' + id_div).focus();
                        console.log(id_div + '**********' + data.value);
                        break;
                    case 'id_jal_new_datepicker':
                        if(id_div =='date'){
                            var date_str = data.value.replace(/-/g, '/');
                            var date = new Date(date_str);

                            $('#boarding-date-field').click();
                            // dateId-2023-8-1
                            var targetMonth = 'dateId-' + date.getFullYear() +'-' + (date.getMonth() + 1) + '-1';
                            var targetDate = date.getDate() + '-' + (date.getMonth() + 1) + '-' + date.getFullYear();
                            var monthObj;
                            for (var i = 0; i <= 12; i++) {
                                var months = $('ngb-datepicker-month', '.ngb-dp-month');
                                months.each(function (key, item){
                                    if ($(item).attr('id') == targetMonth) {
                                        monthObj = $(item);
                                        return;
                                    }
                                });

                                if (!monthObj) {
                                    $('.ngb-dp-arrow.right')[0].dispatchEvent(new Event("click", { bubbles: true }));
                                } else {
                                    break;
                                }
                            }
                            if (monthObj) {
                                var dateObj = $(monthObj).find('div.ngb-dp-day');
                                dateObj.each(function (key, item){
                                    if ($(item).attr('aria-label') == targetDate) {
                                        $(item)[0].dispatchEvent(new Event("click", { bubbles: true }));
                                        $('#confirm-button')[0].dispatchEvent(new Event("click", { bubbles: true }));
                                    }
                                });
                            } else {
                                $('#confirm-button')[0].dispatchEvent(new Event("click", { bubbles: true }));
                            }
                        }
                        break;
                    case 'id_jal_new_carrier':
                        $('#selectedvalue-Airline').click();
                        
                        if (properties == 'JAL') {
                            $('input:radio[name=mat-radio-group-0]:eq(0)').prop('checked', true)[0].dispatchEvent(new Event("change", { bubbles: true }));
                        } else {
                            $('input:radio[name=mat-radio-group-0]:eq(1)').prop('checked', true)[0].dispatchEvent(new Event("change", { bubbles: true }));
                        }
                        $('#confirm-dialog')[0].dispatchEvent(new Event("click", { bubbles: true }));
                        break;
                    default:
                        $('#' + id_div).val(data.value);
                        $('#' + id_div).focus();
                        //console.log($('#'+id_div));
                        break;
                }

                if (typeof (option) != 'undefined' && option.indexOf('Start') != -1) {
                    // $("[name=form_search]").append("<input type='hidden' id='glbCurAirport' name='glbCurAirport' value=''/>");
                    // $("[name=form_search]").append("<input type='hidden' id='glbKubunId' name='glbKubunId' value=''/>");
                }
            }
        });
    } else {
        //console.log('You must enter a key to get.');
    }
}

function removeItem(key) {
    if (key) {
        xdLocalStorage.removeItem(key, function (data) {
            // console.log('Key was removed');
        });
    } else {
        //console.log('You must enter a key to remove.');
    }
}

function keyName(index_keyNameInput) {
    if (index_keyNameInput) {
        xdLocalStorage.key(index_keyNameInput, function (data) {
            return data.key;
        });
    } else {
        // console.log('Key was removed');
    }
}

function clearAllData() {
    xdLocalStorage.clear(function (data) {
        $now = new Date();
        $now = '' + $now.getFullYear() + '-' +
            pad($now.getMonth() + 1, 2) + '-' +
            pad($now.getDate(), 2) + ' ' +
            pad($now.getHours(), 2) + ':' +
            pad($now.getMinutes(), 2) + ':' +
            pad($now.getSeconds(), 2);
        console.log('LocalStorage was cleared at ' + $now);
    });
}

function clearById(id, app_id, line_no) {
    key = "#" + app_id + id + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
}

function clearAll(app_id, line_no) {
    for (i = 0; i < 9; i++) {
        key = "#" + app_id + "_application_traveller_list_" + i + "_last_name";
        xdLocalStorage.removeItem(key, function (data) {
        });
        key = "#" + app_id + "_application_traveller_list_" + i + "_first_name";
        xdLocalStorage.removeItem(key, function (data) {
        });
        key = "#" + app_id + "_application_traveller_list_" + i + "_age";
        xdLocalStorage.removeItem(key, function (data) {
        });
        key = "#" + app_id + "_application_traveller_list_" + i + "_sex";
        xdLocalStorage.removeItem(key, function (data) {
        });
        key = "#" + app_id + "_application_traveller_list_" + i + "_birthday";
        xdLocalStorage.removeItem(key, function (data) {
        });
        key = "#" + app_id + "_application_traveller_list_" + i + "_first_name_rome";
        xdLocalStorage.removeItem(key, function (data) {
        });
        key = "#" + app_id + "_application_traveller_list_" + i + "_last_name_rome";
        xdLocalStorage.removeItem(key, function (data) {
        });
        key = "#" + app_id + "_sex" + i;
        xdLocalStorage.removeItem(key, function (data) {
        });
        key = "#" + app_id + "_application_traveller_list_" + i + "_name_ana";
        xdLocalStorage.removeItem(key, function (data) {
        });
        key = "#" + app_id + "_application_traveller_list_" + i + "_name_jal";
        xdLocalStorage.removeItem(key, function (data) {
        });
    }

    for (i = 0; i < 2; i++) {
        key = "#" + app_id + "_application_infant_list_" + i + "_last_name";
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_application_infant_list_" + i + "_first_name";
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_application_infant_list_" + i + "_age";
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_application_infant_list_" + i + "_sex";
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_application_infant_list_" + i + "_birthday";
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_application_infant_list_" + i + "_first_name_rome";
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_application_infant_list_" + i + "_last_name_rome";
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_sex" + i;
        xdLocalStorage.removeItem(key, function (data) {});

        key = "#" + app_id + "_inf_lname" + i;
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_inf_fname" + i;
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_inf_age" + i;
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_inf_sex" + i;
        xdLocalStorage.removeItem(key, function (data) {});
        key = "#" + app_id + "_inf_pax" + i;
        xdLocalStorage.removeItem(key, function (data) {});
		key = "#" + app_id + "_guardian_no_" + i;
        xdLocalStorage.removeItem(key, function (data) {});
    }
    key = "#" + app_id + "_application_adult_list";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_child_a_list";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_child_b_list";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_child_list";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_adult_count";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_child_a_count";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_child_b_count";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_child_count";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_traveller_list_adult_child_index";
    xdLocalStorage.removeItem(key, function (data) {
    });

    key = "#" + app_id + "_reserve_email_jjp";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_glb_cmslink";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_isLogInOK";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_infant_list";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_infant_count";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_tel1";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_zip_code";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_reserve_email";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_assistMailAccount";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_assistMailDomain";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_sendMailId";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_mail1";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_common_email";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_sky_email";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_yoyaku_email_first";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_yoyaku_email_next";
    xdLocalStorage.removeItem(key, function (data) {
    });

    key = "#" + app_id + "_mail";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_tel";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_tel1";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_tel2";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_address2";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_address3";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_address4";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_flight_airport_name";
    xdLocalStorage.removeItem(key, function (data) {
    });

    key = "#" + app_id + "_merchant_flight_info_callback" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_first_name" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_last_name" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_first_name_rome" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_last_name_rome" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_airline_name" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_flight_no" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_flight_year" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_flight_month" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_flight_day" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_flight_date" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_flight_date_full" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = app_id + "_application_ticket_reservation_no" + line_no;
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_flight_info0";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_flight_info1";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_VNLMode";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_service";
    xdLocalStorage.removeItem(key, function (data) {
    });
    key = "#" + app_id + "_application_mileage_flag" + line_no;
    xdLocalStorage.removeItem(key, function (data) {});
	key = "#" + app_id + "_sjo_callback_reserveNo" + line_no;
    xdLocalStorage.removeItem(key, function (data) {});
}

// common part >>>
function keydown(e) {
    if (e.keyCode == 116) {
        clearAll();
    }
};

///////////////

///////////////
setTimeout(function () {
    loc = window.location;
    $(document).ready(function () {
        // $(document).on("keydown", keydown);
        domain_name = document.domain;
        //setFlightInformationAdo111();

        //return;
        //@Thuy Edit 2016-25-01
        if (CMS_DOMAIN.indexOf(domain_name) > -1) {
            //if( domain_name== CMS_DOMAIN) {
            loc = window.location;
            if (loc.toString().indexOf('/s/appli/application/edit') != -1 || loc.toString().indexOf('/s/appli/application/clone') != -1) {

                // BOOKING >>>>>>
                $("[id^='airline_link_']").click(function () {
                    // check click right link
                    currentId = this.id;
                    // console.log(this.id);
                    arrSplitId = currentId.split('_');
                    if (arrSplitId.length < 4) {
                        return;
                    }
                    kubun_id = currentId.toString().replace('airline_link_', '');
                    kubun_id = kubun_id.substring(0, 1);
                    $('#glbKubunId').val(arrSplitId[2]);
                    $('#glbCurAirport').val(arrSplitId[3]);
                    // Set value to merchant parsing >>>>
                    clearAll();
                    // 代表者名 part >>
console.log("************kubun_id**"+kubun_id + "******glbKubunId***"+arrSplitId[2]+"**glbCurAirport***" + arrSplitId[3]);
                    var adultCount = 0;
                    var childCount = 0;
                    var childCountA = 0;
                    var childCountB = 0;
                    var infantCount = 0;
                    var adultList = "";
                    var childAList = "";
                    var childBList = "";
                    var infantList = "";
                    var childList = "";
                    var app_id = "";

                    //sessionStorage.setItem('cms_app_id', 12345);
                    //sessionStorage.getItem('cms_app_id');

                    app_id = "#" + $('#application_application_id').val();

                    for (i = 0; i <= 8; i++) {
                        lname = $('#application_traveller_list_' + i + '_last_name').val();
                        fname = $('#application_traveller_list_' + i + '_first_name').val();
                        setValue(app_id + '_application_traveller_list_' + i.toString() + '_last_name', lname);
                        setValue(app_id + '_application_traveller_list_' + i.toString() + '_first_name', fname);
                        nameEleAge = "application[traveller_list][" + i.toString() + "][age]";
                        setValue(app_id + '_application_traveller_list_' + i.toString() + '_age', $("[name='" + nameEleAge + "']").val());
                        nameEleSex = "application[traveller_list][" + i.toString() + "][sex]";
                        setValue(app_id + '_application_traveller_list_' + i.toString() + '_sex', $("[name='" + nameEleSex + "']:checked").val());

                        // set birthday
                        setValue(app_id + '_application_traveller_list_' + i.toString() + '_birthday', fixFormatDate($('#application_traveller_list_' + i.toString() + '_birthday').val()));
						// set Nationality
                        setValue(app_id + '_application_traveller_list_' + i.toString() + '_national', fixFormatDate($('#application_traveller_list_' + i.toString() + '_national').val()));

                        // set romaji
                        setValue(app_id + '_application_traveller_list_' + i.toString() + '_first_name_rome', convKata2Romaji(fname, $('#application_traveller_list_' + i.toString() + '_first_name_rome').val()));
                        setValue(app_id + '_application_traveller_list_' + i.toString() + '_last_name_rome', convKata2Romaji(lname, $('#application_traveller_list_' + i.toString() + '_last_name_rome').val()));


                        // Thanh

                        var tmpsex = $('input[name = "application[traveller_list][' + i + '][sex]"]:checked').val();
                        if (lname != "" && fname != "") {
                            if (tmpsex == 1) {
                                setValue(app_id + "_sex" + i, "M");
                            } else {
                                setValue(app_id + "_sex" + i, "F");
                            }
                        }

                        var tmpage = $('#application_traveller_list_' + i + '_age').val();
                        if (lname != "" && fname != "") {
                            if (tmpage >= 12) {
                                adultList += i.toString() + ",";
                                adultCount++;
                            } else if (tmpage >= 8) {
                                childAList += i.toString() + ",";
                                childList += i.toString() + ",";
                                childCountA++;
                            } else if (tmpage >= 3) {
                                childBList += i.toString() + ",";
                                childList += i.toString() + ",";
                                childCountB++;
                            }
                        }
                    }

                    setValue(app_id + '_application_adult_list', adultList);
                    setValue(app_id + '_application_child_a_list', childAList);
                    setValue(app_id + '_application_child_b_list', childBList);
                    setValue(app_id + '_application_child_list', childList);

                    setValue(app_id + '_application_adult_count', adultCount);
                    setValue(app_id + '_application_child_a_count', childCountA);
                    setValue(app_id + '_application_child_b_count', childCountB);
                    setValue(app_id + '_application_child_count', childCountA + childCountB);

                    //FDA, SNA
                    setValue(app_id + '_guardian_no_0', 1);
                    setValue(app_id + '_guardian_no_1', 2);

                    setValue(app_id + '_application_traveller_list_adult_child_index', '' + getStringAdultChildIndex());
                    for (i = 0; i <= 1; i++) {
                        inf_lname = $('#application_infant_list_' + i + '_last_name').val();
                        inf_fname = $('#application_infant_list_' + i + '_first_name').val();
                        setValue(app_id + '_application_infant_list_' + i.toString() + '_first_name', inf_fname);
                        setValue(app_id + '_application_infant_list_' + i.toString() + '_last_name', inf_lname);
                        // birthday
                        setValue(app_id + '_application_infant_list_' + i.toString() + '_birthday', fixFormatDate($('#application_infant_list_' + i + '_birthday').val()));
						// set Nationality
                        setValue(app_id + '_application_infant_list_' + i.toString() + '_national', fixFormatDate($('#application_infant_list_' + i.toString() + '_national').val()));

                        // romaji
                        setValue(app_id + '_application_infant_list_' + i.toString() + '_first_name_rome', convKata2Romaji(inf_fname, $('#application_infant_list_' + i.toString() + '_first_name_rome').val()));
                        setValue(app_id + '_application_infant_list_' + i.toString() + '_last_name_rome', convKata2Romaji(inf_lname, $('#application_infant_list_' + i.toString() + '_last_name_rome').val()));

                        nameEleAge = "application[infant_list][" + i.toString() + "][age]";
                        setValue(app_id + '_application_infant_list_' + i.toString() + '_age', $("[name='" + nameEleAge + "']").val());
                        nameEleSex = "application[infant_list][" + i.toString() + "][sex]";
                        setValue(app_id + '_application_infant_list_' + i.toString() + '_sex', $("[name='" + nameEleSex + "']:checked").val());
                        // ThanhNV >>>

                        setValue(app_id + "_inf_lname" + i, inf_lname);
                        setValue(app_id + "_inf_fname" + i, inf_fname);
                        setValue(app_id + "_inf_age" + i, $('#application_infant_list_' + i + '_age').val());
                        var tmpsex = $('input[name = "application[infant_list][' + i + '][sex]"]:checked').val();
                        if (inf_lname != "" && inf_fname != "") {
                            if (tmpsex == 1) {
                                setValue(app_id + "_inf_sex" + i, "M");
                            } else {
                                setValue(app_id + "_inf_sex" + i, "F");
                            }
                        }
                        // ThanhNV
                        if (inf_lname != "" && inf_fname != "") {
                            infantList += i.toString() + ",";
                            infantCount++;
                        }
                        setValue(app_id + "_inf_pax" + i, i + 1);
                    }


                    setValue(app_id + '_reserve_email_jjp', $('#reserve_email_jjp').val()); // 20170419
                    setValue(app_id + '_glb_cmslink', $('#cmslink').val());
                    var service_type = $('select[name="application[service_type]"]').val();
                    if ($('#cmslink').val() == "AG" && service_type == 34) {
                        setValue(app_id + '_glb_cmslink', "AC");
                    } else if ($('#cmslink').val() == "AG" && service_type == 99) {
						setValue(app_id + '_glb_cmslink', "BTM");//#27639
					}
                    setValue(app_id + '_isLogInOK', '0');
                    setValue(app_id + '_application_infant_list', infantList);
                    setValue(app_id + '_application_infant_count', infantCount);
                    setValue(app_id + '_application_tel1', $('#application_tel1').val());
                    setValue(app_id + '_application_zip_code', $('#application_zip_code').val().toString().replace('-', '').replace('－', ''));
                    // setValue(app_id + '_application_tel1_not0', $('#application_tel1').val().toString.substring(1));
                    arrayMail = $('#reserve_email').val().toString().split('@');
                    setValue(app_id + '_reserve_email', $('#reserve_email').val());
                    setValue(app_id + '_application_assistMailAccount', arrayMail[0]);
                    setValue(app_id + '_application_assistMailDomain', arrayMail[1]);
                    setValue(app_id + '_application_sendMailId', '1');
                    setValue(app_id + '_application_mail1', $('#application_email').val());
                    setValue(app_id + '_application_common_email', $('#mail').val());
                    setValue(app_id + '_application_sky_email', $('#sky_mail').val());
                    $arrMailYoyaku = $('#sky_mail').val().toString().split('@');
                    setValue(app_id + '_application_yoyaku_email_first', $arrMailYoyaku[0]);
                    setValue(app_id + '_application_yoyaku_email_next', $arrMailYoyaku[1]);
                    // ThanhNV
                    setValue(app_id + "_mail", $('#mail').val());
                    var tel = $('#application_tel1').val();
                    //tel = tel.replace(/[-]/g, "");
                    tel = tel.split("-").join("");
                    if (tel == "0334316280") {
                        tel1 = "03";
                        tel2 = "3431";
                        tel3 = "6280";
                    } else {
                        tel1 = tel.substring(0, 3);
                        tel2 = tel.substring(3, 7);
                        tel3 = tel.substring(7);
                    }
                    setValue(app_id + "_tel", tel1);
                    setValue(app_id + "_tel1", tel2);
                    setValue(app_id + "_tel2", tel3);
                    // <<< ThanhNV
                    // <<< 代表者名 part
                    // <<< Set value to merchant parsing
                    //http://test.ticket-search.net/hung/ANA_booking.html
                    // window.open('http://esm.local/jjp/input.html', '_blank');
                    // ThuyTQ >>
                    setValue(app_id + '_application_address2', $('.address_tr').find('#application_address2').val());
                    setValue(app_id + '_application_address3', $('#application_address3').val());
                    setValue(app_id + '_application_address4', $('#application_address4').val());
                    // ThuyTQ <<
                    // SmartTicket ThanhBN add >>> 
                    if ($('#flight_info1').val() != '' && $('#flight_info2').val() != '') {
                        setValue(app_id + '_flight_info1', $('#flight_info1').val());
                        setValue(app_id + '_flight_info2', $('#flight_info2').val());
                        setValue(app_id + '_VNLMode', 1);
                    } else if ($('#flight_info1').val() != '') {
                        setValue(app_id + '_VNLMode', 2);
                        setValue(app_id + '_flight_info1', $('#flight_info1').val());
                        // setValue(app_id + '_flight_info2', $('#flight_info2').val());
                    } else if ($('#flight_info2').val() != '') {
                        setValue(app_id + '_flight_info1', $('#flight_info2').val());
                        setValue(app_id + '_VNLMode', 3);
                    }
                    // <<< SmartTicket ThanhBN add
                });
                // <<<<< BOOKING
                // CONFIRM
                $(".check_button[value='予約確認']").click(function () {
                    onclickFnc = $(this).attr('onclick');
                    onclickFnc = onclickFnc.toString().replace('confirmReservation(', '');
                    onclickFnc = onclickFnc.substring(0, 1);
                    $('#glbKubunId').val(onclickFnc);

                });

                $(".check_button").click(function () {
                    var index = $(this).attr('data-line-no');
                    var app_id = "";

                    app_id = "#" + $('#application_application_id').val();
                    var checkMileage = checkMileageBTM(index);
                    if (checkMileage) {
                        setValue(app_id + 'application_service', $('select[name="application[service_type]"]').val());
                        setValue(app_id + '_application_mileage_flag' + index, checkMileage);
                        for (i = 0; i <= 8; i++) {
                            lname = $('#application_traveller_list_' + i + '_last_name').val();
                            fname = $('#application_traveller_list_' + i + '_first_name').val();
                            ANAMilage = "application[traveller_list][" + i.toString() + "][ana_mileage_no]";
                            JALMilage = "application[traveller_list][" + i.toString() + "][jal_mileage_no]";
                            setValue(app_id + '_application_traveller_list_' + i.toString() + '_name_ana', lname + ' ' + fname + '@' + $("[name='" + ANAMilage + "']").val());
                            setValue(app_id + '_application_traveller_list_' + i.toString() + '_name_jal', lname + ' ' + fname + '@' + $("[name='" + JALMilage + "']").val());
                        }
                    }

                });

                $('.flightdate_button').click(function () {
                    if ($('#tmp').length > 0) {
                        $('#memo_text').val($('#tmp').val());
                        $('#tmp').remove();
                    }
                })
            } else if (loc.toString().indexOf('/s/appli/application/confirmReservation') != -1) {
                setTimeout(function () {
                    clearAll();
                    dtmNow = new Date();
                    intYear = dtmNow.getFullYear();
                    airlineName = $('#airline').val().toString().toLowerCase();

                    app_id = "#" + $('#application_id').val() + "_";
                    line_no = $('#line_no').val();

                    setValue(app_id + 'application_first_name' + line_no, $('#first_name').val());
                    setValue(app_id + 'application_last_name' + line_no, $('#last_name').val());
                    setValue(app_id + 'application_first_name_rome' + line_no, convKata2Romaji($('#first_name').val(), $('#application_traveller_list_0_first_name_rome').val()));
                    setValue(app_id + 'application_last_name_rome' + line_no, convKata2Romaji($('#last_name').val(), $('#application_traveller_list_0_last_name_rome').val()));
                    setValue(app_id + 'application_airline_name' + line_no, $('#airline').val());
                    setValue(app_id + 'application_flight_no' + line_no, $('#flight_no').val());
                    setValue(app_id + 'application_flight_year' + line_no, $('#year').val());
                    setValue(app_id + 'application_flight_month' + line_no, $('#month').val());
                    setValue(app_id + 'application_flight_day' + line_no, $('#day').val());
                    setValue(app_id + 'application_flight_date' + line_no, '' + pad(parseInt($('#month').val()), 2) + pad(parseInt($('#day').val()), 2));
                    setValue(app_id + 'application_flight_date_full' + line_no, $('#year').val() + '-' + pad(parseInt($('#month').val()), 2) + '-' + pad(parseInt($('#day').val()), 2));
                    setValue(app_id + 'application_flightdatefull' + line_no, $('#year').val() + '' + pad(parseInt($('#month').val()), 2) + '' + pad(parseInt($('#day').val()), 2));
                    setValue(app_id + 'application_ticket_reservation_no' + line_no, $('#ticket_reservation_no').val());
                    /*
                    setValue('application_first_name', $('#first_name').val());
                    setValue('application_last_name', $('#last_name').val());
                    setValue('application_first_name_rome', convKata2Romaji($('#first_name').val(), $('#application_traveller_list_0_first_name_rome').val()));
                    setValue('application_last_name_rome', convKata2Romaji($('#last_name').val(), $('#application_traveller_list_0_last_name_rome').val()));
                    setValue('application_airline_name', $('#airline').val());
                    setValue('application_flight_no', $('#flight_no').val());
                    setValue('application_flight_year', $('#year').val());
                    setValue('application_flight_month', $('#month').val());
                    setValue('application_flight_day', $('#day').val());
                    setValue('application_flight_date', '' + pad(parseInt($('#month').val()),2) + pad(parseInt($('#day').val()),2));
                    setValue('application_flight_date_full', $('#year').val() + '-' + pad(parseInt($('#month').val()),2) + '-' + pad(parseInt($('#day').val()),2));
                    setValue('application_ticket_reservation_no', $('#ticket_reservation_no').val());
                    */
                    if (airlineName == 'jta' || airlineName == 'rac' || airlineName == 'jac') {
                        airlineName = 'jal';
                    }
                    href = $('#' + airlineName + '_link').attr('href');
                    if (airlineName == 'jal') {
                        $('input[name="FUNCTION"]').val(6);
                        $('#JALForm').submit();
                    } else if (airlineName == 'amx') {
						$('#searchForm02').submit();
					} else {
                        location.href = href;
                    }

                }, CMS_TIMEOUT_INMILISECONDS);
            } else if (loc.toString().indexOf('/s/appli/application/flightCertification/') != -1) {
                setTimeout(function(){
                    airlineName = $('#airline_name').val().toString().toLowerCase();
                    // set value into localStorage
					setValue('application_flight_certification_year', $('#year').val());
                    setValue('application_flight_certification_month', $('#month').val());
                    setValue('application_flight_certification_day', $('#day').val());
                    setValue('application_flight_certification_ymd', $('#year').val() + '/' + $('#month').val() + '/' + $('#day').val());
                    setValue('application_flight_certification_ymd_1', $('#year').val() + $('#month').val() + $('#day').val());
                    setValue('application_flight_certification_flight_no', $('#flight_no').val());
                    setValue('application_flight_certification_ticket_reservation_no', $('#ticket_reservation_no').val());
                    setValue('application_flight_certification_tel', $('#tel').val());
                    setValue('application_flight_certification_traveller_last_name_rome', $('#traveller_last_name_rome').val());
                    setValue('application_flight_certification_traveller_first_name_rome', $('#traveller_first_name_rome').val());
                    setValue('application_flight_certification_traveller_last_name', $('#traveller_last_name').val());
                    setValue('application_flight_certification_traveller_first_name', $('#traveller_first_name').val());
                    var ticket_receipt_no = $('#ticket_receipt_no').val();
                    if (airlineName == 'jal') {
                        ticket_receipt_no = ticket_receipt_no.replace(" ", "");
                    }
                    setValue('application_flight_certification_ticket_receipt_no', ticket_receipt_no);
                    // check site 
                    if (airlineName == 'jal') {
                        location.href = 'https://www.5971.jal.co.jp/rsv/ETicketSearch.do';
                    }else if (airlineName == 'ana') {
                        $now = new Date();
                        $now = '' + $now.getFullYear() + pad($now.getMonth() + 1, 2) + pad($now.getDate(), 2) + pad($now.getHours(), 2) + pad($now.getMinutes(), 2) + pad($now.getSeconds(), 2);
                        location.href = 'https://aswbe-d.ana.co.jp/9Eile48/dms/redbe/dyc/be/pages/inquire/receiptLoginDispatch.xhtml?rand='+$now+'&CONNECTION_KIND=JPN&LANG=ja';
                    } else if (airlineName == 'sky') {
                        location.href = 'https://www.res.skymark.co.jp/reserve2/?m=confirm&language=ja';
                    } else if (airlineName == 'fda') {
                        location.href = 'https://www.fujidreamairlines.com/bkt/app/RES/top/FRIG410_13BL.do?_ga';
                    } else if (airlineName == 'ado') {
                        location.href = 'https://www.airdo.jp/ap/myairdo/cus005/cus005001?';
                    }
				}, CMS_TIMEOUT_INMILISECONDS);
                
            } else if (loc.toString().indexOf('/s/appli/') != -1) {
                //clearAllData();
            }
        }
        //@Thuy edit 2016-26-01 >>
        else {

            hash = window.location.hash;
            fligh_info1 = hash.split('&');
			if(fligh_info1[1] != undefined){
				hash = "#" + fligh_info1[1];
			}
            fligh_info = hash.split('_');
			console.log('************fligh_info************' +fligh_info);
            if (fligh_info === undefined || fligh_info.length < 3) {
                cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
            } else {
                console.log('************hash id************' + window.location.hash);
                sessionStorage.setItem('cms_app_id', fligh_info[0]); 
                sessionStorage.setItem('line_no', fligh_info[1]);
                sessionStorage.setItem('carrier', fligh_info[2]);
                sessionStorage.setItem('confirm_flag', fligh_info[3]);
                sessionStorage.setItem('person_cnt', fligh_info[4]);
                sessionStorage.setItem('name_rome', fligh_info[5]);
            }
            //#appId_cms=1460509

            //$( "body" ).append( "<p id='domain_cmstest' style='display:none'>"+domain_cms+"</p>" + "<input type='hidden' id='appId_cms'  value='testttt34'>");
            //$( "body" ).append( "<input type='hidden' id='appId_cms'  value='" + appId + "'>");

            loc = window.location;
            if (loc.toString().indexOf('/s/appli/application/edit') != -1 || loc.toString().indexOf('/s/appli/application/clone') != -1) {
                clearAllData();
            }
        }
        //@Thuy edit 2016-26-01 <<
    });
}, 300);

window.addEventListener('focus', function () {
    // check by domain
    domain_name = document.domain;
    //call again CMS domain
    //getDomain();
console.log('******Focus page again: *******');
    setTimeout(function () {
        // Handler for .ready() called.
        CMS_DOMAIN = $("#domain_cms").html();
        CMS_DOMAIN = (CMS_DOMAIN == '' || typeof (CMS_DOMAIN) == 'undefined' ? 'air.tabicapital_dev.net' : CMS_DOMAIN);
        console.log('Call domain again: ' + CMS_DOMAIN);

        //@Thuy Edit 2016-25-01
        if (CMS_DOMAIN.indexOf(domain_name) > -1) {
            loc = window.location;
            app_id = $('#application_application_id').val();
            if (loc.toString().indexOf('/s/appli/application/edit/' + app_id) != -1 || loc.toString().indexOf('/s/appli/application/clone/' + app_id) != -1) {
                getItem('#' + app_id + '_merchant_flight_info_callback0', 'merchant_flight_info_callback', 'merchant_flight_info_callback');
                getItem('#' + app_id + '_merchant_flight_info_callback1', 'merchant_flight_info_callback', 'merchant_flight_info_callback');
                getItem('#' + app_id + '_merchant_flight_info_callback2', 'merchant_flight_info_callback', 'merchant_flight_info_callback');
                getItem('#' + app_id + '_merchant_flight_info_callback3', 'merchant_flight_info_callback', 'merchant_flight_info_callback');
                ////call back to cms 02
                getItem('#' + app_id + '_merchant_flight_info_callback_linkpayment0', 'merchant_flight_info_callback_linkpayment', 'merchant_flight_info_callback_linkpayment');
                getItem('#' + app_id + '_merchant_flight_info_callback_linkpayment1', 'merchant_flight_info_callback_linkpayment', 'merchant_flight_info_callback_linkpayment');
                getItem('#' + app_id + '_merchant_flight_info_callback_linkpayment2', 'merchant_flight_info_callback_linkpayment', 'merchant_flight_info_callback_linkpayment');
                getItem('#' + app_id + '_merchant_flight_info_callback_linkpayment3', 'merchant_flight_info_callback_linkpayment', 'merchant_flight_info_callback_linkpayment');
                getItem('#' + app_id + '_merchant_flight_info_callback_linkpayment0-1', 'merchant_flight_info_callback_linkpayment', 'merchant_flight_info_callback_linkpayment');
                getItem('#' + app_id + '_merchant_flight_info_callback_linkpayment1-2', 'merchant_flight_info_callback_linkpayment', 'merchant_flight_info_callback_linkpayment');
                getItem('#' + app_id + '_merchant_flight_info_callback_linkpayment2-3', 'merchant_flight_info_callback_linkpayment', 'merchant_flight_info_callback_linkpayment');
				//call back sjo set reserveNo
				//step02
				getItem('#' + app_id + '_sjo_callback_reserveNo0', 'merchant_flight_info_callback_reserveNo', 'merchant_flight_info_callback_reserveNo');
				getItem('#' + app_id + '_sjo_callback_reserveNo1', 'merchant_flight_info_callback_reserveNo', 'merchant_flight_info_callback_reserveNo');
				getItem('#' + app_id + '_sjo_callback_reserveNo2', 'merchant_flight_info_callback_reserveNo', 'merchant_flight_info_callback_reserveNo');
				getItem('#' + app_id + '_sjo_callback_reserveNo3', 'merchant_flight_info_callback_reserveNo', 'merchant_flight_info_callback_reserveNo');
            } else if (loc.toString().indexOf('/s/appli/application/edit2/' + app_id) != -1){
				getItem('#' + app_id + '_merchant_confirm_info_callback_rsv0', 'merchant_confirm_info_callback_skyconfirm', 'merchant_confirm_info_callback_skyconfirm');
				getItem('#' + app_id + '_merchant_confirm_info_callback_rsv1', 'merchant_confirm_info_callback_skyconfirm', 'merchant_confirm_info_callback_skyconfirm');
				getItem('#' + app_id + '_merchant_confirm_info_callback_rsv2', 'merchant_confirm_info_callback_skyconfirm', 'merchant_confirm_info_callback_skyconfirm');
				getItem('#' + app_id + '_merchant_confirm_info_callback_rsv3', 'merchant_confirm_info_callback_skyconfirm', 'merchant_confirm_info_callback_skyconfirm');
			}
        }
        //@Thuy Edit 2016-1-26 check Inactive clear all
        else {

            loc = window.location;
            if (loc.toString().indexOf('/s/appli/application/edit') != -1 || loc.toString().indexOf('/s/appli/application/clone') != -1) {
                clearAll();
            }
        }
    }, 500);
    //@Thuy << 2016-1-26
});

window.addEventListener("beforeunload", function (e) {

    loc = window.location.href; 
    var res = loc.match(/application\/.*\/([0-9]{1,8})\/.*/);
    app_id = res[1];
    if (loc.toString().indexOf('/s/appli/application/edit/' + app_id) != -1 || loc.toString().indexOf('/s/appli/application/clone/' + app_id) != -1) {
        //clear all data by appid at edit screen incase close tab
		clearAll(app_id, 0);
        clearAll(app_id, 1);
        clearAll(app_id, 2);
        clearAll(app_id, 3);
		//xdLocalStorage.clear(); //clear all data in local storage
    } 
	//else if (loc.toString().indexOf('res.skymark.co.jp/reserve2/addFlightInfo') != -1) {
	//	xdLocalStorage.clear(); //clear all data in local storage
	//}
}, false);
// <<< common part