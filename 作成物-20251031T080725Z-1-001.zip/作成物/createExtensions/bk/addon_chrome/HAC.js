	function setFlightInformationHAC() {
		dtmLimitDate = '';
		reserveNo = '';
		strLimitDate = '';
		strLimitDate2 = '';
		departureAirposrt = '';
		arrivalAirposrt = '';
		strTicketType = '';
		strSeat = '';
		strBody = $('body').text().toString(); 
		res = strBody.match(/([0-9]{1,2}月[0-9]{1,2}日\(.\))迄にお支払いください。/);
		if (!!res) {		
			strLimitDate = res[1];
			dtmLimitDate = fixAnaDate(strLimitDate);
		} else {
			dtmLimitDate = new Date();
			dtmLimitDate.setDate(dtmLimitDate.getDate() + 2);
		}	
		// reserve table
		reserveNoTbl = $('.numberTable');
		reserveNo = getCellValueInTable(reserveNoTbl, 1, 2);
		// content table
		curTable = getTableByTextContainTH('搭乗日');
		if (typeof(curTable[0]) != 'undefined') {
			curTable = curTable[0];
		}
		curTable = $(curTable);
		//console.log(curTable);
		if (typeof(curTable) != 'undefined') {
				dtmFlightDate = fixAnaDate(getCellValueInTable(curTable, 2, 3));
                if (strLimitDate != "搭乗日当日") {
                    strLimitDate2 = formatDate(dtmLimitDate);
                } else {
                	strLimitDate2 = new Date(dtmFlightDate.getFullYear(), dtmFlightDate.getMonth(), dtmFlightDate.getDate());
                    strLimitDate2 = strLimitDate2.setDate(strLimitDate2.getDate() - 1);
                    strLimitDate2 = formatDate(strLimitDate2);
                }
				vntDepartureTime = getCellValueInTable(curTable, 2, 6).replace(':', '/');
                vntArrivalTime = getCellValueInTable(curTable, 2, 7).replace(':', '/');
                subTable = curTable.find('table').first();
				departureAirposrt = getCellValueInTable(subTable, 1, 1);
				arrivalAirposrt = getCellValueInTable(subTable, 1, 3);
				//console.log(subTable);
				//console.log(departureAirposrt);
				//console.log(arrivalAirposrt);
				strTicketType = getCellValueInTable(curTable, 2, 8);
				strValue = "";
                strValue += formatDate(dtmFlightDate);
                strValue += "/" + fixAnaAirline(getCellValueInTable(curTable, 2, 4));
                strValue += "/" + fixAnaFlightNo(getCellValueInTable(curTable, 2, 4));
                strValue += "/" + fixJalAirportName(departureAirposrt + ' [ 18：30 ]');
                strValue += "/" + fixJalAirportName(arrivalAirposrt + ' [ 18：30 ]');
                strValue += "/" + vntDepartureTime;
                //strValue += "/" + AppCommon.GetMinuteString(vntDepartureTime);
                strValue += "/" + vntArrivalTime;
                //strValue += "/" + AppCommon.GetMinuteString(vntArrivalTime);
                strValue += "/" + reserveNo;
                strValue += "/" + strLimitDate2;
                strValue += "/" + strSeat;
                strValue += "/" + strTicketType;
                //2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム

                strText = "";
                strText +=  getCellValueInTable(curTable,  2, 3);
                strText += "/" + fixAnaAirline(getCellValueInTable(curTable, 2, 4));
                strText += "/" + fixAnaFlightNo(getCellValueInTable(curTable, 2, 4));
                strText += "/" + fixJalAirportName(departureAirposrt + ' [ 18：30 ]');
                strText += "/" + fixJalAirportName(arrivalAirposrt + ' [ 18：30 ]');
				data_callback = strValue + '|' + strText;
				console.log(data_callback);
				setTimeout(function(){
					setValue('merchant_flight_info_callback', data_callback);
				}, CMS_TIMEOUT_INMILISECONDS);
		}
	}
	

	$( document ).ready(function() {
		var domain_name = document.domain;
		var loc = window.location;
		
		if(domain_name=="www.hac-air.co.jp"){
			/*if(loc.toString().indexOf("www.hac-air.co.jp/bkt/app/RES/reservation") != -1 && $('body').text().toString().indexOf('便選択結果') != -1) {
				setTimeout(function(){
					getItem('application_adult_count','adultSeatCount','select');
					getItem('application_child_count','childSeatCount','select');
					getItem('application_infant_count','infantSeatCount','select');
					getItem('application_infant_count','infantSeatCount','endSearchHAC');
				}, CMS_TIMEOUT_INMILISECONDS);
			}  // Comment for 取消/変更 change schedule
			else*/ if(loc.toString().indexOf("www.hac-air.co.jp/bkt/app/RES/reservation")  != -1 && $('body').text().toString().indexOf('搭乗者情報入力')  != -1) {
				// copy from application
				setTimeout(function(){
						//getItem('application_sky_email',"mailAddressPC","name");
						//getItem('application_sky_email',"mailAddressMB","name");
						getItem("application_tel1","phoneNo","name");
						getItem("reserve_email","pcMail","name");
						getItem('application_adult_list',"adult","setTravellerHAC");
						getItem('application_child_list',"child","setTravellerHAC");
						getItem('application_infant_list',"infant","setTravellerHAC");
				}, CMS_TIMEOUT_INMILISECONDS);	
			// copy to application
			} else if(loc.toString().indexOf("www.hac-air.co.jp/bkt")  != -1 && $('body').text().toString().indexOf('予約詳細')  != -1) {
				setFlightInformationHAC();
				console.log('setFlightInformationHAC done');
			}
		}
	});