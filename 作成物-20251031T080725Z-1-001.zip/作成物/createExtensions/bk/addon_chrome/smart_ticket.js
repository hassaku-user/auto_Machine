/*
 * ANA新株 airport
 * Check auto submit
 * Check operator edit after auto fill
 * Check affection to other pages in same domain
 * Clear all value after set in form(click button)
 * */
function logoutSmartTicket() {
	getItem("isLogInOK","isLogInOK","setLogoutSmartTicket");
}

function loginSmartTicket() {
	getItem("glb_cmslink","glb_cmslink","setLoginSmartTicket");
}


function searchFromAppliSmartTicket() {
	getItem("flight_info1","search_from_flight_info1","setSmartTicket");
	getItem("flight_info2","search_from_flight_info2","setSmartTicket");
}

function searchFlightFromAppliSmartTicket() {
	getItem("flight_info1","search_flight_flight_info1","setSmartTicket");
	getItem("flight_info2","search_flight_flight_info2","setSmartTicket");
}

function copyFromAppliSmartTicket() {
	getItem("flight_info1","copy_from_flight_info1","setSmartTicket");
	getItem("flight_info2","copy_from_flight_info2","setSmartTicket");
}

function setFlightInformationSmartTicket() {
	var strLimitDate = '';
	var strLimitDate2 = '';
	var data_callback = '';
	curTable = getTableByTextContainTH('お支払い期限');
	curTable = $(curTable);
	if (typeof(curTable[0]) != 'undefined') {
		strLimitDate = getCellValueInTable(curTable, 2 , 1);
		strLimitDate = strLimitDate.split('～');
		strLimitDate = $.trim(strLimitDate[1]);
	}
	// get dtmLimitDate
	dtmLimitDate = getLimitDateSmartTicket();
	// get flight information
	curTable = getTableByTextContainTH('搭乗日');
	curTable = $(curTable);
	if (typeof(curTable[0]) != 'undefined') {
		strValue = "";
		strText = "";
		for (intRow=2; intRow<=2; intRow++) {
			dtmFlightDate = fixAnaDate(getCellValueInTableSmart(curTable, intRow, 1));
			// 1799 is min value
			if (dtmFlightDate.getFullYear() != DATE_MIN_VAL) {
			    if (intRow > 2) {
					strValue += CMS_DELIMITER;
					strText += CMS_DELIMITER;
				}
				if (strLimitDate != '搭乗日当日') {
					// strLimitDate2 = formatDate(dtmLimitDate);
					strLimitDate2 = dtmLimitDate;
				} else {
					dtmLimitDate2 = new Date(dtmFlightDate.getFullYear(), dtmFlightDate.getMonth(), dtmFlightDate.getDate());
					dtmLimitDate2.setDate(dtmLimitDate2.getDate() - 1);
					strLimitDate2 = formatDate(dtmLimitDate2);
				}
				//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				vntTime = getCellValueInTableSmart(curTable, intRow, 4);
				vntTime = vntTime.toString().replace(':', '/').replace(':', '/').replace('⇒', '/');
				strSeat = fixAnaSeat(getCellValueInTableSmart(curTable, intRow, 5));
				strValue += formatDate(dtmFlightDate);
				strValue += "/" + fixAnaAirline(getCellValueInTableSmart(curTable, intRow, 2));
				strValue += "/" + fixAnaFlightNo(getCellValueInTableSmart(curTable, intRow, 2));
				airLineName = getCellValueInTableSmart(curTable, intRow, 3);
				airLineName = airLineName.split("⇒");
				depName  = airLineName[0];
				desName  = airLineName[1];
				strValue += "/" + fixJalAirportName(depName);
				strValue += "/" + fixJalAirportName(desName);
				strValue += "/" + vntTime;
				strValue += "/" + getCellValueInTableSmart(curTable, intRow, 7);
				strValue += "/" + strLimitDate2;
				strValue += "/" + strSeat;
				strValue += "/" + getCellValueInTableSmart(curTable, intRow, 6);
				//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				strText = ""; 
				// strText += Application2.LastName + Application2.FirstName; // Add by common
				strText +=  formatDate(dtmFlightDate);
				strText += "/" + fixAnaAirline(getCellValueInTableSmart(curTable, intRow, 2));
				strText += "/" + fixAnaFlightNo(getCellValueInTableSmart(curTable, intRow, 2));
				strText += "/" + fixJalAirportName(depName);
				strText += "/" + fixJalAirportName(desName);
			}				
		}
		
		line_no = sessionStorage.getItem('line_no');
		carrier = sessionStorage.getItem('carrier');
		data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
	}
	cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
	line_no = $.trim(sessionStorage.getItem('line_no'));
	setTimeout(function(){
		setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
	}, CMS_TIMEOUT_INMILISECONDS);
}

$( document ).ready(function() {
	var domain_name = document.domain;
	 loc = window.location;
	 if(domain_name=="smart-ticket.biz") {
	 	strBody = $('body').text().toString();
	 	
	 	if(loc.toString().indexOf('smart-ticket.biz/agent/top') != -1 && strBody.indexOf("ログアウト") > -1) {
			setTimeout(function(){
				logoutSmartTicket();		
		    }, CMS_TIMEOUT_INMILISECONDS - 1000);
	 	}
	 	
	 	if (strBody.indexOf("航空券予約システム") > -1) {
		    setTimeout(function(){		
		       loginSmartTicket();
		    }, CMS_TIMEOUT_INMILISECONDS - 1000);
	 	} else if (strBody.indexOf("検索後予約便選択ページへ遷移します。") > -1
				|| strBody.indexOf("サーバーの負荷が上がり、ページ閲覧がしにくい状況が発生しやすくなります。") > -1) {
			setTimeout(function(){		
		       searchFromAppliSmartTicket();
		    }, CMS_TIMEOUT_INMILISECONDS);
		    
		} else if (strBody.indexOf("予約する便のアイコンを選択して下さい。") > -1) {
			setTimeout(function(){
			   searchFlightFromAppliSmartTicket();
		    }, CMS_TIMEOUT_INMILISECONDS);
	    } else if (strBody.indexOf("搭乗者情報をご入力下さい。") > -1) {
	    	console.log('vao input');
	    	setTimeout(function(){
			   copyFromAppliSmartTicket();
			}, CMS_TIMEOUT_INMILISECONDS);
		} else if (strBody.indexOf("予約結果") > -1 && strBody.indexOf("予約が正常に完了しました") > -1 ) {
	    	// press button to view result
	    	setTimeout(function(){
			   $("input[type='submit'][value='発券処理']").trigger('click');
			}, CMS_TIMEOUT_INMILISECONDS - 1500);
		}  else if (strBody.indexOf("予約情報詳細") > -1 && strBody.indexOf("「発券実行」ボタン押下は") > -1) {
    	    // console.log('set callback');
		    setFlightInformationSmartTicket();
		} 
	  } 
});