/*
 * ANA airport
 * Check auto submit
 * Check operator edit after auto fill
 * Check affection to other pages in same domain
 * Clear all value after set in form(click button)
 * */
var fare = '';
function setFlightInformation(flag) {
	var fareList = [
		'バリュー3',
		'バリュー1',
		'フレックスA',
		'フレックスB',
		'フレックスC',
		'フレックスD',
		'スーパーバリュー21',
		'スーパーバリュー28',
		'スーパーバリュー45',
		'スーパーバリュー55',
		'スーパーバリュー75',
	];
	
	if(flag == 1){
		var strLimitDate = '';
		var strLimitDate2 = '';
		var data_callback = '';
		strLimitDate = $('.paymentLimit dd em').html();
		// get dtmLimitDate
		dtmLimitDate = getLimitDateAna();
		// get flight information
		curTable = $('.itinerary');
		if (typeof(curTable[0]) != 'undefined') {
			strValue = "";
			strText = "";
			for (intRow=2; intRow<=2; intRow++) {
				dtmFlightDate = fixAnaDate($('.itineraryDateCell .date').html().split("<br>")[1]);
				// 1799 is min value
				if (dtmFlightDate.getFullYear() != DATE_MIN_VAL) {
					if (intRow > 2) {
						strValue += CMS_DELIMITER;
						strText += CMS_DELIMITER;
					}
					if (strLimitDate != '搭乗日当日') {
						strLimitDate2 = formatDate(dtmLimitDate);
					} else {
						dtmLimitDate2 = new Date(dtmFlightDate.getFullYear(), dtmFlightDate.getMonth(), dtmFlightDate.getDate());
						//dtmLimitDate2.setDate(dtmLimitDate2.getDate() - 1);
						strLimitDate2 = formatDate(dtmLimitDate2);
					}
					//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
					vntDepartureTime = $.trim($($('.flightDep .time')).html()).toString();
					vntDepartureTime = vntDepartureTime.replace(":", "/");
					vntArrivalTime = $.trim($($('.flightArr .time')).html()).toString();
					vntArrivalTime = vntArrivalTime.toString().replace(":", "/");
					strSeat = fixAnaSeat($.trim($($('.itinerarySeatClass')[1]).html()));
					strValue += formatDate(dtmFlightDate);
					airLine = $.trim($($('.itineraryFlightNumber')[1]).html().split("<br>")[0]);
					if (airLine.toString().indexOf('class') != -1) {
						airLine = $($('.itineraryFlightNumber span')).html();
					}
					
					var iconWifiAll = $.trim($($('.itineraryFlightNumber')[1]).html().split("<br>")[2]);
					var wifi = 0;
					if (iconWifiAll.toString().indexOf('iconWifiAll') != -1) {
						wifi = 1;
					}
					if (iconWifiAll.toString().indexOf('iconWifiSome') != -1) {
						wifi = 2;
					}
					//console.log("wifi-" + wifi + "/" + iconWifiAll);
					
					strValue += "/" + fixAnaAirline(airLine);
					strValue += "/" + fixAnaFlightNo(airLine);
					strValue += "/" + fixJalAirportName($.trim($($('.flightDep .airport')).html()));
					strValue += "/" + fixJalAirportName($.trim($($('.flightArr .airport')).html()));
					strValue += "/" + vntDepartureTime;
					//strValue += "/" + getMinuteString(vntDepartureTime);
					//strValue += "/" + pad(vntArrivalTime[0],2);
					strValue += "/" + vntArrivalTime;
					strValue += "/" + $('.itineraryRsvNo em').html();
					strValue += "/" + strLimitDate2;
					strValue += "/" + strSeat;
					fare = $('.itineraryFare ul a').html().split("<span")[0];
					if (formatDate(dtmFlightDate) >= '2016/10/30') {
						patt = new RegExp(/^(特割|旅割)[0-9]+[A-Z]{1}$/);
						res = patt.test(fare);
						if (res) {
							fare = fare.slice(0, -1) + "[AN]";
						}
					}
					
					fareList.forEach(changeFare);
					
					strValue += "/" + fare; 
					
					strValue += "/wifi=" + wifi; 
					//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
					strText = ""; 
					// strText += Application2.LastName + Application2.FirstName; // Add by common
					strText +=  formatDate(dtmFlightDate);
					strText += "/" + fixAnaAirline(airLine);
					strText += "/" + fixAnaFlightNo(airLine);
					strText += "/" + fixJalAirportName($.trim($($('.flightDep .airport')).html()));
					strText += "/" + fixJalAirportName($.trim($($('.flightArr .airport')).html()));
					
				}				
			}
			
			line_no = sessionStorage.getItem('line_no');
			
			
			data_callback = strValue;
			console.log(data_callback);
		}
		cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
		line_no = $.trim(sessionStorage.getItem('line_no'));
		mile = $.trim(sessionStorage.getItem(cms_app_id +'_mile_callback' + line_no));
		setTimeout(function(){
			//setValue("glbCurAirport",'ANA'); // GLOBAL for setting some variables
			//setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
			sessionStorage.setItem(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback + "/mile=" + mile);
		}, CMS_TIMEOUT_INMILISECONDS);
	} else if (flag == 2){
		$(function() {
			//$(".selectArea").click(function(e) {
			/*
			$('input[name ="selectFare"]').click(function(e) {
				//var clickedValue = $(e.target).html();
				//console.log( clickedValue + "/ radio button click");
				var clickedValue = $(e.currentTarget).parent();
				var clickedValue1 = $(clickedValue).parent();
				var clickedValue2 = $(clickedValue1).parent();
				var clickedValue3 = $(clickedValue2).parent().text();
				var myRegexp = /\:(.+?)マイル/g;
				var match = myRegexp.exec(clickedValue3);
				if(match[1] != null && match[1] != "undefined"){
					alert(match[1]);
					//response mile to cms
					console.log(match[1]);
				}
			});
			*/
			$(".selectArea").click(function(e) {
				var clickedValue = $(e.currentTarget).parent();
				var clickedValue1 = $(clickedValue).parent().text();
				var myRegexp = /\:(.+?)マイル/g;
				var match = myRegexp.exec(clickedValue1);
				if(match[1]){
					//alert(match[1]);
					//response mile to cms
					
					
					cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
					line_no = $.trim(sessionStorage.getItem('line_no'));
					carrier = sessionStorage.getItem('carrier');
					sessionStorage.setItem(cms_app_id +'_mile_callback' + line_no, match[1]);
					//data_callback = sessionStorage.getItem(cms_app_id +'_merchant_flight_info_callback' + line_no);
					
					console.log("mile: "+match[1] + "/ appid:" + cms_app_id + "/ data_callback: " + match[1]);
					/*
					setTimeout(function(){
						//setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
						setValue(cms_app_id +'_mile_callback' + line_no, match[1]);
					}, CMS_TIMEOUT_INMILISECONDS);
					console.log(match[1]);
					*/
				}
				
			});
		});
	} else{
		priceChild = 0;
		priceAdult = 0;
		priceList = [];
		
		$('.tableCommonSector.tableBreakdown').each(function(){
			itemPrice = $(this).find('.tableCommonSectorTdCell1 .price').text();
			itemPrice = itemPrice.replace(/,/g, "");
			priceList.push(parseInt(itemPrice));
			
			ticket = $(this).find('.tableCommonSectorTdCell2 a').text();
			if(ticket.toString().indexOf('小児') != -1){
				priceChild = parseInt(itemPrice);
			}else{
				priceAdult = parseInt(itemPrice);
			}
		});
		console.log(priceList);
		var priceArr = priceList.filter(onlyUnique);
		console.log(priceArr);
		if(priceArr.length > 1){
			priceChild = Math.min(...priceArr);
			priceAdult = Math.max(...priceArr);
		}
		
		
		cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
		line_no = $.trim(sessionStorage.getItem('line_no'));
		carrier = sessionStorage.getItem('carrier');
		data_callback = sessionStorage.getItem(cms_app_id +'_merchant_flight_info_callback' + line_no);
		data_callback += '/' + priceAdult + '/' + priceChild + '|' + data_callback  + '|' + line_no + '|' + carrier;
		setTimeout(function(){
			//setValue("glbCurAirport",'ANA'); // GLOBAL for setting some variables
			setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
		}, CMS_TIMEOUT_INMILISECONDS);
		console.log(data_callback);
	}
}

function changeFare(value){
	if(fare.toString().indexOf(value) != -1){
		fare = value;
	}
}

$( document ).ready(function() {
	 
var domain_name = document.domain;

	 loc = window.location;
	 if(domain_name=="aswbe-d.ana.co.jp") {
	 	// search flight information >>> 
    	patt = new RegExp(/https:\/\/aswbe-d.ana.co.jp\/.+?\/dms\/.+?\/dyc\/be\/pages\/res\/search\/vacantResult.xhtml\?aswdcid=/);
	    res = patt.test(loc);
		console.log(res);
	    if (res) {
	    	setTimeout(function(){
				$('#modalGeneral').trigger('click');
	        }, CMS_TIMEOUT_INMILISECONDS);
        }
        // <<<<<<
		
		
		// get mile on search result >>> 
    	patt = new RegExp(/https:\/\/aswbe-d.ana.co.jp\/.+?\/dms\/.+?\/dyc\/be\/pages\/res\/search\/vacantResult.xhtml\?rand/);
	    res = patt.test(loc);
		console.log(res);
	    if (res) {
			setFlightInformation(2);
        }
        // <<<<<<
	 	
	    patt = new RegExp(/https:\/\/aswbe-d.ana.co.jp\/.+?\/rsvp\/dyc\/securePage.do\?rand=[0-9]+&TOKEN=.+/);
    	res = patt.test(loc);
	    if(res == true) {
    	 	// click button add amount and child
    		$("[name='btnSubmit:mapping=pax_infant']").trigger('click');
	    } else {
	    	// after click button add amount and child
	    	//patt = new RegExp(/https:\/\/aswbe-d.ana.co.jp\/.+?\/dms\/red12l\/dyc\/be\/pages\/res\/reservation\/reservationPaxInformationInput.xhtml/);
	    	//res = patt.test(loc);
			
			if(loc.toString().indexOf('dyc/be/pages/res/reservation/reservationPaxInformationInput.xhtml') != -1) {
			
			//if (res) {
    	    	traveller_id = $(".tableCommonSector.tableCustomerInfomation td.lastName input")[0].id.split(':')[0] + ":";
    	    	$temp = $(".tableCommonSector.tableCustomerInfomation.noNumber td.lastName input")[0];
    	    	$haveInfant = false;
    	    	if (typeof($temp) != 'undefined') {
    	    		infant_id = $temp.id.split(':')[0] + ":";
    	    		$haveInfant = true;
    	    	}
	    	    setTimeout(function(){
	    	       for (i=0; i<=5; i++) {
		           		getItem('application_traveller_list_' + i.toString() + '_last_name',traveller_id+ i.toString() +":paxLastName", 'name');
		           		getItem('application_traveller_list_' + i.toString() + '_first_name',traveller_id+ i.toString() +":paxFirstName", 'name');
		           		getItem('application_traveller_list_' + i.toString() + '_age',traveller_id+ i.toString() +":age", 'name');
		           		getItem('application_traveller_list_' + i.toString() + '_sex',traveller_id+ i.toString() +":radioSexCode", 'radio');
		           }
		           if ($haveInfant == true) {
			           for (i=0; i<=1; i++) {
			           	   getItem('application_infant_list_' + i.toString() + '_last_name',infant_id+ i.toString() +":infLastName", 'name');
			           	   getItem('application_infant_list_' + i.toString() + '_first_name',infant_id+ i.toString() +":infFirstName", 'name');
			           	   getItem('application_infant_list_' + i.toString() + '_age',infant_id+ i.toString() +":infAge", 'select');
			           	   getItem('application_infant_list_' + i.toString() + '_sex',infant_id+ i.toString() +":radioInfSexCode", 'radio');
			           	   getItem('inf_pax' + i.toString(),infant_id+ i.toString() +":parentPaxNumber", 'select');
			           }
			       }
		           getItem('application_tel1',"telNo", 'name');
		           getItem('reserve_email',"assistMailAddress", 'mailANA');
		           getItem('reserve_email',"assistConfirmMailAddress", 'mailANA');
		           //getItem('application_assistMailDomain',"contactForm.assistMailDomain", 'name');
		           // getItem('application_sendMailId',"contactForm.sendMailId", 'name');
		           getItem('reserve_email',"assistMailAddress", 'endSetAnaTraveller');

					$('.btnAreaSubmit>input').trigger('click');
					
					ticket = $('.perFare').text();
					if(ticket.toString().indexOf('株主優') != -1){
						//no click
					}else{
						setTimeout(function(){
							$('#dialogNextButtonNoAMC .btnMainStream').trigger('click');
						}, CMS_TIMEOUT_INMILISECONDS);
					}
		       }, CMS_TIMEOUT_INMILISECONDS);
		  } else if (loc.toString().indexOf('dyc/be/pages/inquire/certificateSearch.xhtml') != -1) {
			$('#buttonBoardingCertificate').trigger('click');
			setTimeout(function(){
				// id_jal_span
				getItem('application_flight_certification_ymd','boardingDateText02','id_ana_date');
				getItem('application_flight_certification_ymd_1','boardingDate02','select');
				getItem('application_flight_certification_flight_no','boardingCertificateFlightNo','select');
				getItem('application_flight_certification_ticket_reservation_no','boardingCertificateReservationNo','select');
				getItem('application_flight_certification_traveller_last_name','boardingCertificateReservationNoLastName','select');
				getItem('application_flight_certification_traveller_first_name','boardingCertificateReservationNoFirstName','select');
			}, CMS_TIMEOUT_INMILISECONDS);
		  } else {
	    	// last page, get value to callback CMS
	    	// https://aswbe-d.ana.co.jp/9Eile48/red32f/rsvp/dyc/resPurchase.do?rand=20160106115448S
	    	// https://aswbe-d.ana.co.jp/Axkow23/dms/dyc/be/pages/res/reservation/operationComplete.xhtml?rand=20160905121110
			// https://aswbe-d.ana.co.jp/9Eile48/dms/red12l/dyc/be/pages/res/reservation/operationComplete.xhtml?rand=20180217234532
	    	patt = new RegExp(/https:\/\/aswbe-d.ana.co.jp\/.+?\/dms\/.+?\/dyc\/be\/pages\/res\/reservation\/operationComplete.xhtml\?rand=[0-9]+/);
    	    res = patt.test(loc);
			
    	    if (res) {
			
    	    	// CopyANAToAppli
    	    	console.log('setFlightInformation start');
    	    	setFlightInformation(1);
				setTimeout(function(){
					console.log($('a.btnAside')[0]);
					$(document).ready(function(){
						$('a.btnAside')[0].click();
					})	
				}, CMS_TIMEOUT_INMILISECONDS);
    	    	console.log('setFlightInformation done');
    	    } else {
				patt = new RegExp(/https:\/\/aswbe-d.ana.co.jp\/.+?\/dms\/.+?\/dyc\/be\/pages\/res\/reservation\/operationComplete.xhtml\?aswdcid=[0-9]+/);
				res = patt.test(loc);
				if(res){
					console.log('setFlightInformationPrice start');	
					setFlightInformation(0);
					console.log('setFlightInformationPrice done');
				} else if(loc.toString().indexOf('dyc/be/pages/res/reservation/operationComplete.xhtml') != -1) {
				
					// CopyANAToAppli
					console.log('setFlightInformation start');	
					setFlightInformation(1);
					setTimeout(function(){
							$('.btnAside').trigger('click');
					}, CMS_TIMEOUT_INMILISECONDS);
					
					console.log('setFlightInformation done');
				} else {
					//patt = new RegExp(/pages/retrieve/reserveSearchInput.xhtml/);
					//res = patt.test(loc);
					//if (res) {
					if(loc.toString().indexOf('pages/retrieve/reserveSearchInput.xhtml') != -1)  {
						setTimeout(function(){
						line_no = $.trim(sessionStorage.getItem('line_no'));
						cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
						},500);
						//console.log(line_no);
						//console.log(cms_app_id);
						setTimeout(function(){
							//getItem('application_flight_date' + line_no,"reserveEmbarkationDay", 'name');
							
							getItem('application_flightdatefull' + line_no,"reserveEmbarkationDay");
							getItem('application_flightdatefull' + line_no,"calendar_roundTrip_outbound01", 'name');
							
							getItem('application_flight_no' + line_no,"reserveFlightNumber", 'name');
							getItem('application_ticket_reservation_no' + line_no,"reserveNumber", 'name');	
							getItem('application_last_name' + line_no,"reserveLastName", 'name');
							getItem('application_first_name' + line_no,"reserveFirstName", 'name');
							getItem('application_ticket_reservation_no' + line_no,"chgSearchForm.reserveNumber", 'endConfirmAna');
							clearAll(cms_app_id, line_no);
							setTimeout(function() {
								$('.searchReceipt input[type="submit"]:first').get(0).click();	
							} , 1500);
							
							getItem('application_mileage_flag'+line_no,"mileage_ana", 'mileage_ana');

							//$($get("input[name = 'j_idt320']"))[0].click();
							//$("input[name = 'j_idt320']").trigger('click');
							//$("input[name = 'j_idt320']").click();
							//$(".btnBase.btnMainStream.btnWidthVariable.btnVerticalMain").trigger('click');
							//var script = $.trim($("input[name = 'j_idt320']").eq(0).attr('onclick'));
							//eval(script);
						}, CMS_TIMEOUT_INMILISECONDS);
						console.log('setANAConfirmation done');
						
					}   

					if(loc.toString().indexOf('pages/option/ffpCardinformationInput.xhtml') != -1)  {
						setTimeout(function(){
							for (i=0; i<=5; i++) {
								getItem('application_traveller_list_' + i.toString() + '_name_ana','paxPc:'+i+':userId', 'mileage_no_ana');
							}
						   
							$('.btnArrowNext>input').trigger('click');
							
					   }, CMS_TIMEOUT_INMILISECONDS);
					}
				}
			}
	     } // end else of last page
	   } // end else of input page
	} else if(loc.toString().indexOf('rps.ana.co.jp/web/top.php') != -1)  {
		curA = $("a").filter(function() {
			return $(this).text() == '5.座席指定/変更';
		});
		href = $(curA).attr('href');
		location.href = href;
	} 
	
	
});