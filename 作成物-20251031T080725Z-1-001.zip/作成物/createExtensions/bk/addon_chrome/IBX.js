﻿	function setFlightInformationIBX() {
		var strLimitDate = '';
		var strLimitDateText = '';
		var data_callback = '';
		
		curTable = getTableByTextContain('購入期限');
		if (typeof(curTable[0]) != 'undefined') {
			strLimitDate = getCellValueInTable(curTable, 1, 2);
		}
		dtmLimitDate = getLimitDateText('購入期限');

		curTable = getTableByTextContain('搭乗日');
		if (typeof(curTable[0]) != 'undefined') {
			strValue = "";
			strText = "";
			
			dtmFlightDate = fixSkyDate(getCellValueInTable(curTable, 2, 1));
			if (dtmFlightDate.getFullYear() != DATE_MIN_VAL) {
				if (strLimitDate != '搭乗日当日') {
					strLimitDate2 = formatDate(dtmLimitDate);
				} else {
					dtmLimitDate2 = new Date(dtmFlightDate.getFullYear(), dtmFlightDate.getMonth(), dtmFlightDate.getDate());
					dtmLimitDate2.setDate(dtmLimitDate2.getDate() - 1);
					strLimitDate2 = formatDate(dtmLimitDate2);
				}
				airline = fixAnaAirline(getCellValueInTable(curTable, 2, 2));
				flightno = fixAnaFlightNo(getCellValueInTable(curTable, 2, 2));
				kukan = getCellValueInTable(curTable, 2, 3);
				kukan = kukan.split(" → ");
				dep = fixJalAirportName(kukan[0]);
				des = fixJalAirportName(kukan[1]);
				deptime = getCellValueInTable(curTable, 2, 4);
				destime = getCellValueInTable(curTable, 2, 5);
				ticket_type = getCellValueInTable(curTable, 2, 6);
				reserno = getCellValueInTable(curTable, 2, 7);
				seat = "普通";
				hourdep = deptime.replace(":","/");
				hourdes = destime.replace(":","/");

				strValue = formatDate(dtmFlightDate) + "/" + airline +"/" + flightno + "/" + dep + "/" + des;
				strText = strValue;
				strValue += "/"+ hourdep  + "/" + hourdes + "/" + reserno + "/"+ strLimitDate2 + "/" + seat;
				strValue += "/"+ ticket_type;
				
				line_no = sessionStorage.getItem('line_no');
				carrier = sessionStorage.getItem('carrier');
				data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
			}
			console.log(data_callback);
			cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			line_no = $.trim(sessionStorage.getItem('line_no'));
			setTimeout(function(){
				setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
			}, CMS_TIMEOUT_INMILISECONDS);
		}
	}
	
	$( document ).ready(function() {
		var domain_name = document.domain;
		var loc = window.location;
		if(domain_name=="rsv.ibexair.co.jp"){
			//IBX input
			if(loc.toString().indexOf("/rsv_p/aln_web/resVacant3.do") != -1){
				setTimeout(function(){
					getItem("application_tel1","contactForm.telNo","name");
					for(i= 0; i < 6; i++){
						getItem('application_traveller_list_' + i.toString() + '_last_name',"paxInfantForm.lastName[" + i + "]","name");
						getItem('application_traveller_list_' + i.toString() + '_first_name',"paxInfantForm.firstName[" + i + "]","name");
						getItem('application_traveller_list_' + i.toString() + '_age',"paxInfantForm.age[" + i + "]","name");
						getItem('application_traveller_list_' + i.toString() + '_sex',"paxInfantForm.sexCode[" + i + "]","radio");
					}
					for(i= 0; i < 2; i++){
						getItem('application_infant_list_' + i.toString() + '_first_name',"paxInfantForm.infFirstName[" + i + "]","name");
						getItem('application_infant_list_' + i.toString() + '_age',"paxInfantForm.infAge[" + i + "]","select");
						getItem('application_infant_list_' + i.toString() + '_sex',"paxInfantForm.infSexCode[" + i + "]","radio");
					}
					getItem("application_yoyaku_email_first","contactForm.bdgMailAccount","name");
					getItem("application_yoyaku_email_next","contactForm.bdgMailDomain","name");
				}, CMS_TIMEOUT_INMILISECONDS);
			}
			//IBX Complete
			if(loc.toString().indexOf('rsv_p/aln_web/resPurchase.do?rand') != -1) {
				setFlightInformationIBX();
				console.log('setFlightInformationIBX done');
			}
			if(loc.toString().indexOf('rsv.ibexair.co.jp/rsv_p/aln_web/BERetrieve.do') != -1)  {
				setTimeout(function(){
					line_no = $.trim(sessionStorage.getItem('line_no'));
					cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				},500);
				setTimeout(function(){
					getItem('application_last_name' + line_no,"searchWideForm.lastName", 'name');
					getItem('application_first_name' + line_no,"searchWideForm.firstName", 'name');
					getItem('application_flight_no' + line_no,"searchWideForm.fltNo", 'name');
					getItem('application_flight_year' + line_no,"searchWideForm.selectedEmbYear", 'name');
					getItem('application_flight_month' + line_no,"searchWideForm.selectedEmbMonth", 'name');
					getItem('application_flight_day' + line_no,"searchWideForm.selectedEmbDay", 'name');
					getItem('application_ticket_reservation_no' + line_no,"searchWideForm.rsvNo", 'name');
					getItem('application_ticket_reservation_no' + line_no,"searchWideForm.rsvNo", 'endConfirmIBX');
					clearAll(cms_app_id, line_no);
					setTimeout(function() {
						$("input[name = 'btnSubmit:mapping=success']").click();
					} , 1500);
	    	    }, CMS_TIMEOUT_INMILISECONDS);
	    	    console.log('setIBXConfirmation done');
			} 
		}
	});