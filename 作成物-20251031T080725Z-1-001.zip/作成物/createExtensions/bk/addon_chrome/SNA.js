﻿	function setFlightInformationSna() {
		var strLimitDate = '';
		var strLimitDateText = '';
		var data_callback = '';
		
		curTable = $('.p-booking-box-item-date--name').eq(0);
		if (typeof(curTable[0]) != 'undefined') {
			strLimitDate = $('.p-booking-box-item-date--value').html();
		}
		//strLimitDate = fixAnaDate(strLimitDateText);
		//strLimitDate = formatDate(strLimitDate);//2016/01/09
		//dtmLimitDate = getLimitDateCom('購入期限');
		dtmLimitDate = getLimitDateSna();
		if (typeof(curTable[0]) != 'undefined') {
			strValue = "";
			strText = "";
			
			
			dtmFlightDate = fixAnaDate($('.c-flight-section__day').html().split('年')[1]);
			if (dtmFlightDate.getFullYear() != DATE_MIN_VAL) {
				if (strLimitDate != '搭乗日当日') {
					strLimitDate2 = formatDate(dtmLimitDate);
				} else {
					dtmLimitDate2 = new Date(dtmFlightDate.getFullYear(), dtmFlightDate.getMonth(), dtmFlightDate.getDate());
					dtmLimitDate2.setDate(dtmLimitDate2.getDate() - 1);
					strLimitDate2 = formatDate(dtmLimitDate2);
				}				
				//dtmFlightDate = formatDate(dtmFlightDate);
				$('.c-table-body .c-table-view-val .c-table-view-model').remove();
				airline = fixAnaAirline($('.c-table-body .c-table-view-val').eq(0).text());
				flightno = fixAnaFlightNo($('.c-table-body .c-table-view-val').eq(0).text());
				dep = fixJalAirportName($('.c-flight-section__departure').html());
				des = fixJalAirportName($('.c-flight-section__arrival').html());
				deptime = $('.c-flight-section__departure span').html();
				destime = $('.c-flight-section__arrival span').html();
				ticket_type = $('.c-table-body a').eq(0).html();
				reserno = $.trim($('.p-reservation-flight-number dd').html());
				seat = "普通";
				hourdep = deptime.replace(":","/");
				hourdes = destime.replace(":","/");
				//value=//2009/03/31/JAL/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				//text =//3月30日（月）/JAL/548/札幌(千歳)/東京(羽田)
				strValue = formatDate(dtmFlightDate) + "/" + airline +"/" + flightno + "/" + dep + "/" + des;
				strText = strValue;
				strValue += "/"+ hourdep  + "/" + hourdes + "/" + reserno + "/"+ strLimitDate2 + "/" + seat;
				strValue += "/"+ ticket_type;
				line_no = sessionStorage.getItem('line_no');
				carrier = sessionStorage.getItem('carrier');
				data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
				console.log(data_callback);
			}
			cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			line_no = $.trim(sessionStorage.getItem('line_no'));
			setTimeout(function(){
				setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
			}, CMS_TIMEOUT_INMILISECONDS);
		}
	}
	

	$( document ).ready(function() {
		var domain_name = document.domain;
		var loc = window.location;
		
		if(domain_name=="resv.solaseedair.jp"){
			//SNA input
			if(loc.toString().indexOf('reservationPaxInformationInput.xhtml') != -1) {
				setTimeout(function(){
					for(i= 0; i < 6; i++){
						if(i==0){
							getItem('application_traveller_list_' + i.toString() + '_last_name',"paxInfoListLoop:" + i + ":paxLastName","name");
							getItem('application_traveller_list_' + i.toString() + '_first_name',"paxInfoListLoop:" + i + ":paxFirstName","name");
							getItem('application_traveller_list_' + i.toString() + '_age',"paxInfoListLoop:" + i + ":age","name");
							getItem('application_traveller_list_' + i.toString() + '_sex',"paxInfoListLoop:" + i + ":sexCode","radio");
							getItem('application_tel1',"paxInfoListLoop:" + i + ":telephoneNumberKind","selectTelephoneSNA");
							getItem('application_tel1',"paxInfoListLoop:" + i + ":telephoneNumber","name");
							getItem('reserve_email',"paxInfoListLoop:" + i + ":mailAddless","name");
							getItem('reserve_email',"paxInfoListLoop:" + i + ":confirmMailAddless","name");
						}else{
							getItem('application_traveller_list_' + i.toString() + '_last_name',"paxInfoListLoop:" + i + ":paxLastName2","name");
							getItem('application_traveller_list_' + i.toString() + '_first_name',"paxInfoListLoop:" + i + ":paxFirstName2","name");
							getItem('application_traveller_list_' + i.toString() + '_age',"paxInfoListLoop:" + i + ":age2","name");
							getItem('application_traveller_list_' + i.toString() + '_sex',"paxInfoListLoop:" + i + ":sexCode2","radio");
						}
					}
					for(i= 0; i < 2; i++){
						getItem('application_infant_list_' + i.toString() + '_last_name',"j_idt246:" + i + ":infLastName","name");
						getItem('application_infant_list_' + i.toString() + '_first_name',"j_idt246:" + i + ":infFirstName","name");
						getItem('application_infant_list_' + i.toString() + '_age',"j_idt246:" + i + ":infAge","name");
						getItem('application_infant_list_' + i.toString() + '_sex',"j_idt246:" + i + ":infSexCode","radio");
						getItem('guardian_no_'+ i.toString(),"j_idt246:" + i + ":parentPaxNumber","select");
					}
					getItem('application_tel1',"consentConfirmFlag", 'endConfirmSNA');
				}, CMS_TIMEOUT_INMILISECONDS);
			}
			//SNA Complete
			if(loc.toString().indexOf('reservationDetailReview.xhtml') != -1 || loc.toString().indexOf('reservationSearchInput.xhtml') != -1) {
				setFlightInformationSna();
				console.log('setFlightInformationSna done');
			}
			if(loc.toString().indexOf('reservationSearchInput.xhtml?rand=') != -1)  {
				setTimeout(function(){
					line_no = $.trim(sessionStorage.getItem('line_no'));
					cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				},500);
				setTimeout(function(){
	    	    		getItem('application_flightdatefull' + line_no,"reserveEmbarkationDay", 'name');
						getItem('application_flightdatefull' + line_no,"embarkationDay01", 'name');
						getItem('application_flight_no' + line_no,"reserveFlightNumber", 'name');
						getItem('application_ticket_reservation_no' + line_no,"reservationNumber", 'name');
						getItem('application_last_name' + line_no,"reserveLastName", 'name');
	    	    		getItem('application_first_name' + line_no,"reserveFirstName", 'name');
	    	    		//getItem('application_ticket_reservation_no' + line_no,"endConfirmSNA", 'endConfirmSNA');
	    	    		clearAll(cms_app_id, line_no);
						setTimeout(function() {
							$("input[name='searchButton']").click();
						} , 1500);
	    	    }, CMS_TIMEOUT_INMILISECONDS);
	    	    console.log('setSNAConfirmation done');
			} 
		}  else {
		}
	});