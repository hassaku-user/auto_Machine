
function setCallBackANA() {
	app_id = "#" + $('#application_application_id').val();
    getItem (app_id + '_merchant_flight_info_callback','merchant_flight_info_callback_ANA', 'parse_call_back_ana');
}

function setCallBackJAL() {
	app_id = "#" + $('#application_application_id').val();
    getItem (app_id + '_merchant_flight_info_callback','merchant_flight_info_callback_JAL', 'parse_call_back_jal');
}

function setCallBackAPJC() {
    app_id = "#" + $('#application_application_id').val();
    getItem (app_id + '_merchant_flight_info_callback','merchant_flight_info_callback_ANA', 'parse_call_back_apjc');
}



function fixJalSeat(strSeat) {
	strSeat = strSeat.toString();
	if (strSeat.indexOf("クラス Ｊ") > -1) {
		return "クラスJ";
	} else if (strSeat.indexOf("ファーストクラス") > -1) {
		return "ファーストクラス";
	} else {
		return "普通";
	}
 }
 
function getJalDepTime(strText) {

  //東京(羽田) [ 07：10 ]
  var intHour="";
  var intMinute="";
  
  strText = strText.toString();
  var result = strText.match("([0-9]{1,2}(：|:)[0-9]{1,2})");
  return result[0];
}

function fixSkyDate(strText) {

    //2012年11月28日(水) 23:59
	
	strText = strText.toString();
	var result = strText.match("([0-9]+)年([0-9]+)月([0-9]+)日");

    if (result.length > 0) {
		var year = result[1];
        var month = result[2];
		var day = result[3];
		var dtmDate = new Date(year, month - 1, day);
		return dtmDate;
    }
	return new Date(DATE_MIN_VAL,1,1);
}

function fixAnaDate(strText) {
	// 3月31日(火)
	intPos = 0;
	intMonth = 0;
	intDay = 0;
	intYear = 0;
	dtmNow = 0;
	dtmDate = 0;
    dtmNow = new Date();
    intYear = dtmNow.getFullYear();
	strText = strText.toString(); 
    intPos = strText.indexOf("月");
    if (intPos != -1 ) {
        intMonth = parseInt(strText.substring(0, intPos));        
        strText = strText.substring(intPos + 1);
        intPos = strText.indexOf("日");
        if (intPos != -1 ) {
            intDay = parseInt(strText.substring(0, intPos));         
            dtmDate = new Date(intYear, intMonth - 1, intDay);
            if (formatDate(dtmDate) < formatDate(dtmNow)) {
                dtmDate = new Date(intYear + 1, intMonth - 1, intDay);
            }
            return dtmDate;
         }
    }
	return new Date(DATE_MIN_VAL,1,1);               
}
 // start from 1;
 function getCellValueInTable(table, iRow, iCol) {
    curRow = table.find('tr:nth-child('+ iRow +')').first();
	return $.trim(curRow.find('td:nth-child('+ iCol +')').first().text()).replace(/(\r\n|\n|\r)/gm," ");
 }

 function getCellValueInTableTH(table, iRow, iCol) {
    curRow = table.find('tr:nth-child('+ iRow +')').first();
	return $.trim(curRow.find('th:nth-child('+ iCol +')').first().text()).replace(/(\r\n|\n|\r)/gm," ");
 }
 
 function getCellValueInTableSmart(table, iRow, iCol) {
	return $.trim(table.find('tr td:nth-child('+ iCol +')').first().text()).replace(/(\r\n|\n|\r)/gm," ");
 }
  
 function getTableByTextContain(strText) {
	curRow = $("td").filter(function() {
		return $(this).text() == strText;
	}).parent("tr");
	return curRow.parent().parent(); // because table have <table><tbody><tr>
 }
 
 function getTableByTextContainTH(strText) {
	curRow = $("th").filter(function() {
		return $(this).text() == strText;
	}).parent("tr");
	return curRow.parent().parent(); // because table have <table><tbody><tr>
 } 

 function getTableByClassName(strClassName) {
	return $('.' + strClassName);
 }

 function getLimitDate() {
    var dtmLimitDate = new Date();
	curTable = getTableByTextContain('お支払い期限');
	if (typeof(curTable[0]) != 'undefined') {
		strLimitDate = getCellValueInTable(curTable, 1, 2);
		if (strLimitDate != "搭乗日当日") {
			dtmLimitDate = fixAnaDate(strLimitDate);
		}
	} else {
		curTable = getTableByTextContain('お支払い期間');
		if (typeof(curTable[0]) != 'undefined') {
			dtmLimitDate = new Date();
			dtmLimitDate.setDate(dtmLimitDate.getDate() + 2);
		}
	}
	return dtmLimitDate;
}

function getLimitDateAna() {
    var dtmLimitDate = new Date();
	strText = $.trim($('.paymentLimit dt').html());
	if (strText == 'お支払い期限') {
		strLimitDate = $('.paymentLimit dd em').html();
		if (strLimitDate != "搭乗日当日") {
			temp = strLimitDate.split("年");
			strLimitDate = temp[1];
			dtmLimitDate = fixAnaDate(strLimitDate);
		}
	} else {
		curTable = getTableByTextContain('お支払い期間');
		strText = $.trim($('.paymentLimit dt').html());
		if (strText == 'お支払い期間') {
			dtmLimitDate = new Date();
			dtmLimitDate.setDate(dtmLimitDate.getDate() + 2);
		}
	}
	return dtmLimitDate;
}

 /*function getLimitDateSmartTicket() {
    var dtmLimitDate = new Date();
	curTable = getTableByTextContainTH('お支払い期限');
	curTable = $(curTable);
	if (typeof(curTable[0]) != 'undefined') {
		strLimitDate = getCellValueInTable(curTable, 2, 1);
		if (strLimitDate != "搭乗日当日") {
			strLimitDate = strLimitDate.split('～');
			strLimitDate = $.trim(strLimitDate[1]);
			dtmLimitDate = fixAnaDate(strLimitDate);
		}
	} else {
		curTable = getTableByTextContainTH('お支払い期間');
		curTable = $(curTable);
		if (typeof(curTable[0]) != 'undefined') {
			dtmLimitDate = new Date();
			dtmLimitDate.setDate(dtmLimitDate.getDate() + 2);
		}
	}
	return dtmLimitDate;
}*/

function getLimitDateSmartTicket() {
    var dtmLimitDate = new Date();
	curTable = getTableByTextContainTH('お支払い期限');
	curTable = $(curTable);
	if (typeof(curTable[0]) != 'undefined') {
		strLimitDate = getCellValueInTable(curTable, 2, 1);
		if (strLimitDate != "搭乗日当日") {
			strLimitDate = strLimitDate.split('～');
			strLimitDate = $.trim(strLimitDate[1]);
			strLimitDate = strLimitDate.split(' ');
			strLimitDate = $.trim(strLimitDate[0]);
			dtmLimitDate = strLimitDate.toString().replace('-', '/').replace('-', '/');
		}
	} else {
		curTable = getTableByTextContainTH('お支払い期間');
		curTable = $(curTable);
		if (typeof(curTable[0]) != 'undefined') {
			strLimitDate = getCellValueInTable(curTable, 2, 1);
			if (strLimitDate != "搭乗日当日") {
				strLimitDate = strLimitDate.split('～');
				strLimitDate = $.trim(strLimitDate[1]);
				strLimitDate = strLimitDate.split(' ');
				strLimitDate = $.trim(strLimitDate[0]);
				dtmLimitDate = strLimitDate.toString().replace('-', '/').replace('-', '/');
			}
		}
	}
	return dtmLimitDate;
}




 function getLimitDateCom(strText) {
    var dtmLimitDate = new Date();
	curTable = getTableByTextContain(strText);
	if (typeof(curTable[0]) != 'undefined') {
		strLimitDate = getCellValueInTable(curTable, 1, 2);
		if (strLimitDate != "搭乗日当日") {
			dtmLimitDate = fixAnaDate(strLimitDate);
		}
	} else {
		curTable = getTableByTextContain('お支払い期間');
		if (typeof(curTable[0]) != 'undefined') {
			dtmLimitDate = new Date();
			dtmLimitDate.setDate(dtmLimitDate.getDate() + 2);
		}
	}
	return dtmLimitDate;
}

 function getLimitDateSna() {
    var dtmLimitDate = new Date();
	curTable = $('.p-booking-box-item-date--name');
	if (typeof(curTable[0]) != 'undefined') {
		strLimitDate = $('.p-booking-box-item-date--value').html().split('年')[1];
		if (strLimitDate != "搭乗日当日") {
			dtmLimitDate = fixAnaDate(strLimitDate);
		}
	} else {
		curTable = $('.p-booking-box-item-date--name');
		if (typeof(curTable[0]) != 'undefined') {
			dtmLimitDate = new Date();
			dtmLimitDate.setDate(dtmLimitDate.getDate() + 2);
		}
	}
	return dtmLimitDate;
}

function getLimitDateText(strText) {
    var dtmLimitDate = new Date();
	curTable = getTableByTextContain(strText);
	if (typeof(curTable[0]) != 'undefined') {
		strLimitDate = getCellValueInTable(curTable, 1, 2);
		if (strLimitDate != "搭乗日当日") {
			dtmLimitDate = fixSkyDate(strLimitDate);
		}
	} else {
		curTable = getTableByTextContain('お支払い期間');
		if (typeof(curTable[0]) != 'undefined') {
			dtmLimitDate = new Date();
			dtmLimitDate.setDate(dtmLimitDate.getDate() + 2);
		}
	}
	return dtmLimitDate;
}

function getLimitDateFda() {
    var dtmLimitDate = new Date();

	strLimitDate = $('.reservation-date').html();
	if (strLimitDate != "搭乗日当日") {
		dtmLimitDate = fixAnaDate(strLimitDate);
	}
	
	return dtmLimitDate;
}

function getLimitDateComFromDateText(strText) {
	var dtmLimitDate = new Date();
	if (strText != "") {
		strLimitDate = strText;
		if (strLimitDate != "搭乗日当日") {
			dtmLimitDate = fixAnaDate(strLimitDate);
		}
	} else {
			dtmLimitDate = new Date();
			dtmLimitDate.setDate(dtmLimitDate.getDate() + 2);
	}
	return dtmLimitDate;
}
function getLimitDateComFromDateAdo(strText) {
	var dtmLimitDate = new Date();
	if (strText != "") {
		strLimitDate = strText;
		if (strLimitDate != "搭乗日当日") {
			dtmLimitDate = fixSkyDate(strLimitDate);
		}
	} else {
			dtmLimitDate = new Date();
			dtmLimitDate.setDate(dtmLimitDate.getDate() + 2);
	}
	return dtmLimitDate;
}

function pad (str, max) {
  str = str.toString();
  return str.length < max ? pad("0" + str, max) : str;
}


// get must add 1 for month
function formatDate(dateTime)  {
	return dateTime.getFullYear() + '/' + pad(dateTime.getMonth() + 1, 2) + '/' + pad(dateTime.getDate(), 2);
}

function fixAnaTime(strText) {
	//12:30
	//14:05
	intPos = -1;
	intHour = 0;
	intMinute = 0;
	dtmTime = '';
	strText = strText.toString();
	intPos = strText.indexOf(":");
	if (intPos != -1) {
		intHour = parseInt(strText.substring(0, intPos));
		intMinute = parseInt(strText.substring(intPos + 1));
		dateNow = new Date();
		dtmTime = new Date(dateNow.getFullYear(), dateNow.getMonth(), dateNow.getDate(), intHour, intMinute, 0);
		return dtmTime;
	}
	return new Date(DATE_MIN_VAL,1,1,0,0,0);    
}
		

function fixAnaTimeOver24Hour(strText) {
	intPos = -1;
	intHour = 0;
	intMinute = 0;
    dtmTime = new Array(2);
	strText = strText.toString();
	intPos = strText.indexOf(":");
	if (intPos != -1)
	{
		intHour = parseInt(strText.substring(0, intPos));
		intMinute = parseInt(strText.substring(intPos + 1));
		dtmTime[0] = intHour;
		dtmTime[1] = intMinute;
	}
	return dtmTime;
}

  function fixAnaDepartureAirport(strText) {
	vntItems = strText.split("  ");////半角スペース２つ
	if (vntItems.length > 0 ) {
		return $.trim(vntItems[0].toString());
	}
	return "";

 }
 
   function fixAnaArrivalAirport(strText) {
	vntItems = strText.split("  ");////半角スペース２つ
	if (vntItems.length > 1 ) {
		return $.trim(vntItems[1].toString());
	}
	return "";

 }

        
	function fixAnaFlightNo(strJalFlightNo) {

		if (strJalFlightNo.length > 3) {
			return $.trim(strJalFlightNo.toString().substring(3));
		}
		return "";
	}

	function fixAnaAirline(strJalFlightNo) {
		if (strJalFlightNo.length > 3 ) {
			return $.trim(strJalFlightNo.substring(0, 3));
		}
		return "";
	}

	function fixAnaSeat(strSeat) {
		strSeat = strSeat.toString();
		if (strSeat.indexOf("普通席") > -1) {
			return "普通";
		} else if (strSeat.indexOf("普通") > -1) {
			return "普通";
		} else {
			return "プレミアム";
		}
	}
	
	function fixJalAirportName(strText) {
		strResult = '';
		//東京(羽田) [ 18：30 ]
		strText = strText.toString();
		strText = $.trim(strText.toString());
		var result = strText.match("[^0-9\s\[]+");
  		strText = $.trim(result[0]);
		strText = strText.replace('（', '(').replace('）', ')').replace('<', '');
		switch (strText) {
			case "札幌丘珠":
				strResult = "札幌(丘珠)";
				break;
			case "札幌千歳":
			case "札幌 新千歳":
				strResult = "札幌(千歳)";
				break;
			//Added 20150403
			case "新千歳":
				strResult = "札幌(千歳)";
				break;
			//End Added Hung20150403
			//Added 20150427
			case "札幌新千歳":
				strResult = "札幌(千歳)";
				break;
			//End Added Hung20150427
			case "東京羽田":
				strResult = "東京(羽田)";
				break;
			case "東京成田":
			case "東京 成田":
				strResult = "東京(成田)";
				break;
			case "名古屋中部":
				strResult = "名古屋(中部)";
				break;
			case "名古屋小牧":
				strResult = "名古屋(小牧)";
				break;
			case "大阪伊丹":
				strResult = "大阪(伊丹)";
				break;
			case "大阪関西":
				strResult = "大阪(関西)";
				break;
			//Added Hung20150414
			case "大阪(関西空港)":
				strResult = "大阪(関西)";
				break;
			//End Added Hung20150414
			case "大阪(神戸)":
				strResult = "神戸";
				break;
			//Added Hung20150414
			case "松山/愛媛":
				strResult = "松山";
				break;
			//End Added Hung20150414
			//Added Hung20150427
			case "沖縄那覇":
				strResult = "那覇";
				break;
			case "広島空港":
				strResult = "広島";
				break;
			case "佐賀空港":
				strResult = "佐賀";
				break;
			case "札幌(新千歲)":
			case "札幌(新千歳":
				strResult = "札幌(千歳)";
				break;
			//End Added Hung20150427
			default:
				strResult = strText;
				break;
			}
		return strResult;
	}
	function fixJJPAirportName(strText) {
		strResult = '';
		//東京(羽田) [ 18：30 ]
		strText = strText.toString();
		strText = $.trim(strText.toString());
		var result = strText.match("[^0-9\s\[]+");
  		strText = $.trim(result[0]);
		strText = strText.replace('（', '(').replace('）', ')');
		switch (strText) {
			case "札幌丘珠":
				strResult = "札幌(丘珠)";
				break;
			case "札幌千歳":
			case "札幌":
			case "札幌 新千歳":
				strResult = "札幌(千歳)";
				break;
			//Added 20150403
			case "新千歳":
				strResult = "札幌(千歳)";
				break;
			//End Added Hung20150403
			//Added 20150427
			case "札幌新千歳":
				strResult = "札幌(千歳)";
				break;
			//End Added Hung20150427
			case "東京羽田":
				strResult = "東京(羽田)";
				break;
			case "東京成田":
			case "東京":
				strResult = "東京(成田)";
				break;
			case "名古屋中部":
				strResult = "名古屋(中部)";
				break;
			case "名古屋小牧":
				strResult = "名古屋(小牧)";
				break;
			case "大阪伊丹":
				strResult = "大阪(伊丹)";
				break;
			case "大阪関西":
				strResult = "大阪(関西)";
				break;
			//Added Hung20150414
			case "大阪(関西空港)":
				strResult = "大阪(関西)";
				break;
			//End Added Hung20150414
			case "大阪(神戸)":
				strResult = "神戸";
				break;
			//Added Hung20150414
			case "松山/愛媛":
				strResult = "松山";
				break;
			//End Added Hung20150414
			//Added Hung20150427
			case "沖縄那覇":
				strResult = "那覇";
				break;
			case "ISHIGAKI ISG":
			case "ISHIGAKIISG":
			case "ISHIGAKI ISG":
				//strResult = "石垣";
				strResult = "ISG";
				break;
			case "Hakodate":
			case "Hakodate HKD":
			case "HakodateHKD":
				//strResult = "函館";
				strResult = "HKD";
				break;
			default:
				strResult = strText;
				break;
			}
		console.log('airport ' + strText + " result " + strResult);
		return strResult;
	}	
	
function checkAnaConfirmAllFilled() {
	array = new Array();
	getItem('application_flight_date',"chgSearchForm.selectedEmbDate", 'name');	
	    	    		getItem('application_last_name',"chgSearchForm.lastName", 'name');
	    	    		getItem('application_first_name',"chgSearchForm.firstName", 'name');
	    	    		getItem('application_flight_no',"chgSearchForm.flightNumber", 'name');
	    	    		getItem('application_flight_month',"chgSearchForm.selectedEmbMonth", 'name');
	    	    		getItem('application_flight_day',"chgSearchForm.selectedEmbDay", 'name');
	    	    		getItem('application_ticket_reservation_no',"chgSearchForm.reserveNumber", 'name');
}
	
function getHourString(vntTime) {
	return pad(vntTime.getHours(), 2);
}

function getMinuteString(vntTime) {
	return pad(vntTime.getMinutes(), 2);
}	

function getStringAdultChildIndex() {
	airPortName = $('#glbCurAirport').val().toString().toUpperCase();
	strAdult = '';
	strChild = '';
	for (i = 0; i < 9; i++) {
		ageEle = "application[traveller_list][" + i.toString() + "][age]";
		ageValue = parseInt($("[name='"+ ageEle +"']").val());
		if (12<= ageValue && ageValue <=999) {
			strAdult += i.toString() + '|';	
		}
		
		if (2<= ageValue && ageValue <=11) {
			strChild += i.toString() + '|';	
		}  
	}
	strAdult = strAdult.substring(0, strAdult.length - 1);
	strChild = strChild.substring(0, strChild.length - 1);
	return strAdult + ';' +  strChild;
}

 var glbKanaList = new Array(
            "キャ", "キュ", "キョ",
            "ギャ", "ギュ", "ギョ",
            "シャ", "シュ", "シェ", "ショ",
            "ジャ", "ジュ", "ジェ", "ジョ",
            "チャ", "チュ", "チェ", "チョ",
            "ニャ", "ニュ", "ニェ", "ニョ",
            "ヒャ", "ヒュ", "ヒョ",
            "ビャ", "ビュ", "ビョ",
            "ピャ", "ピュ", "ピョ",
            "ミャ", "ミュ", "ミョ",
            "リャ", "リュ", "リョ",
            "テャ", "ティ", "テュ", "テェ", "テョ",
            "ガ", "ギ", "グ", "ゲ", "ゴ",
            "ザ", "ジ", "ズ", "ゼ", "ゾ",
            "ダ", "ヂ", "ヅ", "デ", "ド",
            "バ", "ビ", "ブ", "ベ", "ボ",
            "パ", "ピ", "プ", "ペ", "ポ",
            "ア", "イ", "ウ", "エ", "オ",
            "カ", "キ", "ク", "ケ", "コ",
            "サ", "シ", "ス", "セ", "ソ",
            "タ", "チ", "ツ", "テ", "ト",
            "ナ", "ニ", "ヌ", "ネ", "ノ",
            "ハ", "ヒ", "フ", "ヘ", "ホ",
            "マ", "ミ", "ム", "メ", "モ",
            "ヤ", "ユ", "ヨ",
            "ラ", "リ", "ル", "レ", "ロ",
            "ワ", "ヲ",
            "ン"
        );

 var glbRomaList = new Array(
            "kya", "kyu", "kyo",
            "gya", "gyu", "gyo",
            "sha", "shu", "she", "sho",
            "ja", "ju", "je", "jo",
            "cha", "chu", "che", "cho",
            "nya", "nyu", "nye", "nyo",
            "hya", "hyu", "hyo",
            "bya", "byu", "byo",
            "pya", "pyu", "pyo",
            "mya", "myu", "myo",
            "rya", "ryu", "ryo",
            "tha", "thi", "thu", "the", "tho",
            "ga", "gi", "gu", "ge", "go",
            "za", "ji", "zu", "ze", "zo",
            "da", "di", "du", "de", "do",
            "ba", "bi", "bu", "be", "bo",
            "pa", "pi", "pu", "pe", "po",
            "a", "i", "u", "e", "o",
            "ka", "ki", "ku", "ke", "ko",
            "sa", "shi", "su", "se", "so",
            "ta", "chi", "tsu", "te", "to",
            "na", "ni", "nu", "ne", "no",
            "ha", "hi", "fu", "he", "ho",
            "ma", "mi", "mu", "me", "mo",
            "ya", "yu", "yo",
            "ra", "ri", "ru", "re", "ro",
            "wa", "wo",
            "n");
function convKata2Romaji(nameKata, nameRomaji) {
	roma = '';
	if (nameRomaji != '' && nameRomaji != null) {
		return nameRomaji.toUpperCase();
	}
    tsu = false;
    srcKana = nameKata;
    while (srcKana != "") {
        convFrom = "";
        convTo = "";
        if (srcKana.substring(0, 1) == "ッ") {
            srcKana = srcKana.substring(1);
            tsu = true;
            continue;
        }

        for (convIndex = 0; convIndex < glbRomaList.length; ++convIndex) {
            convFrom = glbKanaList[convIndex];
            if (srcKana.indexOf(convFrom) == 0) {
                if (tsu) {
                    convTo = glbRomaList[convIndex].substring(0, 1);
                }
                convTo += glbRomaList[convIndex];
                break;
            }
        }

        if (convTo != "") {
            roma += convTo;
            srcKana = srcKana.substring(convFrom.length);
        } else {
            roma += srcKana.substring(0, 1);
            srcKana = srcKana.substring(1);
        }
        tsu = false;
    }
    return roma.toUpperCase();
}

// check format yyyy-mm-dd
function checkYMDFormat(strDate) {
	patt = new RegExp("^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})$");
    return patt.test(strDate);
	
}

function getSeatType(strSeat) {
	strType = "";
	switch (strSeat)
	{
		case "普通":
			strType = "Y";
			break;
		case "プレミアム":
			strType = "S";
			break;
		case "クラスJ":
			strType = "J";
			break;
		default:
			break;
	}
	return strType;
}

 // ANA新株
   function selectFlight(airlineNo, airlineID, ticketType) {
   	   // $text = $text.split(/\s|,/);
   	   //console.log(airlineID);
	   //console.log(airlineNo);
	   //console.log(ticketType);
   	    $("#going_disp_list td[id^=going]").each(function(){
   	    	//console.log(this.id);
   	    	if (!!$(this).html()) {
   	    		seq = this.id.toString().replace('going', '');
   	    		ailineNoEle = $(this).find("#flight_num_going" + seq).first();
   	    		ailineIDEle = $(this).find("#flight_prefix_going" + seq).first();
   	    		ticketTypeEle = $(this).find("#flight_option_name_going" + seq).first();
   	    		if (ailineNoEle.val() == airlineNo && ailineIDEle.val() == airlineID && ticketTypeEle.val() == getTicketType(ticketType)) {
   	    			console.log(this.id);
   	    			$(this).find("img").first().trigger('click');
   	    			return false;
   	    		}
   	    	}
   	    });
	}
	
   function selectFlightReturn(airlineNo, airlineID, ticketType) {
   	   // $text = $text.split(/\s|,/);
   	   //console.log(airlineID);
	   //console.log(airlineNo);
	   //console.log(ticketType);
   	    $("#going_disp_list td[id^=going]").each(function(){
   	    	//console.log(this.id);
   	    	if (!!$(this).html()) {
   	    		seq = this.id.toString().replace('return', '');
   	    		ailineNoEle = $(this).find("#flight_num_return" + seq).first();
   	    		ailineIDEle = $(this).find("#flight_prefix_return" + seq).first();
   	    		ticketTypeEle = $(this).find("#flight_option_name_return" + seq).first();
   	    		if (ailineNoEle.val() == airlineNo && ailineIDEle.val() == airlineID && ticketTypeEle.val() == getTicketType(ticketType)) {
   	    			console.log(this.id);
   	    			$(this).find("img").first().trigger('click');
   	    			return false;
   	    		}
   	    	}
   	    });
	}	

function getTicketType(strTicket) {
	strType = "";
	switch (strTicket)
	{
		case "1":
			strType = "普通運賃";
			break;
		case "5":
		case "9":
			strType = "株主優待";
			break;
		case "16":
		case "17":
		case "18":
			strType = "特割";
			break;
		case "90":
		case "91":
			strType = "旅割21";
			break;
		case "92":
			strType = "旅割28";
			break;
		case "20":
			strType = "旅割45";
			break;
		case "93":
			strType = "旅割60";
			break;
		case "94":
			strType = "旅割75";
			break;
		case "215":
			strType = "旅割55";
			break;
		case "100":
			strType = "プレミアム";
			break;
		case "102":
		case "115":
		case "116":
			strType = "プレミアム特割";
			break;
		case "99":
		case "103":
			strType = "プレミアム株優";
			break;
		case "117":
			strType = "プレミアム旅割28";
			break;
		default:
			break;
	}
	return strType;
}

function fixVNLMonth(month)	{
		monthTxt = "";
		switch (month) {
			case 1:
				monthTxt = "Jan";
				break;
			case 2:
				monthTxt = "Feb";
				break;
			case 3:
				monthTxt = "Mar";
				break;
			case 4:
				monthTxt = "Apr";
				break;
			case 5:
				monthTxt = "May";
				break;
			case 6:
				monthTxt = "Jun";
				break;
			case 7:
				monthTxt = "Jul";
				break;
			case 8:
				monthTxt = "Aug";
				break;
			case 9:
				monthTxt = "Sep";
				break;
			case 10:
				monthTxt = "Oct";
				break;
			case 11:
				monthTxt = "Nov";
				break;
			case 12:
				monthTxt = "Dec";
				break;
			default:
				break;
		}
	  return monthTxt;
}

// fix format 1983-09-10
function fixFormatDate(str){
	if(str == undefined)
		return '';
	// 
	if (str.indexOf('-') > -1) {
		return str;
	} else {
		return str.substring(0,4) + '-' + str.substring(4,6) + '-' + str.substring(6,8);
	}
}

function onlyUnique(value, index, self) { 
    return self.indexOf(value) === index;
}

function getMileSFJ(dep, des, ticket_type){
	var group1 = ['大人普通運賃'];
	var group2 = ['株主優待割引運賃', 'STAR1 A', 'STAR1 B', 'STAR3', 'STAR7'];
	var group3 = ['そら旅21', 'そら旅28', 'そら旅45', 'そら旅60', 'そら旅80'];
	var mile = 0;
	
	//HND-KKJ | KKJ-HND
	if((dep == '東京(羽田)' && des == '北九州') || (des == '東京(羽田)' && dep == '北九州')){
		if(group1.indexOf(ticket_type) != -1){
			mile = 534;
		}
		if(group2.indexOf(ticket_type) != -1){
			mile = 401;
		}
		if(group3.indexOf(ticket_type) != -1){
			mile = 267;
		}
	}
	//HND-FUK | FUK-HND
	if((dep == '東京(羽田)' && des == '福岡') || (des == '東京(羽田)' && dep == '福岡')){
		if(group1.indexOf(ticket_type) != -1){
			mile = 567;
		}
		if(group2.indexOf(ticket_type) != -1){
			mile = 425;
		}
		if(group3.indexOf(ticket_type) != -1){
			mile = 284;
		}
	}
	//HND-KIX | KIX-HND
	if((dep == '東京(羽田)' && des == '大阪(関西)') || (des == '東京(羽田)' && dep == '大阪(関西)')){
		if(group1.indexOf(ticket_type) != -1){
			mile = 280;
		}
		if(group2.indexOf(ticket_type) != -1){
			mile = 210;
		}
		if(group3.indexOf(ticket_type) != -1){
			mile = 140;
		}
	}
	//HND-UBJ | UBJ-HND
	if((dep == '東京(羽田)' && des == '山口宇部') || (des == '東京(羽田)' && dep == '山口宇部')){
		if(group1.indexOf(ticket_type) != -1){
			mile = 510;
		}
		if(group2.indexOf(ticket_type) != -1){
			mile = 383;
		}
		if(group3.indexOf(ticket_type) != -1){
			mile = 255;
		}
	}
	
	
	//NGO-FUK | FUK-NGO
	if((dep == '名古屋(中部)' && des == '福岡') || (des == '名古屋(中部)' && dep == '福岡')){
		if(group1.indexOf(ticket_type) != -1){
			mile = 374;
		}
		if(group2.indexOf(ticket_type) != -1){
			mile = 281;
		}
		if(group3.indexOf(ticket_type) != -1){
			mile = 187;
		}
	}
	
	

	//KKJ-OKA | OKA-KKJ
	if((dep == '北九州' && des == '沖縄(那覇)') || (des == '北九州' && dep == '沖縄(那覇)')){
		if(group1.indexOf(ticket_type) != -1){
			mile = 563;
		}
		if(group2.indexOf(ticket_type) != -1){
			mile = 422;
		}
		if(group3.indexOf(ticket_type) != -1){
			mile = 282;
		}
	}
	
	return mile;
}