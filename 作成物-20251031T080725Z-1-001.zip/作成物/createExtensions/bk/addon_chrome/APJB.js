/*
 * APJB (booking B2C)
 * @author yenvt
 * */

const constantsTravelAgent = {
    "username": "Evolableasia",
    "password": "Password1234*",
    "postalCode": "105-0002",
    "state": "TOKYO",
    "city": "MINATOKU",
    "address": "ATAGO2-5-1",
    "mobile": "334316280",
    "email": "lcc-tehai@travel.co.jp",
    "airports": airportListTravelagent()
};

function searchFlightTravelagent() {
    getItem("flight_info1", "Search-CriteriaBox", "setSearchTravelagent", constantsTravelAgent);
}

function getPassengerAmount() {
    let adults = 1;
    let children = 0;
    let infants = 0;
    const nav = $('.nav-container .sky-breadcrumb span.title');
    if (nav.length > 0) {
        let flightSearchUrl = null;
        for (let i = 0; i < nav.length; i++) {
            if ($(nav[i]).text() == 'Ticket') {
                flightSearchUrl = $(nav[i]).parent().find('a');
                break;
            }

        }
        const urlObj = new URL(flightSearchUrl[0].baseURI + flightSearchUrl[0].search);
        adults = parseInt(urlObj.searchParams.get('adults'));
        children = parseInt(urlObj.searchParams.get('children'));
        infants = parseInt(urlObj.searchParams.get('infants'));
    }

    return {
        "adults": adults,
        "children": children,
        "infants": infants
    };
}

function setTravellerTravelAgent() {
    const travelAmount = getPassengerAmount();
    const adults = travelAmount.adults + travelAmount.children;
    let num = 0;
    for (let i = 0; i < adults; i++) {
        let option = "Booking_Passengers_Title_TravelAgent";
        if (num >= travelAmount.adults) {
            option = "Booking_Passengers_Title_Infant_TravelAgent";
        }
        getItem('application_traveller_list_' + i.toString() + '_sex', "Booking\\.Passengers\\[" + num + "\\]\\.Title", option);
        getItem('application_traveller_list_' + i.toString() + '_last_name_rome', "Booking\\.Passengers\\[" + num + "\\]\\.LastName", "Booking_Passengers_TravelAgent");
        getItem('application_traveller_list_' + i.toString() + '_first_name_rome', "Booking\\.Passengers\\[" + num + "\\]\\.FirstName", "Booking_Passengers_TravelAgent");
        getItem('application_traveller_list_' + i.toString() + '_birthday', "Booking\\.Passengers\\[" + num + "\\]\\.BirthDate", "Booking_Passengers_Birthday_TravelAgent");
        num++;
    }
    if (travelAmount.infants > 0) {
        for (let i = 0; i < travelAmount.infants; i++) {
            getItem('application_infant_list_' + i.toString() + '_sex', "Booking\\.Passengers\\[" + num + "\\]\\.Title", "Booking_Passengers_Title_Infant_TravelAgent");
            getItem('application_infant_list_' + i.toString() + '_last_name_rome', "Booking\\.Passengers\\[" + num + "\\]\\.LastName", "Booking_Passengers_TravelAgent");
            getItem('application_infant_list_' + i.toString() + '_first_name_rome', "Booking\\.Passengers\\[" + num + "\\]\\.FirstName", "Booking_Passengers_TravelAgent");
            getItem('application_infant_list_' + i.toString() + '_birthday', "Booking\\.Passengers\\[" + num + "\\]\\.BirthDate", "Booking_Passengers_Birthday_TravelAgent");
            num++;
        }
    }
}

function setPaymentTravelAgent() {
    const changeEvent = document.createEvent("HTMLEvents");
    changeEvent.initEvent("change", true, true);

    const travelAmount = getPassengerAmount();
    const total = travelAmount.adults + travelAmount.children + travelAmount.infants;

    for (let i = 0; i < total; i++) {
        if (typeof $('#Booking_Passengers_' + i + '__Email').val() !== 'undefined') {
            $('#Booking_Passengers_' + i + '__Email').val(constantsTravelAgent.email);
            $('#Booking_Passengers_' + i + '__Email').focus();
            document.querySelector('#Booking_Passengers_' + i + '__Email').dispatchEvent(changeEvent);
        }

        if (typeof $('#Booking_Passengers_' + i + '__Mobile').val() !== 'undefined') {
            $('#Booking_Passengers_' + i + '__Mobile').val(constantsTravelAgent.mobile);
            $('#Booking_Passengers_' + i + '__Mobile').focus();
            document.querySelector('[id="Booking_Passengers_' + i + '__Mobile"]').dispatchEvent(changeEvent);
        }

        $('#Booking_Passengers_' + i + '__Address').val(constantsTravelAgent.address);
        $('#Booking_Passengers_' + i + '__Address').focus();
        document.querySelector('[id="Booking_Passengers_' + i + '__Address"]').dispatchEvent(changeEvent);

        $('#Booking_Passengers_' + i + '__Postal').val(constantsTravelAgent.postalCode);
        $('#Booking_Passengers_' + i + '__Postal').focus();
        document.querySelector('[id="Booking_Passengers_' + i + '__Postal"]').dispatchEvent(changeEvent);

        $('#Booking_Passengers_' + i + '__State').val(constantsTravelAgent.state);
        $('#Booking_Passengers_' + i + '__State').focus();
        document.querySelector('[id="Booking_Passengers_' + i + '__State"]').dispatchEvent(changeEvent);

        $('#Booking_Passengers_' + i + '__City').val(constantsTravelAgent.city);
        $('#Booking_Passengers_' + i + '__City').focus();
        document.querySelector('[id="Booking_Passengers_' + i + '__City"]').dispatchEvent(changeEvent);
    }

    $('#paymentMethodRadio-Radixx\\:INVC').click();
    $('#AcceptTermsConditions').click();
}

function airportListTravelagent() {
    return JSON.parse('[{"Code":"KIX","Name":"Osaka (Kansai)"},{"Code":"KUH","Name":"Kushiro"},{"Code":"CTS","Name":"Sapporo (Shin-Chitose)"},{"Code":"SDJ","Name":"Sendai"},{"Code":"KIJ","Name":"Niigata"},{"Code":"NRT","Name":"Tokyo (Narita)"},{"Code":"HND","Name":"Tokyo (Haneda)"},{"Code":"MYJ","Name":"Matsuyama / Ehime"},{"Code":"FUK","Name":"Fukuoka"},{"Code":"NGS","Name":"Nagasaki"},{"Code":"KMI","Name":"Miyazaki"},{"Code":"KOJ","Name":"Kagoshima"},{"Code":"OKA","Name":"Okinawa (Naha)"},{"Code":"ISG","Name":"Ishigaki"},{"Code":"ASJ","Name":"Amami"}]');
}

$(document).ready(function () {
    const domain_name = document.domain;
    const location = window.location;
    if (domain_name == "travelagent.flypeach.com") {
        if (location.href.indexOf('/corporate/my-account') > -1) {
            const menu = $('#profile-left-menu').find('li');
            if (menu.length > 0) {
                let flightSearch = null;
                for (let i = 0; i < menu.length; i++) {
                    let aTag = $(menu[i]).find('a').first();
                    if (aTag.length > 0) {
                        if ($(aTag).attr('href').indexOf('/flight/search') > -1) {
                            flightSearch = aTag;
                            break;
                        }
                    }
                }
                if (flightSearch != null) {
                    $(flightSearch)[0].click();
                }
            }
        } else if (location.href.indexOf('/flight/search') > -1) {
            if (location.search.length == 0) {
                setTimeout(function () {
                    searchFlightTravelagent();
                }, CMS_TIMEOUT_INMILISECONDS);
            }
        } else if (location.href.indexOf('/flight/services') > -1) {
            setTimeout(function () {
                setTravellerTravelAgent();
            }, CMS_TIMEOUT_INMILISECONDS);
        } else if (location.href.indexOf('/flight/payment') > -1) {
            setTimeout(function () {
                setPaymentTravelAgent();
            }, CMS_TIMEOUT_INMILISECONDS);
        } else if (location.href.indexOf('/corporate/corporate-login') > -1) {
            $("[id=usrname_field]").val(constantsTravelAgent.username).trigger('change');
            let changeEvent = document.createEvent("HTMLEvents");
            changeEvent.initEvent("change", true, true);
            document.querySelector('[id="usrname_field"]').dispatchEvent(changeEvent);

            $("[id=passwd_field]").val(constantsTravelAgent.password).trigger('change');
            document.querySelector('[id="passwd_field"]').dispatchEvent(changeEvent);

            const loginCorp = document.getElementById('loginCorp');
            setTimeout(function () {
                loginCorp.click();
            }, 1000);
        } else {
            // @TODO
        }

    }
}); 