/*
 * JJP airport
 * Check auto submit
 * Check operator edit after auto fill
 * Check affection to other pages in same domain
 * Clear all value after set in form(click button)
 * */
// 20170329 add more case for change design JJP
function copyFromApplicationJJP1($arrAdult, $arrChild) {
        $divPc = $('#passenger-contact');
        adultCount = 0;
        childCount = 0;
        infantCount = 0;
        //console.log($arrAdult);
        //console.log($arrChild);
        //console.log($arrAdult[0]);
        //console.log($arrChild[0]);
        //$section = $('#passengerForm div').first().find('div');
        $section =  $('.js-form-section');
        $.each($section, function(){
			$textCheck = $(this).find('h4').first().text();
			$divP = $(this);
			if ($textCheck.indexOf('幼児') > -1) {
                //幼児 (2歳未満)
                if (infantCount <= 1) {
                    //名前
                    $inp = $divP.find("[id*='infant_Firstname_']").first();
                    if (typeof($inp) != 'undefined') {
                    	getItem('application_infant_list_' + infantCount.toString() + '_first_name_rome',$inp.attr('name'), 'name');
                    	$inp.focus();
                    }
                    $inp = $divP.find("[id*='infant_Lastname_']").first();
                    if (typeof($inp) != 'undefined') {
                    	getItem('application_infant_list_' + infantCount.toString() + '_last_name_rome',$inp.attr('name'), 'name');
                    	$inp.focus();
                    }
                    //性別
                    $sel = $divP.find("[id*='infant_Gender_']").first();
                    if (typeof($sel) != 'undefined') {
                    	getItem('application_infant_list_' + infantCount.toString() + '_sex',$sel.attr('name'), 'select');
                    	$sel.focus();
                    }
                    //生年月日
                    $inpY = $divP.find("[id*='infant_date_of_birth_year_']").first();
                    $inpM = $divP.find("[id*='infant_date_of_birth_month_']").first();
                    $inpD = $divP.find("[id*='infant_Dob_']").first();
                    if (typeof($inpY) != 'undefined' && typeof($inpM) != 'undefined' && typeof($inpD) != 'undefined') {
                    	getItem('application_infant_list_' + infantCount.toString() + '_birthday', 
                    			    $inpY.attr('name') + '|' + $inpM.attr('name') + '|' + $inpD.attr('name') , 'YMD');
                    	$inpY.focus();
                    	$inpM.focus();
                    	$inpD.focus();
                    }
                    $('#infant_travellingWith_' + infantCount).val(infantCount);
                    ++infantCount;
                }
			}
			
			if ($textCheck.indexOf('大人') > -1) {
				index = $arrAdult[adultCount];
				
                if (index > -1) {
                	//名前
                    $inp = $divP.find("[id*='passenger_Firstname_']").first();
                    if (typeof($inp) != 'undefined') {
                    	getItem('application_traveller_list_' + index.toString() + '_first_name_rome',$inp.attr('name'), 'name');
                    	$inp.focus();
                    }
                    $inp = $divP.find("[id*='passenger_Lastname_']").first();
                    if (typeof($inp) != 'undefined') {
                    	getItem('application_traveller_list_' + index.toString() + '_last_name_rome',$inp.attr('name'), 'name');
                    	$inp.focus();
                    }
                	//タイトル
                    $selSex = $divP.find("[id*='passenger_Gender_']").first();
                    if (typeof($selSex) != 'undefined' ) {
                    	getItem('application_traveller_list_' + index.toString() + '_sex',$selSex.attr('name'), 'sexJJP2');
                    	$selSex.focus();
                    }
                    
                    if (adultCount == 0) {
                    	getItem('application_traveller_list_' + index.toString() + '_first_name_rome','js-contact_Name_First');
                    	$inp.focus();
                    	getItem('application_traveller_list_' + index.toString() + '_last_name_rome','js-contact_Name_Last');
                    	$inp.focus();
					}
					//生年月日
                    $inpY = $divP.find("[id*='date_of_birth_year_']").first();
                    $inpM = $divP.find("[id*='date_of_birth_month_']").first();
                    $inpD = $divP.find("[id*='adult_Dob_']")[1];
                    if (typeof($inpY) != 'undefined' && typeof($inpM) != 'undefined' && typeof($inpD) != 'undefined') {
                    	getItem('application_traveller_list_' + index.toString() + '_birthday', 
                    			    $inpY.attr('name') + '|' + $inpM.attr('name') + '|' + $($inpD).attr('name') , 'YMD');
                    	$inpY.focus();
                    	$inpM.focus();
                    	$inpD.focus();
                    }
					++adultCount;
                }
			}
			
			if ($textCheck.indexOf('子供') > -1) {
				index = $arrChild[childCount];
                    if (index > -1) {
                    	//名前
	                    $inp = $divP.find("[id*='passenger_Firstname_']").first();
	                    if (typeof($inp) != 'undefined') {
	                    	getItem('application_traveller_list_' + index.toString() + '_first_name_rome',$inp.attr('name'), 'name');
	                    	$inp.focus();
	                    }
	                    $inp = $divP.find("[id*='passenger_Lastname_']").first();
	                    if (typeof($inp) != 'undefined') {
	                    	getItem('application_traveller_list_' + index.toString() + '_last_name_rome',$inp.attr('name'), 'name');
	                    	$inp.focus();
	                    }
	
	
	                    $selSex = $divP.find("[id*='passenger_Gender_']").first();
	                    if (typeof($selSex) != 'undefined' ) {
	                    	getItem('application_traveller_list_' + index.toString() + '_sex',$selSex.attr('name'), 'sexJJP2');
	                    	$selSex.focus();
	                    }
	                    
						
	                    //生年月日
	                    /*$inpY = $divP.find("[name*='DropDownListBirthDateYear_']").first();
	                    $inpM = $divP.find("[name*='DropDownListBirthDateMonth_']").first();
	                    $inpD = $divP.find("[name*='DropDownListBirthDateDay_']").first();
	                    if (typeof($inpY) != 'undefined' && typeof($inpM) != 'undefined' && typeof($inpD) != 'undefined') {
	                    	getItem('application_traveller_list_' + index.toString() + '_birthday', 
	                    			    $inpY.attr('name') + '|' + $inpM.attr('name') + '|' + $inpD.attr('name') , 'YMD');
	                    	$inpY.focus();
	                    	$inpM.focus();
	                    	$inpD.focus();
	                    }*/
	                    ++childCount;               
	                 } 
			}
        });
        // tel1
        getItem('application_tel1','contact_Phone_Number');
        // zipcode
        getItem('application_zip_code','contact_Postcode');
        
        getItem('reserve_email_jjp', 'contact_Email_Address'); // 20170419
        getItem('reserve_email_jjp', 'contact_Email_Phone'); // 20170419
}

// 20170329 add more case for change design JJP >>>
function setFlightInformationJJP1(depAirport,arrAirport) {
	
	//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
	// flightNo
	flightNo = $.trim($('.datalayer-segment-info').attr('data-flightsegmentflightnumber'));
	// 予約番号
	reserveNo = $.trim($('.confirmation-panel__pnr').text());
	//reserveNo = $.trim($('#datalayer-transaction-data').attr('data-transaction-pnr'));
	dtmLimitDate = new Date();
	dtmLimitDate.setDate(dtmLimitDate.getDate() + 1);
	dtmLimitDate = formatDate(dtmLimitDate);
	// deptime
	depTime = $.trim($('.datalayer-segment-info').attr('data-flightsegmentlocaldeparturetime'));
	depTime = depTime.split('T');
	flightDate = depTime[0];
	depTime = depTime[1].replace(':', '/');
	// arrtime
	arrTime = $.trim($('.datalayer-segment-info').attr('data-flightsegmentlocalarrivaltime'));
	arrTime = arrTime.split('T');
	arrTime = arrTime[1].replace(':', '/');
	// flightDate
	flightDate = flightDate.toString().replace('-', '/').replace('-', '/');
	flightDateJP = flightDate.toString().replace('-', "年").replace('-', "月");
	flightDateJP += '日';
	// seat 
	// seatTemp = $.trim($('.datalayer-segment-info').attr('data-flightsegmentcabinclass'));
	$fareClass = $(".datalayer-segment-info").attr('data-flightsegmentfareclass');
	if ($fareClass == 'S7') {
		seat = '普通';
	} else {
		seat = 'プレミアム';
	}
	strValue = "";
    strValue += flightDate;
    strValue += "/" + "JJP" + "/" + flightNo;
    strValue += "/" + fixJJPAirportName(depAirport);
    strValue += "/" + fixJJPAirportName(arrAirport);
    strValue += "/" + depTime;
    strValue += "/" + arrTime;
    strValue += "/" + reserveNo;
    strValue += "/" + dtmLimitDate;
    strValue += "/" + seat;
    strValue += "/" + $fareClass;
    
    strText = "";
    strText += flightDateJP;
    strText += "/" + "JJP" + "/" + flightNo;
    strText += "/" + fixJJPAirportName(depAirport);
    strText += "/" + fixJJPAirportName(arrAirport);	
	
	line_no = sessionStorage.getItem('line_no');
	carrier = sessionStorage.getItem('carrier');
	data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
	console.log(data_callback);
	cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));

	setTimeout(function(){
		setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
	}, CMS_TIMEOUT_INMILISECONDS);
}

function copyFromApplicationJJP($arrAdult, $arrChild) {
		$divPc = $('#passenger-contact');
        adultCount = 0;
        childCount = 0;
        infantCount = 0;
        //console.log($arrAdult);
        //console.log($arrChild);
        //console.log($arrAdult[0]);
        //console.log($arrChild[0]);
        for (p=1;p<=11;p++) {
            $divP = $('#p' + p.toString());	
            if (typeof($divP) == 'undefined') {
                break;
            }
			if ($divP.text().indexOf("幼児 (2歳未満)") > -1) {
                //幼児 (2歳未満)
                if (infantCount <= 1) {
                    //名前
                    $inp = $divP.find("[name*='TextBoxFirstName_']").first();
                    if (typeof($inp) != 'undefined') {
                    	getItem('application_infant_list_' + infantCount.toString() + '_first_name_rome',$inp.attr('name'), 'name');
                    	$inp.focus();
                    }
                    $inp = $divP.find("[name*='TextBoxLastName_']").first();
                    if (typeof($inp) != 'undefined') {
                    	getItem('application_infant_list_' + infantCount.toString() + '_last_name_rome',$inp.attr('name'), 'name');
                    	$inp.focus();
                    }
                    //性別
                    $sel = $divP.find("[name*='DropDownListGender_']").first();
                    if (typeof($sel) != 'undefined') {
                    	getItem('application_infant_list_' + infantCount.toString() + '_sex',$sel.attr('name'), 'select');
                    	$sel.focus();
                    }
                    //生年月日
                    $inpY = $divP.find("[name*='DropDownListBirthDateYear_']").first();
                    $inpM = $divP.find("[name*='DropDownListBirthDateMonth_']").first();
                    $inpD = $divP.find("[name*='DropDownListBirthDateDay_']").first();
                    if (typeof($inpY) != 'undefined' && typeof($inpM) != 'undefined' && typeof($inpD) != 'undefined') {
                    	getItem('application_infant_list_' + infantCount.toString() + '_birthday', 
                    			    $inpY.attr('name') + '|' + $inpM.attr('name') + '|' + $inpD.attr('name') , 'YMD');
                    	$inpY.focus();
                    	$inpM.focus();
                    	$inpD.focus();
                    }
                    ++infantCount;
                }
            } else if ($divP.text().indexOf("「子供」のご予約についてはこちらをご確認ください") > -1) {
	                //子供
                    //タイトル
                    index = $arrChild[childCount];
                    if (index > -1) {
	                    $selTitle = $divP.find("[name*='DropDownListTitle_']").first();
	                    $selSex = $divP.find("[name*='DropDownListGender_']").first();
	                    if (typeof($selTitle) != 'undefined' && typeof($selSex) != 'undefined' ) {
	                    	getItem('application_traveller_list_' + index.toString() + '_sex',$selTitle.attr('name') + '|' + $selSex.attr('name'), 'selSexTitleChild');
	                    	$selTitle.focus();
	                    	$selSex.focus();
	                    }
	                    
						//名前
	                    $inp = $divP.find("[name*='TextBoxFirstName_']").first();
	                    if (typeof($inp) != 'undefined') {
	                    	getItem('application_traveller_list_' + index.toString() + '_first_name_rome',$inp.attr('name'), 'name');
	                    	$inp.focus();
	                    }
	                    $inp = $divP.find("[name*='TextBoxLastName_']").first();
	                    if (typeof($inp) != 'undefined') {
	                    	getItem('application_traveller_list_' + index.toString() + '_last_name_rome',$inp.attr('name'), 'name');
	                    	$inp.focus();
	                    }
	                    
	                    //生年月日
	                    $inpY = $divP.find("[name*='DropDownListBirthDateYear_']").first();
	                    $inpM = $divP.find("[name*='DropDownListBirthDateMonth_']").first();
	                    $inpD = $divP.find("[name*='DropDownListBirthDateDay_']").first();
	                    if (typeof($inpY) != 'undefined' && typeof($inpM) != 'undefined' && typeof($inpD) != 'undefined') {
	                    	getItem('application_traveller_list_' + index.toString() + '_birthday', 
	                    			    $inpY.attr('name') + '|' + $inpM.attr('name') + '|' + $inpD.attr('name') , 'YMD');
	                    	$inpY.focus();
	                    	$inpM.focus();
	                    	$inpD.focus();
	                    }
	                    ++childCount;
	                 }     
            } else {
                //大人
                
                index = $arrAdult[adultCount];
                if (index > -1) {
                	//タイトル
					$selTitle = $divP.find("[name*='DropDownListTitle_']").first();
                    $selSex = $divP.find("[name*='DropDownListGender_']").first();
                    if (typeof($selTitle) != 'undefined' && typeof($selSex) != 'undefined' ) {
                    	getItem('application_traveller_list_' + index.toString() + '_sex',$selTitle.attr('name') + '|' + $selSex.attr('name'), 'selSexTitleAdult');
                    	$selTitle.focus();
                    	$selSex.focus();
                    }
                    
					//名前
                    $inp = $divP.find("[name*='TextBoxFirstName_']").first();
                    if (typeof($inp) != 'undefined') {
                    	getItem('application_traveller_list_' + index.toString() + '_first_name_rome',$inp.attr('name'), 'name');
                    	$inp.focus();
                    }
                    $inp = $divP.find("[name*='TextBoxLastName_']").first();
                    if (typeof($inp) != 'undefined') {
                    	getItem('application_traveller_list_' + index.toString() + '_last_name_rome',$inp.attr('name'), 'name');
                    	$inp.focus();
                    }                    
                    
                    if (adultCount == 0) {
						$selTitle = $divPc.find("[name*='DropDownListTitle']").first();
						if (typeof($selTitle) != 'undefined') {
							getItem('application_traveller_list_' + index.toString() + '_sex',$selTitle.attr('name'), 'selTitle');
							$selTitle.focus();
						}
						
						$inp = $divPc.find("[name*='TextBoxFirstName']").first();
						if (typeof($inp) != 'undefined') {
	                    	getItem('application_traveller_list_' + index.toString() + '_first_name_rome',$inp.attr('name'), 'name');
	                    	$inp.focus();
	                    }
	                    
	                    $inp = $divPc.find("[name*='TextBoxLastName']").first();
						if (typeof($inp) != 'undefined') {
	                    	getItem('application_traveller_list_' + index.toString() + '_last_name_rome',$inp.attr('name'), 'name');
	                    	$inp.focus();
	                    }
					}
					//生年月日
                    $inpY = $divP.find("[name*='DropDownListBirthDateYear_']").first();
                    $inpM = $divP.find("[name*='DropDownListBirthDateMonth_']").first();
                    $inpD = $divP.find("[name*='DropDownListBirthDateDay_']").first();
                    if (typeof($inpY) != 'undefined' && typeof($inpM) != 'undefined' && typeof($inpD) != 'undefined') {
                    	getItem('application_traveller_list_' + index.toString() + '_birthday', 
                    			    $inpY.attr('name') + '|' + $inpM.attr('name') + '|' + $inpD.attr('name') , 'YMD');
                    	$inpY.focus();
                    	$inpM.focus();
                    	$inpD.focus();
                    }
					++adultCount;
                }
            } 
        }
        // tel1
        getItem('application_tel1','ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxOtherPhone|ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxHomePhone|ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxWorkPhone', 'TelMailJJP');
        
        getItem('reserve_email_jjp', 'ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxEmailAddress'); // 20170419
        getItem('reserve_email_jjp', 'ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxEmailAddressConfirm'); // 20170419        
        // zipcode
        getItem('application_zip_code','ControlGroupPassengerView_ContactInputViewPassengerView_TextBoxPostalCode');
             
}

function setFlightInformationJJP() {
	$i = 0;
	depAirport = '';
	arrAirport = '';
	flightDate = '';
	depHour ='';
	depMinute ='';
	arrHour = '';
	arrMinute = '';	
	seat = '';
	$("th.flight-details").each(function(){
		$text = $(this).text();
		$text = $text.split(/\s|,/);
		// departure
		if ($i == 0) {
			depAirport = $text[0];
			flightDate = $text[1].toString().substring(5);//.replace('/', '-').replace('/', '-');
			flightDateJP = flightDate.toString().replace('/', "年").replace('/', "月");
			flightDateJP += '日';
			depTime = $text[3].split(':');
			depHour = pad(parseInt(depTime[0]),2);
			depMinute = pad(parseInt(depTime[1]),2);
		} else if ($i == 1){
		    // arrival
			arrAirport = $text[0];
			// flightDate = $text[1].toString().substring(5).replace('/', '-').replace('/', '-');
			arrTime = $text[3].split(':');
			arrHour = pad(parseInt(arrTime[0]),2);
			arrMinute = pad(parseInt(arrTime[1]),2);
		} 
		$i++;
	});
	
	// flightNo
	$text = $("td.flight-details.half-cell").first().text();
	$res = $text.match(/([A-Z]+)\s+([0-9]+)/);
	flightNo = $res[0].substring(3);
	// 予約番号
	$text = $("span.pnr").first().text();
	reserveNo = $.trim($text);
	dtmLimitDate = new Date();
	dtmLimitDate.setDate(dtmLimitDate.getDate() + 1);
	dtmLimitDate = formatDate(dtmLimitDate);
	
	strValue = "";
    strValue += flightDate;
    strValue += "/" + "JJP" + "/" + flightNo;
    strValue += "/" + fixJJPAirportName(depAirport);
    strValue += "/" + fixJJPAirportName(arrAirport);
    strValue += "/" + depHour;
    strValue += "/" + depMinute;
    strValue += "/" + arrHour;
    strValue += "/" + arrMinute;
    strValue += "/" + reserveNo;
    strValue += "/" + dtmLimitDate;
    strValue += "/" + seat;
    strValue += "/" + $(".datalayer-segment-info").attr('data-flightsegmentfareclass');
    
    strText = "";
    strText += flightDateJP;
    strText += "/" + "JJP" + "/" + flightNo;
    strText += "/" + fixJJPAirportName(depAirport);
    strText += "/" + fixJJPAirportName(arrAirport);
	line_no = sessionStorage.getItem('line_no');
	carrier = sessionStorage.getItem('carrier');
	data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
	cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));

	setTimeout(function(){
		setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
	}, CMS_TIMEOUT_INMILISECONDS);
}

//var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
//function reactSetInputValue(input, value) {
//	nativeInputValueSetter.call(input, value);
//	input.dispatchEvent(new Event('input', { bubbles: true}));
//}

$( document ).ready(function() {
	
	loc = window.location;
	var domain_name = document.domain;
	/*if(domain_name=="booknow.jetstar.com") {
		if(loc.toString().indexOf('booknow.jetstar.com/Passenger.aspx') != -1 && $('body').text().toString().indexOf('搭乗者様の情報を入力') != -1) {
			setTimeout(function(){
				getItem('application_traveller_list_adult_child_index',"copyFromApplicationJJP", 'copyFromApplicationJJP');
			}, CMS_TIMEOUT_INMILISECONDS);
		} else if(loc.toString().indexOf('booknow.jetstar.com/htl2-Itinerary.aspx') != -1 && $('body').text().toString().indexOf('お客様のご予約番号') != -1) {
			setFlightInformationJJP();
			console.log('setFlightInformationJJP done');
		}
	}*/
	
	if(domain_name=="booking.jetstar.com") {
		if(loc.toString().indexOf('booking/select-flights') != -1) {
			cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			setTimeout(function(){
				setValue(cms_app_id +'_application_flight_airport_name', $('#chooseFlights').text());
			}, CMS_TIMEOUT_INMILISECONDS);
		} else if(loc.toString().indexOf('booking/passengers') != -1 && $('body').text().toString().indexOf('搭乗者／連絡先情報') != -1) {
			setTimeout(function(){
				getItem('application_traveller_list_adult_child_index',"copyFromApplicationJJP1", 'copyFromApplicationJJP1');
			}, CMS_TIMEOUT_INMILISECONDS);
		} else if(loc.toString().indexOf('booking/confirmation') != -1 && $('body').text().toString().indexOf('ご予約状況') != -1) {
			setTimeout(function(){
				getItem('application_flight_airport_name',"setFlightInformationJJP1", 'setFlightInformationJJP1');
				console.log('setFlightInformationJJP1 done');
			}, CMS_TIMEOUT_INMILISECONDS-500);
		} else if(loc.toString().indexOf('mmb/#/login?') != -1) {
			var line_no = sessionStorage.getItem('line_no');
			var line_no_new = sessionStorage.getItem('line_no_new');
			setTimeout(function(){
				if(line_no==null && line_no_new==null){
					location.reload();
					sessionStorage.setItem('line_no_new', 1);
				}
			}, 1000);
			setTimeout(function(){
				getItem('application_ticket_reservation_no' + line_no,'pnr', 'pnr_jjp');
				getItem('application_last_name_rome' + line_no,'identifier', 'pnr_jjp');
				getItem('application_ticket_reservation_no' + line_no,'button-component-children', 'pnr_jjp_btn');				
			}, 5000);
			
		}
	}
});