/*
 * APJC airport
 * Check auto submit
 * Check operator edit after auto fill
 * Check affection to other pages in same domain
 * Clear all value after set in form(click button)
 * Auther: ThuyTQ
 * */
function setFlightInformation_APJC() {
	//予約番号
	//ref-number
	var reserveNo = "";
	var div = $(".txt-number .font-big").text();
	if (div != null) {
		reserveNo = $.trim(div);
	}

	//予約期限
	dtmLimitDate = new Date();
	dtmLimitDate.setDate(dtmLimitDate.getDate() + 1);
	dtmLimitDate = formatDate(dtmLimitDate);

	var strLimitDate = '';
	var strLimitDateText = '';
	var data_callback = '';
	var data_callback1 = '';

	curTable = $('.content_complete-row .content_complete-flight .info_trip-table .info_trip-row');
	if ( typeof (curTable) != 'undefined' && curTable.length >= 1) {

		var flightDate = DATE_MIN_VAL;
		var flightNo = "";
		var depAirport = "";
		var arrAirport = "";
		var depHour = 0;
		var depMinute = 0;
		var arrHour = 0;
		var arrMinute = 0;
		var seat = "";
		var ticketType = "";

		var i = 0;
		var s = "";
		var result = "";

		curTable.each(function() {
		    //one

			if (i == 0) {
				//フライト
				//MM151
				s = $(this).find(".info_trip-serial").text();
				//flightNo = s.match(/[0-9]{3}/);
				flightNo = s.replace(/\D/g, '');

				//出発地
				//大阪（関西空港）
				s = $(this).find(".info_round-c span.from").html();
                s = s.split('<br>');
                depAirport = $(s[0]).text();

                result  =  s[1].match("([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})");
				result2 =  s[1].match("([0-9]{1,2}):([0-9]{1,2})");

            	flightDate      = result[1] + "/" + result[2] + "/" + result[3];
            	flightDateJP    = result[1] + "年" + result[2] + "月" + result[3] + "日";
            	depHour         = result2[1];
            	depMinute       = result2[2];

				//目的地
				s           = $(this).find(".info_round-c span.to").html();
                s           = s.split('<br>');
				arrAirport  = $(s[0]).text();

				//到着日時
				result = s[1].match("([0-9]{1,2}):([0-9]{1,2})");
				arrHour = result[1];
				arrMinute = result[2];

				//type tickit
                /*
				s = $(".TBLTikets .FlightInformation1 td.BodyCOL3").first().text();
				$res = s.match(/HAPPLUS/);
				if ($res) {
					ticketType = "ハッピーピーチプラス";
				} else
				{
					ticketType = "ハッピーピーチ（預け手荷物なし）";
				}
                */

				//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				strValue = "";
				strValue += flightDate.toString();
				strValue += "/" + "APJ" + "/" + flightNo;
				strValue += "/" + fixJalAirportName(depAirport);
				strValue += "/" + fixJalAirportName(arrAirport);
				strValue += "/" + depHour.toString();
				strValue += "/" + depMinute.toString();
				strValue += "/" + arrHour.toString();
				strValue += "/" + arrMinute.toString();
				strValue += "/" + reserveNo.toString();
				strValue += "/" + dtmLimitDate.toString();
				strValue += "/" + seat;
				strValue += "/" + ticketType;

				//
				strText = "";
				strText += flightDate.toString();
				strText += "/" + "APJ" + "/" + flightNo;
				strText += "/" + fixJalAirportName(depAirport);
				strText += "/" + fixJalAirportName(arrAirport);

				line_no = sessionStorage.getItem('line_no');
				carrier = sessionStorage.getItem('carrier');
				data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
				
				console.log(data_callback);
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				
				setTimeout(function(){
					if(line_no == "0-1"){
						line_no = 0;
					}
					console.log('_merchant_flight_info_callback' + line_no);
					setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
				}, CMS_TIMEOUT_INMILISECONDS);

			}

            if (i == 1) {
				//フライト
				//MM151
				s = $(this).find(".info_trip-serial").text();
				flightNo = s.match(/[0-9]{3}/);
				//flightNo = s.match(/[0-9]{3,4}/);

				//出発地
				//大阪（関西空港）
				s = $(this).find(".info_round-c span.from").html();
                s = s.split('<br>');
                depAirport = $(s[0]).text();

                result  =  s[1].match("([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})");
				result2 =  s[1].match("([0-9]{1,2}):([0-9]{1,2})");

            	flightDate      = result[1] + "/" + result[2] + "/" + result[3];
            	flightDateJP    = result[1] + "年" + result[2] + "月" + result[3] + "日";
            	depHour         = result2[1];
            	depMinute       = result2[2];

				//目的地
				s           = $(this).find(".info_round-c span.to").html();
                s           = s.split('<br>');
				arrAirport  = $(s[0]).text();

				//到着日時
				result = s[1].match("([0-9]{1,2}):([0-9]{1,2})");
				arrHour = result[1];
				arrMinute = result[2];

				//type tickit

				//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				strValue2 = "";
				strValue2 += flightDate.toString();
				strValue2 += "/" + "APJ" + "/" + flightNo;
				strValue2 += "/" + fixJalAirportName(depAirport);
				strValue2 += "/" + fixJalAirportName(arrAirport);
				strValue2 += "/" + depHour.toString();
				strValue2 += "/" + depMinute.toString();
				strValue2 += "/" + arrHour.toString();
				strValue2 += "/" + arrMinute.toString();
				strValue2 += "/" + reserveNo.toString();
				strValue2 += "/" + dtmLimitDate.toString();
				strValue2 += "/" + seat;
				strValue2 += "/" + ticketType;

				//
				strText2 = "";
				strText2 += flightDate.toString();
				strText2 += "/" + "APJ" + "/" + flightNo;
				strText2 += "/" + fixJalAirportName(depAirport);
				strText2 += "/" + fixJalAirportName(arrAirport);

				data_callback1 = '';
				line_no1 = parseInt(sessionStorage.getItem('line_no'))+1;
				carrier = sessionStorage.getItem('carrier');

				data_callback1 = strValue2 + '|' + strText2 + '|' + line_no1 + '|' + carrier;
				console.log(data_callback1);
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				
				setTimeout(function() {
					if(line_no1 == "0-1"){
						line_no1 = 0;
					}
					console.log('_merchant_flight_info_callback' + line_no1);
					setValue(cms_app_id +'_merchant_flight_info_callback' + line_no1, data_callback1);
				}, CMS_TIMEOUT_INMILISECONDS);

			}

			i++;
		});

	}
}


/*function setFlightInformation_APJC_OLD() {
	//予約番号
	//ref-number
	var reserveNo = "";
	var div = $("#spnBookingId").text();
	if (div != null) {
		reserveNo = $.trim(div);
	}

	//予約期限
	dtmLimitDate = new Date();
	dtmLimitDate.setDate(dtmLimitDate.getDate() + 1);
	dtmLimitDate = formatDate(dtmLimitDate);

	var strLimitDate = '';
	var strLimitDateText = '';
	var data_callback = '';

	curTable = $('.bookinginform .TBLYourItinerary');
	if ( typeof (curTable) != 'undefined' && curTable.length >= 2) {

		var flightDate = DATE_MIN_VAL;
		var flightNo = "";
		var depAirport = "";
		var arrAirport = "";
		var depHour = 0;
		var depMinute = 0;
		var arrHour = 0;
		var arrMinute = 0;
		var seat = "";
		var ticketType = "";

		var i = 0;
		var s = "";
		var result = "";

		curTable.each(function() {
		    //one
			if (i == 1) {
				//フライト
				//MM 151
				s = $(this).find("td.BodyCOL1").text();
				$res = s.match(/([A-Z]+)\s+([0-9]+)/);
				flightNo = $res[0].substring(3);

				//出発地
				//大阪（関西空港）
				s = $(this).find("td.BodyCOL2").text();
				depAirport = s;

				//目的地
				s = $(this).find("td.BodyCOL3").text();
				arrAirport = s;

				//出発日時
				s = $(this).find("td.BodyCOL4").text();
				//result = s.match("^([0-9]{4})/([0-9]{2})/([0-9]{2}) ([0-9]{2}):([0-9]{2})$");
				result  =  s.match("([0-9]{4})/([0-9]{2})/([0-9]{2}).+");
				result2 =  s.match("([0-9]{2}):([0-9]{2})");
				//if (result) {
					flightDate = result[1] + "/" + result[2] + "/" + result[3];
					flightDateJP = result[1] + "年" + result[2] + "月" + result[3] + "日";
					depHour = result2[1];
					depMinute = result2[2];
				//}

				//到着日時
				s = $(this).find("td.BodyCOL5").text();
				result = s.match("([0-9]{2}):([0-9]{2})");
				//if (result) {
					arrHour = result[1];
					arrMinute = result[2];
				//}

				//type tickit
				s = $(".TBLTikets .FlightInformation1 td.BodyCOL3").first().text();
				$res = s.match(/HAPPLUS/);
				if ($res) {
					ticketType = "ハッピーピーチプラス";
				} else
				{
					ticketType = "ハッピーピーチ（預け手荷物なし）";
				}

				//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				strValue = "";
				strValue += flightDate.toString();
				strValue += "/" + "APJ" + "/" + flightNo;
				strValue += "/" + fixJalAirportName(depAirport);
				strValue += "/" + fixJalAirportName(arrAirport);
				strValue += "/" + depHour.toString();
				strValue += "/" + depMinute.toString();
				strValue += "/" + arrHour.toString();
				strValue += "/" + arrMinute.toString();
				strValue += "/" + reserveNo.toString();
				strValue += "/" + dtmLimitDate.toString();
				strValue += "/" + seat;
				strValue += "/" + ticketType;

				//
				strText = "";
				strText += flightDate.toString();
				strText += "/" + "APJ" + "/" + flightNo;
				strText += "/" + fixJalAirportName(depAirport);
				strText += "/" + fixJalAirportName(arrAirport);

				line_no = sessionStorage.getItem('line_no');
				carrier = sessionStorage.getItem('carrier');
				data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
				
				console.log(data_callback);
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				
				setTimeout(function() {
					setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
				}, CMS_TIMEOUT_INMILISECONDS);

			}

            //one
			if (i == 2) {
				//フライト
				//MM 151
				s = $(this).find("td.BodyCOL1").text();
                if(s!='')
                {

				$res = s.match(/([A-Z]+)\s+([0-9]+)/);
				flightNo = $res[0].substring(3);

				//出発地
				//大阪（関西空港）
				s = $(this).find("td.BodyCOL2").text();
				depAirport = s;

				//目的地
				s = $(this).find("td.BodyCOL3").text();
				arrAirport = s;

				//出発日時
				s = $(this).find("td.BodyCOL4").text();
				//result = s.match("^([0-9]{4})/([0-9]{2})/([0-9]{2}) ([0-9]{2}):([0-9]{2})$");
				result  =  s.match("([0-9]{4})/([0-9]{2})/([0-9]{2}).+");
				result2 =  s.match("([0-9]{2}):([0-9]{2})");
				//if (result) {
					flightDate = result[1] + "/" + result[2] + "/" + result[3];
					flightDateJP = result[1] + "年" + result[2] + "月" + result[3] + "日";
					depHour = result2[1];
					depMinute = result2[2];
				//}

				//到着日時
				s = $(this).find("td.BodyCOL5").text();
				result = s.match("([0-9]{2}):([0-9]{2})");
				//if (result) {
					arrHour = result[1];
					arrMinute = result[2];
				//}

				//type tickit
				s = $(".TBLTikets .FlightInformation1:eq(1) td.BodyCOL3").first().text();
				$res = s.match(/HAPPLUS/);
				if ($res) {
					ticketType = "ハッピーピーチプラス";
				} else
				{
					ticketType = "ハッピーピーチ（預け手荷物なし）";
				}

				//2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				strValue2 = "";
				strValue2 += flightDate.toString();
				strValue2 += "/" + "APJ" + "/" + flightNo;
				strValue2 += "/" + fixJalAirportName(depAirport);
				strValue2 += "/" + fixJalAirportName(arrAirport);
				strValue2 += "/" + depHour.toString();
				strValue2 += "/" + depMinute.toString();
				strValue2 += "/" + arrHour.toString();
				strValue2 += "/" + arrMinute.toString();
				strValue2 += "/" + reserveNo.toString();
				strValue2 += "/" + dtmLimitDate.toString();
				strValue2 += "/" + seat;
				strValue2 += "/" + ticketType;

				//
				strText2 = "";
				strText2 += flightDate.toString();
				strText2 += "/" + "APJ" + "/" + flightNo;
				strText2 += "/" + fixJalAirportName(depAirport);
				strText2 += "/" + fixJalAirportName(arrAirport);

				line_no = sessionStorage.getItem('line_no');
				carrier = sessionStorage.getItem('carrier');
				data_callback = '';
				data_callback = strValue2 + '|' + strText2 + '|' + line_no + '|' + carrier;
				console.log(data_callback);
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				
				setTimeout(function() {
					setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
				}, CMS_TIMEOUT_INMILISECONDS);

                }
			}

			i++;
		});

	}
}*/


function writePerson(array_index)
{
    if(array_index)
    {
        n = array_index.length;
        for (i=0; i<=n; i++) {
            writeItem('application_traveller_list_' + array_index[i] + '_age');
            writeItem('application_traveller_list_' + array_index[i] + '_sex');
            writeItem('application_traveller_list_' + array_index[i] + '_birthday');
            writeItem('application_traveller_list_' + array_index[i] + '_first_name_rome');
            writeItem('application_traveller_list_' + array_index[i] + '_last_name_rome');
		}
    }
}

function writePersonInfant(){
    for (i=0; i<=1; i++)
    {
        writeItem('application_infant_list_' + i.toString() + '_age');
        writeItem('application_infant_list_' + i.toString() + '_sex');
        writeItem('application_infant_list_' + i.toString() + '_birthday');
        writeItem('application_infant_list_' + i.toString() + '_first_name_rome');
        writeItem('application_infant_list_' + i.toString() + '_last_name_rome');
    }
}

function writeItem(key){
  temp = $.trim(sessionStorage.getItem('cms_app_id')) + "_";
  key = temp + key;
  xdLocalStorage.getItem(key, function(data) {
    //console.log(data.value);
    orginalKey = key.replace(temp, '');
    if (!!data.value) {
        $("body").append("<input type='hidden' id='"+orginalKey+"' name='"+orginalKey+"' value='" + data.value + "'>");
    }
  });
}

$(document).ready(function() {
	var domain_name = document.domain;
	var loc = window.location;
    /*************
    @Thuytq 2016-03-17 add >>
    */
    if (domain_name == "booking.flypeach.com") {

        //calback
        //path_callback   =  new RegExp(/https:\/\/booking.flypeach.com\/jp\/done\?access_uuid=(.*)/);
        //path_callback   =  new RegExp(/https:\/\/booking.flypeach.com\/jp\/done/);
		path_callback = new RegExp(/https:\/\/booking.flypeach.com\/jp\/pay\/prepared/);
        res_calback     = path_callback.test(loc);
		if (res_calback) {
			
			setTimeout(function() {
				setFlightInformation_APJC();
		    	console.log('setFlightInformation_APJC done');
			}, 2000);
			
			//set hash url
			setTimeout(function() {
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				line_no = $.trim(sessionStorage.getItem('line_no'));
				line_no_org = $.trim(sessionStorage.getItem('line_no'));
				
				if($('.content_complete-row .content_complete-flight .info_trip-table .info_trip-row').length>1){
					line_no = line_no+'-'+(parseInt(line_no)+1);
				}
				var hash_id = cms_app_id + "_" + line_no + "_APJ";//#3667664_0_APJ
				window.location.hash = cms_app_id + "_" + line_no_org + "_APJ";//#3667664_0_APJ
				
				$("a[href='/jp/pay/redirect']").attr('href', '/jp/pay/redirect' + hash_id);
				var url_redirect = 'https://booking.flypeach.com/jp/pay/redirect' + hash_id;
				//window.open(url_redirect,'_blank');
				console.log("***redirect payment link***" + url_redirect);
			}, CMS_TIMEOUT_INMILISECONDS);
			
		    //setTimeout(function() {
			//	myString = $('body').text().toString();
			//    arr = myString.match(/https:\/\/api.openpay.mx\/v1\/(.*)\/charges\/(.*)\/redirect\//);
			//	
			//	
			//		
			//	
			//	
			//    if(arr != null){
			//    	cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			//    	line_no_payment = $.trim(sessionStorage.getItem('line_no'));
			//		
			//		if($('.content_complete-row .content_complete-flight .info_trip-table .info_trip-row').length>1){
			//			line_no_payment = line_no_payment+'-'+(parseInt(line_no_payment)+1);
			//		}
			//		
			//    	carrier = $.trim(sessionStorage.getItem('carrier'));
			//    	url_redirect = arr[0]  + cms_app_id + "_" + line_no_payment + "_" + carrier;
			//    	//window.location.href = url_redirect;//open in cur tab
			//    	window.open(url_redirect,'_blank');// open new tap
			//    }
			//    console.log('setFlightInformation_APJC-ARR ' + arr);
			//}, 3000);
		    
        }

        patt = new RegExp(/https:\/\/booking.flypeach.com\/jp\/profile/);
        res = patt.test(loc);
		if (res) {

                $("span[key='profile.nextButton']").click(function(){
                    //alert("ok");
                    $("div[riot-tag='modal-error']").hide();
                    $("p.error_text-c").hide();
                    $("form[name='form']").submit();
                })


            	var strValue = "";
				var inp = null;
				var sel = null;
				var adultCount = 0,
				    childCount = 0,
				    infantCount = 0;
				var adultCount_index = null,
				    childCount_index = null;

				//get position
				setTimeout(function() {
					cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
					line_no = $.trim(sessionStorage.getItem('line_no'));
					window.location.hash = cms_app_id + "_" + line_no + "_APJ";//#3667664_0_APJ
					xdLocalStorage.getItem(cms_app_id + "_application_traveller_list_adult_child_index", function(data) {
						//console.log(data.value);
						if (!!data.value) {
							$("body").append("<input type='hidden' id='application_traveller_list_adult_child_index' name='application_traveller_list_adult_child_index' value='" + data.value + "'>");

						}
					});

				}, CMS_TIMEOUT_INMILISECONDS);

				setTimeout(function() {
					//get
					var str = $("#application_traveller_list_adult_child_index").val();
					if (str != '' && typeof (str) != 'undefined') {
						var res = str.split(";");
						if (res[0]) {
							adultCount_index = res[0].toString().split("|");
							adultCount = adultCount_index.length;
                            //write html
                            writePerson(adultCount_index);
							console.log(adultCount_index + "=>adultCount:" + adultCount);
						}
						if (res[1]) {
							childCount_index = res[1].toString().split("|");
							childCount = childCount_index.length;

                            //write html
                            writePerson(childCount_index);
							console.log(childCount_index + "=>childCount:" + childCount);
						}
					}
                    //write infant
                    writePersonInfant();

				}, CMS_TIMEOUT_INMILISECONDS + 500);

				var i = 0;
				var j = 0;
				var l = 0;
				console.log(adultCount_index);
                setTimeout(function() {
                var checkTextPage2 = $.trim($("h2.content_header-heading").first().text());
    			if (checkTextPage2 == "搭乗者情報") {console.log("532");

                    if($($(".content_inner-c")[0]).html()!="")
                    {console.log("535");
                        var item = $($($(".content_inner-c")[0]).find('.profile_input_form-c').children('div')[1]).children('div');
                        //var item = $($(".content_inner-c")[0].$('.profile_input_form-c')[0]).$('div')[1];
                        item.each(function(index) {console.log("537");
                            var txt_person = $($(this).find('.txt_person')).first().text();

                            if(txt_person=="大人")
                            {console.log("541");
                                var lastname  =  $('#application_traveller_list_' + adultCount_index[i].toString() + '_last_name_rome').val();
                                var firstname =  $('#application_traveller_list_' + adultCount_index[i].toString() + '_first_name_rome').val();
                                var sex       =  $('#application_traveller_list_' + adultCount_index[i].toString() + '_sex').val();
                                var birthday  =  $('#application_traveller_list_' + adultCount_index[i].toString() + '_birthday').val();

                                var str = birthday.replace(/[^\d]/g,'')
                                var y = str[0]+str[1]+str[2]+str[3];
                                var m = str[4]+str[5];
                                var d = str[6]+str[7];


                               /* $(this).find('input[name="lastname"]').first().val(lastname + 'S');
                                $(this).find('input[name="lastname"]').first().trigger('change');
                                $(this).find('input[name="lastname"]').first().trigger('keyup');*/
                                $(this).find('input[name="lastname"]').first().val(lastname);
                                $(this).find('input[name="lastname"]').first().trigger('change');
                                $(this).find('input[name="lastname"]').first().trigger('keyup');
                                $(this).find('input[name="firstname"]').first().val(firstname);
//                                $(this).find('input[name="firstname"]').first().trigger('change');
                                var type_sex =  "";console.log("562");
                                if(sex==1)
                                {
                                      type_sex = "M";
                                      if($(this).find('input:radio[name="genderType"]').is(':checked') === false) {
                                            $(this).find('input:radio[name="genderType"]').filter('[value=male]').attr('checked', true);
                                            $(this).find('input:radio[name="genderType"]').filter('[value=male]').parent('label').addClass('checked-s focus-s');
                                      }
                                }else
                                {     type_sex = "F";
                                      if($(this).find('input:radio[name="genderType"]').is(':checked') === false) {
                                            $(this).find('input:radio[name="genderType"]').filter('[value=female]').attr('checked', true);
                                            $(this).find('input:radio[name="genderType"]').filter('[value=female]').parent('label').addClass('checked-s focus-s');
                                      }

                                }console.log("576");



                                //year
                                $(this).find('select[name="birthyear"] option[value="'+y+'"]').attr('selected', 'selected');
                                $(this).find('select[name="birthmonth"] option[value="'+parseInt(m)+'"]').attr('selected', 'selected');
                                $(this).find('select[name="birthdate"] option[value="'+parseInt(d)+'"]').attr('selected', 'selected');

                                $("input[name='passengers["+i+"][lastname]']").val(lastname);
                                $("input[name='passengers["+i+"][firstname]']").val(firstname);
                                $("input[name='passengers["+i+"][gender_type]']").val(type_sex);
                                $("input[name='passengers["+i+"][date_of_birth]']").val(y+"/"+m+"/"+d);


                                $("input[name='passengers["+i+"][lastname]']").first().trigger('change');

            				    i++;

                            }else if(txt_person=="幼児"){

                                var lastname  =  $('#application_infant_list_' + l.toString() + '_last_name_rome').val();
                                var firstname =  $('#application_infant_list_' + l.toString() + '_first_name_rome').val();
                                var sex       =  $('#application_infant_list_' + l.toString() + '_sex').val();
                                var birthday  =  $('#application_infant_list_' + l.toString() + '_birthday').val();

                                var str = birthday.replace(/[^\d]/g,'')
                                var y = str[0]+str[1]+str[2]+str[3];
                                var m = str[4]+str[5];
                                var d = str[6]+str[7];

                                $(this).find('input[name="lastname"]').first().val(lastname);
                                $(this).find('input[name="firstname"]').first().val(firstname);

                                var type_sex =  "";
                                if(sex==1)
                                {
                                      type_sex = "M";
                                      if($(this).find('input:radio[name="genderType"]').is(':checked') === false) {
                                            $(this).find('input:radio[name="genderType"]').filter('[value=male]').attr('checked', true);
                                            $(this).find('input:radio[name="genderType"]').filter('[value=male]').parent('label').addClass('checked-s focus-s');
                                      }
                                }else
                                {
                                      type_sex = "F";
                                      if($(this).find('input:radio[name="genderType"]').is(':checked') === false) {
                                            $(this).find('input:radio[name="genderType"]').filter('[value=female]').attr('checked', true);
                                            $(this).find('input:radio[name="genderType"]').filter('[value=female]').parent('label').addClass('checked-s focus-s');
                                      }

                                }

                                 //year
                                $(this).find('select[name="birthyear"] option[value="'+y+'"]').attr('selected', 'selected');
                                $(this).find('select[name="birthmonth"] option[value="'+parseInt(m)+'"]').attr('selected', 'selected');
                                $(this).find('select[name="birthdate"] option[value="'+parseInt(d)+'"]').attr('selected', 'selected');

                                $("input[name='passengers["+i+"][lastname]']").val(lastname);
                                $("input[name='passengers["+i+"][firstname]']").val(firstname);
                                $("input[name='passengers["+i+"][gender_type]']").val(type_sex);
                                $("input[name='passengers["+i+"][date_of_birth]']").val(y+"/"+m+"/"+d);

                                i++;
								l++;

                            }else
                            {
                                var lastname  =  $('#application_traveller_list_' + childCount_index[j].toString() + '_last_name_rome').val();
                                var firstname =  $('#application_traveller_list_' + childCount_index[j].toString() + '_first_name_rome').val();
                                var sex       =  $('#application_traveller_list_' + childCount_index[j].toString() + '_sex').val();
                                var birthday  =  $('#application_traveller_list_' + childCount_index[j].toString() + '_birthday').val();


                                var str = birthday.replace(/[^\d]/g,'')
                                var y = str[0]+str[1]+str[2]+str[3];
                                var m = str[4]+str[5];
                                var d = str[6]+str[7];


                                $(this).find('input[name="lastname"]').first().val(lastname);
                                $(this).find('input[name="firstname"]').first().val(firstname);
                                var type_sex =  "";
                                if(sex==1)
                                {
                                      type_sex = "M";
                                      if($(this).find('input:radio[name="genderType"]').is(':checked') === false) {
                                            $(this).find('input:radio[name="genderType"]').filter('[value=male]').attr('checked', true);
                                            $(this).find('input:radio[name="genderType"]').filter('[value=male]').parent('label').addClass('checked-s focus-s');
                                      }
                                }else
                                {
                                      type_sex = "F";
                                      if($(this).find('input:radio[name="genderType"]').is(':checked') === false) {
                                            $(this).find('input:radio[name="genderType"]').filter('[value=female]').attr('checked', true);
                                            $(this).find('input:radio[name="genderType"]').filter('[value=female]').parent('label').addClass('checked-s focus-s');
                                      }

                                }
                                //year
                                $(this).find('select[name="birthyear"] option[value="'+y+'"]').attr('selected', 'selected');
                                $(this).find('select[name="birthmonth"] option[value="'+parseInt(m)+'"]').attr('selected', 'selected');
                                $(this).find('select[name="birthdate"] option[value="'+parseInt(d)+'"]').attr('selected', 'selected');

                                $("input[name='passengers["+i+"][lastname]']").val(lastname);
                                $("input[name='passengers["+i+"][firstname]']").val(firstname);
                                $("input[name='passengers["+i+"][gender_type]']").val(type_sex);
                                $("input[name='passengers["+i+"][date_of_birth]']").val(y+"/"+m+"/"+d);

            				   	i++;
								j++;
                            }

                             //$(this).find("label.input_text-c").addClass('border_change-s');

                        });


                    }console.log("693");

                		getItem("application_traveller_list_0_last_name_rome", ".h-adr input[name='lastname']","inputName");
                        getItem("application_traveller_list_0_last_name_rome", "input[name='applicant[lastname]']","inputName");

    					getItem("application_traveller_list_0_first_name_rome", ".h-adr input[name='firstname']","inputName");
                        getItem("application_traveller_list_0_first_name_rome", "input[name='applicant[firstname]']","inputName");

                        getItem("application_traveller_list_0_sex", ".h-adr input:radio[name='genderType']","BTN_SEX");
                        getItem("application_traveller_list_0_sex", "input[name='applicant[gender_type]']","BTN_SEX_HIDDEN");
    					//PCメールアドレス
    					//置換前
                        /*strValue = "cc@tokyo-ogasawarakai.com";
    					$(".h-adr input[name='email']").val(strValue);
                        $("input[name='applicant[email]']").val(strValue);*/
                        //置換後
                        chrome.storage.sync.get('apj_add', function(result){
                            strValue = "cc@tokyo-ogasawarakai.com";
                            if (result.apj_add) strValue = result.apj_add;console.log(strValue);
                            $(".h-adr input[name='email']").val(strValue);
                            $("input[name='applicant[email]']").val(strValue);
                        });
                        //ここまで
                        $(this).find('.h-adr select[name="country"] option[value="JP"]').attr('selected', 'selected');
                        $("input[name='applicant[country]").val("JP");

                        $(this).find('.h-adr select[name="purpose"] option[value="6"]').attr('selected', 'selected');
                        $("input[name='applicant[purpose]").val(6);

    					//電話番号1
                        getItem("application_tel1", ".h-adr input[name='phone']","inputName");
                        getItem("application_tel1", "input[name='applicant[phone]']","inputName");
                        //郵便番号
                        getItem("application_zip_code", ".h-adr input[name='zipCode']","inputName");
                        getItem("application_zip_code", "input[name='applicant[zip_code]']","inputName");
                        //都道府県
                        getItem("application_address2", ".h-adr input[name='state']","inputName");
                        getItem("application_address2", "input[name='applicant[state]']","inputName");
    					//番地・ビル名等
                        getItem("application_address3", ".h-adr input[name='city']","inputName");
                        getItem("application_address3", "input[name='applicant[city]']","inputName");
                        //電話番号1
                        getItem("application_address4", ".h-adr input[name='street']","inputName");
                        getItem("application_address4", "input[name='applicant[street]']","inputName");

                        //$(".h-adr").find("label.input_text-c").addClass('border_change-s');
             }

             }, CMS_TIMEOUT_INMILISECONDS + 2000);

		}
		
		//patt = new RegExp(/https:\/\/booking.flypeach.com\/jp\/pay\/prepared_test/);
        //res = patt.test(loc);
		//if (res) {
		//	//set hash url
		//	setTimeout(function() {
		//		cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
		//		line_no = $.trim(sessionStorage.getItem('line_no'));
		//		var hash_id = cms_app_id + "_" + line_no + "_APJ";//#3667664_0_APJ
		//		window.location.hash = hash_id;
		//		$("a[href='/jp/pay/redirect']").attr('href', '/jp/pay/redirect' + hash_id);
		//		console.log("***redirect payment link*** /jp/pay/redirect" + hash_id);
		//	}, CMS_TIMEOUT_INMILISECONDS);
		//}
    }
	
	
	
    //https://link.kessai.info/JLP/JLPcon?code=6sb4.Rd0WAf.Dki44Oc0f8.&rkbn=1
    if (domain_name == "link.kessai.info") {
    	//call back to cms 01
    	setTimeout(function() {
    		hash = window.location.hash;
		  	//new
            var limit_hold = "_"+document.getElementById("paydetail").querySelector("table").rows[3].cells[1].innerText.split('　※')[0];
			console.log('setFlightInformation_APJC_Hash' + hash + "limit_hold:" + limit_hold);
            //end
		  	if(hash != ""){
		  		fligh_info = hash.split('_');
                //置換前
		  		//setValue(fligh_info[0] +'_merchant_flight_info_callback_linkpayment' + fligh_info[1], encodeURI(loc));
                //置換後
                setValue(fligh_info[0] +'_merchant_flight_info_callback_linkpayment' + fligh_info[1], encodeURI(loc)+limit_hold);
		  	}
		}, CMS_TIMEOUT_INMILISECONDS);
		console.log('setFlightInformation_APJC_PAY done' + loc);
    }
	if (domain_name == "www5.econ.ne.jp" || domain_name ==  "pay.econ.ne.jp") {
		//call back to cms 01
		setTimeout(function() {
			var hash = window.location.hash;
			//var limit_hold_elm = document.getElementById("SidebarPayment").querySelector("ul li:last-child").innerText.split("\n");
			//var limit_hold = '_' + limit_hold_elm[1] + ' ' + limit_hold_elm[2];
			var limit_year = $(".pay-board_limit__year").text();
			var limit_date = $(".pay-board_limit__date").text();
			var limit_time = $(".pay-board_limit__time").text();
			var limit_hold = '_' + limit_year + limit_date + limit_time;
			console.log('setFlightInformation_APJC_Hash' + hash + "limit_hold:" + limit_hold);
			//end
			if (hash != "") {
				var fligh_info = hash.split('_');
				//置換後
				setValue(fligh_info[0] +'_merchant_flight_info_callback_linkpayment' + fligh_info[1], encodeURI(loc) + limit_hold);
			}
		}, CMS_TIMEOUT_INMILISECONDS);
		console.log('setFlightInformation_APJC_PAY done ' + loc);
	}
    /*************
    @Thuytq 2016-03-17 add <<
    */

	//******29925confirm apj******//https://manage.flypeach.com/jp/manage/retrieve-booking
	if (domain_name == "manage.flypeach.com") {
		patt = new RegExp(/https:\/\/manage.flypeach.com\/jp\/manage\/retrieve-booking/);
        res = patt.test(loc);
		if (res) {
			//var line_no = sessionStorage.getItem('line_no');
			hash = window.location.hash;
			flight_info = hash.split("_");
			var line_no = flight_info[1];
			setTimeout(function(){
				getItem('application_ticket_reservation_no' + line_no,'mat-input-0', 'pnr_apj_id');
				getItem('application_last_name_rome' + line_no,'mat-input-1', 'pnr_apj_id');
				getItem('application_ticket_reservation_no' + line_no,'search-booking-button.mat-raised-button.mat-button-base.mat-primary', 'pnr_jjp_btn');				
				//$("[type='submit']").trigger('click');
				console.log('***************setFlightInformation_confirm done***************');
			}, CMS_TIMEOUT_INMILISECONDS);
		}
	}

	/*if (domain_name == "book.flypeach.com") {

		$('#dvMessageButtonText').live('click', function(e){
			 setFlightInformation_APJC_OLD();
			 console.log('setFlightInformation_APJC_OLD done');
		});


		patt = new RegExp(/https:\/\/book.flypeach.com\/default.aspx\?langculture=ja-jp&ao.+/);
		res = patt.test(loc);
		if (res) {

			var checkTextPage2 = $.trim($(".MainContactDetails .Boxtopmiddle").first().text());
			if (checkTextPage2 == "申込者情報 ※姓、名の順番を正しく入力下さい") {
				
				var strValue = "";
				var inp = null;
				var sel = null;
				var adultCount = 0,
				    childCount = 0,
				    infantCount = 0;
				var adultCount_index = null,
				    childCount_index = null;

				//get position
				setTimeout(function() {
					xdLocalStorage.getItem("application_traveller_list_adult_child_index", function(data) {
						//console.log(data.value);
						if (!!data.value) {
							$("body").append("<input type='hidden' id='application_traveller_list_adult_child_index' name='application_traveller_list_adult_child_index' value='" + data.value + "'>");

						}
					});

				}, CMS_TIMEOUT_INMILISECONDS);

				setTimeout(function() {
					//get
					var str = $("#application_traveller_list_adult_child_index").val();
					if (str != '' && typeof (str) != 'undefined') {
						var res = str.split(";");
						if (res[0]) {
							adultCount_index = res[0].toString().split("|");
							adultCount = adultCount_index.length;
							console.log(adultCount_index + "=>adultCount:" + adultCount);

						}
						if (res[1]) {
							childCount_index = res[1].toString().split("|");
							childCount = childCount_index.length;
							console.log(childCount_index + "=>childCount:" + childCount);
						}
					}
				}, CMS_TIMEOUT_INMILISECONDS + 500);

				var i = 0;
				var j = 0;
				var l = 0;

				$(".Paxicon ul").each(function(index) {
					var className = $(this).attr('class');
					if (className != null) {
						if (className == "PaxAdult") {

							setTimeout(function() {
								if (adultCount_index[i]) {
									getItem('application_traveller_list_' + adultCount_index[i].toString() + '_birthday', "hdBirthDate_" + (i + 1).toString(), 'Y/M/D');
									getItem('application_traveller_list_' + adultCount_index[i].toString() + '_sex', "hdTitle_" + (i + 1).toString());
									getItem('application_traveller_list_' + adultCount_index[i].toString() + '_last_name_rome', "hdLastname_" + (i + 1).toString());
									getItem('application_traveller_list_' + adultCount_index[i].toString() + '_first_name_rome', "hdName_" + (i + 1).toString());
									//optionend
									getItem('application_traveller_list_' + adultCount_index[i].toString() + '_first_name_rome', i, 'endParseAdultAPJC');
									i++;
								}
							}, CMS_TIMEOUT_INMILISECONDS + 1000);

						} else if (className == "PaxChildren") {
							setTimeout(function() {

								if (childCount_index[j]) {
									getItem('application_traveller_list_' + childCount_index[j].toString() + '_birthday', "hdBirthDate_" + (i + 1).toString(), 'Y/M/D');
									getItem('application_traveller_list_' + childCount_index[j].toString() + '_sex', "hdTitle_" + (i + 1).toString());
									getItem('application_traveller_list_' + childCount_index[j].toString() + '_last_name_rome', "hdLastname_" + (i + 1).toString());
									getItem('application_traveller_list_' + childCount_index[j].toString() + '_first_name_rome', "hdName_" + (i + 1).toString());
									//optionend
									getItem('application_traveller_list_' + l.toString() + '_first_name_rome', j, 'endParseChildrenAPJC');
									i++;
									j++;
								}

							}, CMS_TIMEOUT_INMILISECONDS + 1000);

						} else if (className == "PaxInfant") {
							setTimeout(function() {

								getItem('application_infant_list_' + l.toString() + '_birthday', "hdBirthDate_" + (i + 1).toString(), 'Y/M/D');
								getItem('application_infant_list_' + l.toString() + '_sex', "hdTitle_" + (i + 1).toString());
								getItem('application_infant_list_' + l.toString() + '_last_name_rome', "hdLastname_" + (i + 1).toString());
								getItem('application_infant_list_' + l.toString() + '_first_name_rome', "hdName_" + (i + 1).toString());
								//optionend
								getItem('application_infant_list_' + l.toString() + '_first_name_rome', l, 'endParseInfantAPJC');
								i++;
								l++;

							}, CMS_TIMEOUT_INMILISECONDS + 1000);

						}
					}// end if null
				});

				setTimeout(function() {
					getItem('application_traveller_list_0_sex', 'ctl00_stContactTitle');
					getItem('application_traveller_list_0_last_name_rome', 'ctl00_txtContactLastname');
					getItem('application_traveller_list_0_first_name_rome', 'ctl00_txtContactFirstname');
					//PCメールアドレス
					strValue = "cc@tokyo-ogasawarakai.com";
					$("#ctl00_txtContactEmail").val(strValue);
					//電話番号1
					getItem('application_tel1', 'ctl00_txtContactHome');
					//電話番号1
					getItem('application_address4', 'ctl00_txtContactAddress1');
					//番地・ビル名等
					getItem('application_address3', 'ctl00_txtContactCity');
					//都道府県
					getItem('application_address2', 'ctl00_txtContactState');
					//郵便番号
					getItem('application_zip_code', 'ctl00_txtContactZip');
				}, CMS_TIMEOUT_INMILISECONDS + 1000);

			}

		}
	}*/
}); 