﻿function fixAnaDateNew(strText) {
	// 2019年5月16日（木）まで
	intPos = 0;
	intMonth = 0;
	intDay = 0;
	intYear = 0;
	dtmNow = 0;
	dtmDate = 0;
    dtmNow = new Date();
    intYear = dtmNow.getFullYear();
	strText = strText.toString(); 
    intPos = strText.indexOf("区間1");
    if (intPos != -1 ) {
    	strText = strText.substring(intPos + 3);
    }
    intPos = strText.indexOf("月");
    if (intPos != -1 ) {
        intPos = strText.indexOf("年");
        intYear1 = parseInt(strText.substring(0, intPos));        
        strText = strText.substring(intPos + 1);
        intPos = strText.indexOf("月");
        intMonth = parseInt(strText.substring(0, intPos));        
        strText = strText.substring(intPos + 1);
        
        intPos = strText.indexOf("日");
        if (intPos != -1 ) {
            intDay = parseInt(strText.substring(0, intPos));   
            dtmDate =   intYear1 +"/" + intMonth + "/" + intDay;
            return dtmDate;
         }
    }
	return new Date(DATE_MIN_VAL,1,1);               
}
	function setFlightInformationJal() {
		var strLimitDate = '';
		var strLimitDateText = '';
		var data_callback = '';
		
		dtmLimitDate = $('.list-info_hdg span').text().toString();
		dtmLimitDate = fixAnaDateNew(dtmLimitDate);

        //strLimitDate = fixAnaDate(strLimitDateText);
		//strLimitDate = formatDate(strLimitDate);//2016/01/09
		
		strValue = "";
		strText = "";
		curTable = $('.table-number');
		if (typeof(curTable[0]) != 'undefined') {
			reserno = getCellValueInTable(curTable, 1, 2);
			
			dtmFlightDate = $('.list-desc-line dt').text().toString();
			dtmFlightDate = fixAnaDateNew(dtmFlightDate);
			
			flight_info = $('.list-desc-line_plan_class li').text().toString();
			airline_name = flight_info.match(/([a-zA-Z]{3})/gi);
			airline = airline_name.toString().trim();
			flightno = flight_info.match(/([0-9]{4})|([0-9]{3})/gi);
			
			var cl_wifi = $('.list-desc-line_plan_option li.wifi').text().toString();
			var wifi = 0;
			if(cl_wifi != "undefined" && cl_wifi){
				wifi = 1;
			}
			console.log("wifi-" + wifi + "/" + cl_wifi);
			str = $('.list-desc-line_plan_date').text().toString();
			arr = str.split("→");
			
			dep_time = arr[0].match(/([0-9]{2}):([0-9]{2})/gi);
			dep = arr[0].replace(dep_time, "");
			des_time = arr[1].match(/([0-9]{2}):([0-9]{2})/gi);
			des = arr[1].replace(des_time, "");
			
			dep = dep.toString().trim();
			des = des.toString().trim();
			deptime = dep_time.toString().trim();
			destime = des_time.toString().trim();
			
			arr = flight_info.split("：");
			if(arr[2]){
				seat = arr[2].toString().trim();
				seat = seat.replace(' ','');
				if(seat == '普通席')
					seat = '普通';
			}
			hourdep = deptime.replace(":","/");
			hourdes = destime.replace(":","/");
			
			ticket_type = $('.list-desc-line_price_table .sup th').text().toString();
			
			ticket_type_list = [
				'株主割引',
				'特便割引1-タイプA',
				'特便割引1-タイプB',
				'特便割引1-タイプC',
				'特便割引1-タイプD',
				'特便割引3-タイプA',
				'特便割引3-タイプB',
				'特便割引3-タイプC',
				'特便割引3-タイプD',
				'特便割引7-タイプA',
				'特便割引7-タイプB',
				'特便割引7-タイプC',
				'特便割引7-タイプD',
				'特便割引7-タイプE',
				'特便割引21-タイプD',
				'特便割引21-タイプE',
				'身体障がい者割引',
				'スーパー先得',
				'ウルトラ先得',
				'先得割引-タイプA',
				'先得割引-タイプB',
				'普通運賃'
			];
			
			ticket_type_list.forEach(function(item, index, array) {
				if(ticket_type.indexOf(item) != -1){
					ticket_type = item;
				}
			});
			
			
			//alert(seat + "/" + hourdep + "/" + hourdes + "/" + des);
			//value=//2009/03/31/JAL/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
			//text =//3月30日（月）/JAL/548/札幌(千歳)/東京(羽田)
			strValue = dtmFlightDate + "/" + airline +"/" + flightno + "/" + dep + "/" + des;
			strText = strValue;
			strValue += "/"+ hourdep  + "/" + hourdes + "/" + reserno + "/"+ dtmLimitDate + "/" + seat;
			strValue += "/"+ ticket_type;
			strValue += "/wifi="+ wifi;
			line_no = sessionStorage.getItem('line_no');
			carrier = sessionStorage.getItem('carrier');
			cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			
			mile = $.trim(sessionStorage.getItem(cms_app_id +'_mile_callback' + line_no));
			strValue += "/mile="+ mile;
			
			data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
			console.log(data_callback);
			cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			setTimeout(function(){
				setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
			}, CMS_TIMEOUT_INMILISECONDS);
		}
	}
	

	$( document ).ready(function() {
		var domain_name = document.domain;
		var loc = window.location;
		// test >>> 
		if(loc.toString().indexOf('jal-end/jal_complete.html') != -1) {
				setFlightInformationJal();
				console.log('setFlightInformationJal done');
			}
		if(loc.toString().indexOf('/rsv/ReservationComplete.do') != -1) {
				setFlightInformationJal();
				console.log('setFlightInformationJal done');
			}

		// <<< test 
		if(domain_name=="www.5971.jal.co.jp"){
			if (loc == "https://www.5971.jal.co.jp/rsv/ETicketDetail.do") {
				setTimeout(function(){
					getItem('application_flight_certification_ymd','form-link-calendar_data','id_jal_date_calendar', 'board');
					getItem('application_flight_certification_flight_no','flightNumber','select');
				}, CMS_TIMEOUT_INMILISECONDS);
			}
			if (loc == "https://www.5971.jal.co.jp/rsv/ETicketSearch.do") {
				setTimeout(function(){
					getItem('application_flight_certification_traveller_last_name','familyNameView','select');
					getItem('application_flight_certification_traveller_first_name','firstNameView','select');
					getItem('application_flight_certification_traveller_last_name_rome','familyName','select');
					getItem('application_flight_certification_traveller_first_name_rome','firstName','select');
					getItem('application_flight_certification_ticket_receipt_no','confirmNoView','select');
				}, CMS_TIMEOUT_INMILISECONDS);
			}
			if(loc=="https://www.5971.jal.co.jp/rsv/InputPassenger.do"){
			
				//cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				//alert(loc.toString() + cms_app_id);return false;
				$('.btn-add').get(0).click();
				$('input:radio[name="telDetailKbn"][value="1"]').attr('checked',true);
				setTimeout(function(){
					getItem("application_common_email","tempMailAddress","mailANA");
					getItem("application_common_email","confirmationTempMailAddress","mailANA");
					getItem('application_tel1',"telno1", 'name');
					//getItem("tel","telno1","name");
					//getItem("tel1","telno2","name");
					//getItem("tel2","telno3","name");
					
					for(i= 0; i < 6; i++){
						j = i + 1;
						getItem('application_traveller_list_' + i.toString() + '_last_name',"familyNameView" + j,"name_jal");
						getItem('application_traveller_list_' + i.toString() + '_first_name',"firstNameView" + j,"name_jal");
						getItem('application_traveller_list_' + i.toString() + '_age',"age" + j,"name_jal");
						getItem('sex' + i.toString(),"sex" + j,"radio");
					}
					for(i= 0; i < 2; i++){
						j = i + 1;
						getItem('application_infant_list_' + i.toString() + '_last_name',"familyNameInfantView" + j,"name_jal");
						getItem('application_infant_list_' + i.toString() + '_first_name',"firstNameInfantView" + j,"name_jal");
						getItem('application_infant_list_' + i.toString() + '_age',"ageInfant" + j,"select");
						getItem('inf_sex' + i.toString(),"sexInfant" + j,"radio");
					}
					getItem('application_common_email',"tempMailAddress","jalendinput");
				}, CMS_TIMEOUT_INMILISECONDS + 500);
			}
			if(loc.toString().indexOf('jal.co.jp/rsv/ReservationConfirm.do') != -1) {
				$('#checkbox-consent-01').attr('checked',true);
				console.log('ReservationConfirmJAL done');
			}
			if(loc.toString().indexOf('jal.co.jp/rsv/ReservationComplete.do') != -1) {
				setFlightInformationJal();
				console.log('setFlightInformationJal done');
			}
			
			if(loc.toString().indexOf('.jal.co.jp/rsv/LFSSearchDispatch.do') != -1) {
				$(function() {
					$("._cell-item.js-table-flight-chart_cell").click(function(e) {
						var clickedValue = $(e.currentTarget).html();
						var attr_col = $(e.currentTarget).attr('data-table-flight-chart-index');
						
						var myRegexp = /submitSelectFlight(.+?)\;return/g;
						var match = myRegexp.exec(clickedValue);
						
						arr = match[1].split("','");
						var class_type = arr[13];
						console.log(attr_col + "/" + class_type + "/" +arr);
						
						var th = $('.w-flight-item.js-table-flight-chart_cell[data-table-flight-chart-index="' + parseInt(attr_col) + '"]');
						//console.log(th.html());
						//data-class=\"y\"[^>]*>(.*?)マイル
						//class_type = class_type.toLowerCase();
						if(class_type =="F")
							myRegexp = /data-class=\"f\"[^>]*>(.*?)マイル/g;
						else if(class_type =="J")
							myRegexp = /data-class=\"j\"[^>]*>(.*?)マイル/g;
						else 
							myRegexp = /data-class=\"y\"[^>]*>(.*?)マイル/g;
						var match1 = myRegexp.exec(th.html());
						if(match1[1]){
							cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
							line_no = $.trim(sessionStorage.getItem('line_no'));
							carrier = sessionStorage.getItem('carrier');
							sessionStorage.setItem(cms_app_id +'_mile_callback' + line_no, match1[1]);
							console.log("mile: "+match1[1] + "/ appid:" + cms_app_id + "/ data_callback: " + match1[1]);
						}
					});
				});
			}
			
			
			/*
			if(loc.toString().indexOf('jal.co.jp/rsv/ScheduleSearchDirectFlightChoose.do') != -1) {
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				$( "body" ).append( "<input type='hidden' id='appId_cms'  value='" + cms_app_id + "'>");
				if(cms_app_id != ""){
			  		//hash = window.location.hash;
			  		sessionStorage.setItem('cms_app_id', cms_app_id);
			  	}
			}
			*/
			if(loc.toString().indexOf("/rsv/SearchReservation.do") != -1){
				setTimeout(function(){
					line_no = $.trim(sessionStorage.getItem('line_no'));
					cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				},500);
				setTimeout(function(){
	    	    		getItem('application_last_name' + line_no,"familyNameView", 'name_jal');
	    	    		getItem('application_first_name' + line_no,"firstNameView", 'name_jal');
	    	    		getItem('application_flight_no' + line_no,"flightNumber", 'name_jal');	    	    		
	    	    		getItem('application_flight_month' + line_no,"boardMonth", 'name');
	    	    		getItem('application_flight_day' + line_no,"boardDay", 'name');
						getItem('application_flight_year' + line_no,"boardYear", 'name');
	    	    		getItem('application_ticket_reservation_no' + line_no,"rsvNo", 'name_jal');
	    	    		getItem('application_airline_name' + line_no,"application_airline_name_jal", 'endConfirmJal');
	    	    		clearAll(cms_app_id, line_no);
	    	    }, CMS_TIMEOUT_INMILISECONDS);
	    	    console.log('setJALConfirmation done');
			}
			
			if(loc.toString().indexOf("jal.co.jp/rsv/InputJmbNo.do") != -1){
				setTimeout(function(){
					for (i=0; i<=5; i++) {
						getItem('application_traveller_list_' + i.toString() + '_name_jal', i, 'mileage_no_jal');
					}
					$('.formButton>input').get(1).click();
				}, CMS_TIMEOUT_INMILISECONDS);
			}
			
			if(loc.toString().indexOf("/rsv/ReservationDetail.do") != -1){
				line_no = $.trim(sessionStorage.getItem('line_no'));
				setTimeout(function(){
					getItem('application_mileage_flag'+line_no,"mileage_jal", 'mileage_jal');
				}, CMS_TIMEOUT_INMILISECONDS);
			}
		} else if(domain_name=="booking.jal.co.jp"){// Confirm booking jal new
			if(loc.toString().indexOf("jl/dom-pbkg/manage-booking") != -1){
				setTimeout(function(){
					var line_no = $.trim(sessionStorage.getItem('line_no'));
					var cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
					var carrier = $.trim(sessionStorage.getItem('carrier'));
					console.log(line_no + '*****cms_app_id****** ' + cms_app_id);
				
					getItem('application_last_name_rome' + line_no,"fieldLast-name", 'id_jal_new');
					getItem('application_first_name_rome' + line_no,"fieldFirst-name", 'id_jal_new');
					getItem('application_flight_no' + line_no,"flight-id", 'id_jal_new');
					getItem('application_ticket_reservation_no' + line_no,"fieldResrvation-no", 'id_jal_new');
					getItem('application_airline_name' + line_no,"selectedvalue-Airline", 'id_jal_new_carrier', carrier);
					getItem('application_flight_date_full' + line_no,"date", 'id_jal_new_datepicker');
					setTimeout(function() {
						$('#guest-search').get(0).click();
						clearAll(cms_app_id, line_no);
					}, CMS_TIMEOUT_INMILISECONDS);
	    	    }, CMS_TIMEOUT_INMILISECONDS);
	    	    console.log('setJALConfirmation done');
			}
		}
	});