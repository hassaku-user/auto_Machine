﻿$(document).ready(function () {
    var domain_name = document.domain;
    var loc = window.location;

    if (domain_name == "www.orc-air.co.jp") {
        var line_no, cms_app_id, key;
        setTimeout(function () {
            line_no = $.trim(sessionStorage.getItem('line_no'));
            cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
            key = cms_app_id + '_flight_info' + (parseInt(line_no) + 1);
        }, 500);
        setTimeout(function () {
            xdLocalStorage.getItem(key, function (data) {
                console.log(data.value);
                if (!!data.value) {
                    setSearchForm(data.value);
                }
            })
        }, CMS_TIMEOUT_INMILISECONDS);
    } else if (domain_name == "rsv.orc-air.co.jp") {
        if (loc.pathname.indexOf('/rsv_p/aln_web/resVacant3.do') !== -1) {
            setTimeout(function () {
                setPassengerFormOrc();
            }, CMS_TIMEOUT_INMILISECONDS);
        } else if (loc.pathname.indexOf('/rsv_p/aln_web/resPaxinfo.do') !== -1) {
            setTimeout(function () {
                $('input[name="baggageCheckBoxCode"]').get(0).click();
            }, 500);
        } else if (loc.pathname.indexOf('/rsv_p/aln_web/resPurchase.do') !== -1) {
            //
            setFlightInformationOrc();
        } else if (loc.pathname.indexOf('/rsv_p/aln_web/BERetrieve.do') !== -1) {
			//confirm reservation
			setTimeout(function(){
				line_no = $.trim(sessionStorage.getItem('line_no'));
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			},500);			
			setTimeout(function(){
					getItem('application_last_name' + line_no,"searchWideForm.lastName", 'name');
					getItem('application_first_name' + line_no,"searchWideForm.firstName", 'name');
					getItem('application_flight_no' + line_no,"searchWideForm.fltNo", 'name');
					getItem('application_flight_year' + line_no,"searchWideForm.selectedEmbYear", 'name');
					getItem('application_flight_month' + line_no,"searchWideForm.selectedEmbMonth", 'name');
					getItem('application_flight_day' + line_no,"searchWideForm.selectedEmbDay", 'name');
					getItem('application_ticket_reservation_no' + line_no,"searchWideForm.rsvNo", 'name');
					getItem('application_ticket_reservation_no' + line_no,"searchWideForm.rsvNo", 'endConfirmSFJ');
					clearAll(cms_app_id, line_no);
					setTimeout(function() {
						$("input[name = 'btnSubmit:mapping=success&rt=rt_rsvno&parameter=loc_search']").click();
					} , 1500);
			}, CMS_TIMEOUT_INMILISECONDS);
			console.log('setORCConfirmation done');
		}
    }
});

function setPassengerFormOrc() {
    for (var i = 0; i < 6; i++) {
        getItem('application_traveller_list_' + i.toString() + '_last_name_rome', "paxInfantForm.lastName[" + i + "]", "name");
        getItem('application_traveller_list_' + i.toString() + '_first_name_rome', "paxInfantForm.firstName[" + i + "]", "name");
        getItem('application_traveller_list_' + i.toString() + '_age', "paxInfantForm.age[" + i + "]", "name");
        getItem('application_traveller_list_' + i.toString() + '_sex', "paxInfantForm.sexCode[" + i + "]", "radioSexORC");
    }
    for (var i = 0; i < 2; i++) {
        getItem('application_infant_list_' + i.toString() + '_first_name_rome', "paxInfantForm.infFirstName[" + i + "]", "name");
        getItem('application_infant_list_' + i.toString() + '_age', "paxInfantForm.infAge[" + i + "]", "name");
        getItem('application_infant_list_' + i.toString() + '_sex', "paxInfantForm.infSexCode[" + i + "]", "radioSexORC");
    }
    getItem('application_infant_count', "paxInfantForm.parentPaxNo", "infCountOrc");
    getItem('application_tel1', "contactForm.telNo", "name");
}

function setSearchForm(flightData) {
    var part = flightData.split("_");
    $('select[name="segConditionForm.selectedDepApo"]').val(part[7]);
    $('select[name="segConditionForm.selectedArrApo"]').val(part[8]);
    $('input[name="segConditionForm.selectedEmbYear"]').val(part[1]);
    $('input[name="segConditionForm.selectedEmbMonth"]').val(part[2])
    $('input[name="segConditionForm.selectedEmbDay"]').val(part[3]);
    $('#reservationBtn-02').val(part[1] + '/' + part[2] + '/' + part[3]);
    var action = $('form[name="form3"]').attr('action');
    $('form[name="form3"]').attr('action', action + window.location.hash);
    console.log('FILL SEARCH FORM COMPLETE');
    // submit form search
    setTimeout(function () {
        $('.MenuContent__btn--reservation-01 a').get(0).click();
    }, 500);
}

function setFlightInformationOrc() {
    var strLimitDate = '';
    var dataCallback = '';

    var tablePurchaseDate = $('table')[13]; // 航空券 > 購入期限
    strLimitDate = $(tablePurchaseDate).find('td:eq(1)').text().trim();

    var tableFlight = $('table')[17]; // フライト
    var rowFlightDetail = $(tableFlight).find('tr:eq(1) td');

    var flightDate = $($(rowFlightDetail)[0]).text().trim(),
        flightNum = $($(rowFlightDetail)[1]).text().trim().split(' '),
        airline = flightNum[0],
        flightNo = flightNum[1],
        airport = $($(rowFlightDetail)[2]).text().trim().split('→'),
        dep = airport[0].trim(),
        des = airport[1].trim(),
        hourDep = $($(rowFlightDetail)[3]).text().trim().replace(":", "/"),
        hourDes = $($(rowFlightDetail)[4]).text().trim().replace(":", "/"),
        reserNo = $($(rowFlightDetail)[6]).text().trim(),
        seat = '', ticketType = '';

    var strValue = formatDate(fixSkyDate(flightDate)) + "/" + airline + "/" + flightNo + "/" + dep + "/" + des;
    var strText = strValue;
    strValue += "/" + hourDep + "/" + hourDes + "/" + reserNo + "/" + formatDate(fixSkyDate(strLimitDate)) + "/" + seat;
    strValue += "/" + ticketType;

    var cms_app_id = $.trim(sessionStorage.getItem('cms_app_id')),
        line_no = $.trim(sessionStorage.getItem('line_no')),
        carrier = $.trim(sessionStorage.getItem('carrier'));

    dataCallback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
    console.log(dataCallback);

    setTimeout(function () {
        setValue(cms_app_id + '_merchant_flight_info_callback' + line_no, dataCallback);
    }, CMS_TIMEOUT_INMILISECONDS);
}
