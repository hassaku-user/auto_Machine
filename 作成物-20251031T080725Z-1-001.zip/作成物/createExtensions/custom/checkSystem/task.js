// =======================
// ANA 専用処理関数群
// =======================

// ANA: マイナスカウント判定
function countANAminus(text) {
  let cleaned = text.normalize("NFKC")
    .replace(/[\u00A0\u2000-\u200B\u202F\u205F\u3000]/g, " ")
    .replace(/\s+/g, " ");

  const patterns = [
    /ANA NOT SUPPORT AUTOBOOKING/gi,
    /ANA自動予約失敗/gi,
    /ANA SUPER VALUE(\s*\S*)?/gi,
    /ANA VALUE(\s*\S*)?/gi,
    /フレックスD/gi
  ];

  return patterns.reduce(
    (sum, re) => sum + (cleaned.match(re) || []).length,
    0
  );
}

// ANA: 通常カウント判定
function countANAInText(text) {
  let countANA = 0;
  let countNum = 0;

  countANA += (text.match(/(^|[^A-Z0-9])ANA([^A-Z0-9]|$)/g) || []).length;

  if (/ANA\s*\d{4}/.test(text)) {
    console.log("⚠️ ANA便名 'ANA ****' があったので数字は無視:", text);
  } else {
    const nums = text.match(/(?<!手:)\b\d{4}(?!\/)\b/g) || [];
    countNum += nums.length;

    if (nums.length < (text.match(/\b\d{4}\b/g) || []).length) {
      console.log("⚠️ ANA: '/' 付きの4桁数字を無視しました:", text);
    }
  }

  const minus = countANAminus(text);
  if (minus > 0) {
    console.log("ANAマイナスカウント：" + minus);
    countANA -= minus;
  }

  return { countANA, countNum };
}


// =======================
// ANA / SKY 判定用関数
// =======================
function countANAandNumbers(td) {
  let countANA = 0;
  let countNum = 0;

  const text = td.textContent.trim().toUpperCase();
  if (!text) return { countANA, countNum };

  // ----------------------
  // 最初の ANA を検出
  // ----------------------
  const firstANAmatch = text.match(/\bANA\b/);
  if (firstANAmatch) countANA = 1;

  // ----------------------
  // 末尾行の数字のみカウント
  // ----------------------
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(l => l);
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i];
    // 3～4桁の数字のみ、文字付きは除外
    const match = line.match(/^\d{3,4}$/);
    if (match) {
      countNum = 1;
      break;
    }
    // 数字だけの行が見つからなければスキップ
  }

  console.log("🔍 countANAandNumbers 結果:", { ANA: countANA, NUM: countNum, td });
  return { countANA, countNum };
}





// =======================
// tr 判定関数
// =======================
function isValidTr(tr, memoDivText) {
  if (memoDivText.includes("ANA")) {

    if (tr.textContent.includes("株主優待割引運賃")) {
      console.log("❌ tr スキップ: ANA かつ 株主優待割引運賃を含む", tr);
      return false;
    }

    const personalTds = tr.querySelectorAll("td.personal");
    let validPersonal = false;

    if (personalTds.length === 0) {
      console.log("❌ tr スキップ: td.personal が存在しない", tr);
    }

    personalTds.forEach(td => {
      const { countANA, countNum } = countANAandNumbers(td);

      if (countANA > 0 && countANA === countNum) {
        validPersonal = true;
      } else {
        console.log(`❌ td スキップ: ANA=${countANA}, NUM=${countNum} → 不一致`, td);
      }
    });

    if (!validPersonal) {
      console.log("❌ tr スキップ: ANA 数字数一致せず", tr);
    }
    return validPersonal;
  }

  if (memoDivText.includes("SKY")) {
    console.log("✅ SKY のみ → 条件OK", memoDivText);
    return true;
  }

  console.log("❌ tr スキップ: ANA も SKY も含まれない", memoDivText);
  return false;
}


// =======================
// 対象 tr 処理
// =======================
function handleTargetTr(tr) {
  const memoDiv = tr.querySelector("div[id^='memo_html_']");
  if (!memoDiv) {
    console.log("❌ handleTargetTr 中止: memoDiv が存在しない", tr);
    return;
  }

  // 対象をスクロールして可視化
  memoDiv.scrollIntoView({ behavior: "auto", block: "center" });
  console.log("🖱️ スクロールして対象を表示:", memoDiv.id);

  // ✅ ダブルクリックイベントを発火（エミュレート）
  const dblClickEvent = new MouseEvent("dblclick", {
    bubbles: true,
    cancelable: true,
    view: window
  });
  memoDiv.dispatchEvent(dblClickEvent);

  console.log("✅ ダブルクリックを発火しました:", memoDiv.id);
}


// =======================
// 日付時刻フィルタ関数
// =======================
function getFirstDateTimeInTr(tr) {
  const tds = tr.querySelectorAll("td");
  const dateTimeRegex = /\b\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\b/;

  for (const td of tds) {
    const match = td.textContent.trim().match(dateTimeRegex);
    if (match) {
      console.log("🔍 日付時刻検出:", match[0], "in td:", td);
      return new Date(match[0]);
    }
  }
  console.log("ℹ️ 日付時刻なし in tr:", tr);
  return null;
}

window.addEventListener("load", () => {
  console.log("🌐 ページロード完了 → tr 探索開始");

  // chrome.storage.local から設定取得
  chrome.storage.local.get(
    {
      excludeWordsAirline: [],
      excludeWordsMember: [],
      insertText: "",
      targetMode: "first", // first=最古 / last=最新
      startDateTime: "",
      endDateTime: ""
    },
    (data) => {
      const airlineWords = (data.excludeWordsAirline || []).map(w => w.toUpperCase());
      const memberWords = (data.excludeWordsMember || []).map(w => w.toUpperCase());
      memberWords.push("重複".toUpperCase());
      console.log(memberWords);
      const mode = data.targetMode || "first";

      const startDateTime = data.startDateTime ? new Date(data.startDateTime) : null;
      const endDateTime = data.endDateTime ? new Date(data.endDateTime) : null;

      console.log("ℹ️ 判定日付範囲:", startDateTime, endDateTime, "mode:", mode);

      const headerTrs = document.querySelectorAll("tr.header");
      let candidateTrs = [];

      for (const headerTr of headerTrs) {
        console.log("➡️ 処理中 headerTr:", headerTr);

        // statusTd 条件確認
        const statusTd = headerTr.querySelector("td.header[class*='status-']");
        if (!statusTd || !statusTd.textContent.includes("◆◆AIRTRIP◆◆")) {
          console.log("❌ スキップ: statusTd 条件不一致", statusTd);
          continue;
        }

        // 日付時刻判定
        const dt = getFirstDateTimeInTr(headerTr);
        if (dt) {
          if ((startDateTime && dt < startDateTime) || (endDateTime && dt > endDateTime)) {
            console.log("❌ スキップ: 日付時刻範囲外", dt);
            continue;
          }
          console.log("✅ 日付時刻範囲内:", dt);
        } else {
          if (startDateTime || endDateTime) {
            console.log("❌ スキップ: 日付時刻なしで範囲指定あり");
            continue;
          }
          console.log("ℹ️ 日付時刻なしだが範囲指定なし → 処理対象");
        }

        // header + 子 tr 判定
        const headerHit = isValidTr(headerTr, airlineWords, memberWords);
        console.log("ℹ️ headerHit 判定結果:", headerHit);

        let allChildrenHit = true;
        let hasChild = false;
        let sibling = headerTr.nextElementSibling;
        while (sibling && !sibling.classList.contains("header")) {
          hasChild = true;
          const valid = isValidTr(sibling, airlineWords, memberWords);
          if (!valid) allChildrenHit = false;
          console.log("   子 tr 判定:", sibling, "→", valid);
          sibling = sibling.nextElementSibling;
        }

        if (headerHit && (!hasChild || allChildrenHit)) {
          candidateTrs.push({ tr: headerTr, dateTime: dt || new Date(0) });
          console.log("🎯 候補 tr に追加:", headerTr, "日付時刻:", dt);
        } else {
          console.log("❌ header+子 tr 判定 NG");
        }
      }

      if (candidateTrs.length === 0) {
        console.log("❌ 条件一致する tr はありませんでした");
        return;
      }

      // 並び替え（最古/最新切り替え）
      if (mode === "last") {
        candidateTrs.sort((a, b) => b.dateTime - a.dateTime);
      } else {
        candidateTrs.sort((a, b) => a.dateTime - b.dateTime);
      }

      const targetTr = candidateTrs[0].tr;
      console.log(`🎯 ${mode === "last" ? "最新" : "最古"}の条件一致 tr を選択:`, targetTr, "日付時刻:", candidateTrs[0].dateTime);

      // 既存処理呼び出し
      handleTargetTr(targetTr);
    }
  );
});

/**
 * trの有効判定
 */
function isValidTr(tr, airlineWords = [], memberWords = []) {
  const memoDiv = tr.querySelector("div[id^='memo_html_']");
  const memoDivText = memoDiv ? memoDiv.textContent.trim().toUpperCase() : "";

  // memberWords 判定
  if (memberWords.some(word => memoDivText.includes(word))) {
    console.log("❌ tr スキップ: memoDiv に member ワード一致", tr);
    return false;
  }

  // td.personal を取得
  const personalTds = tr.querySelectorAll("td.personal");
  if (personalTds.length < 5) { // どちらにしても最低5個必要
    console.log("❌ tr スキップ: td.personal が不足", tr);
    return false;
  }

  // headerTr かどうかで index を切り替え
  const targetIndex = tr.classList.contains("header") ? 4 : 5;
  const targetTd = personalTds[targetIndex];
  const tdText = targetTd.textContent.trim().toUpperCase();

  console.log(`🔍 判定対象 td.personal[${targetIndex}] =`, tdText);

  // airlineWords 除外判定
  if (airlineWords.some(word => tdText.includes(word))) {
    console.log(`❌ tr スキップ: td.personal[${targetIndex}] に airline ワード一致`, targetTd);
    return false;
  }

  // ANA 判定
  let { countANA, countNum } = { countANA: 0, countNum: 0 };
  if (tdText.includes("ANA")) {
    const counts = countANAandNumbers(targetTd);
    countANA = counts.countANA;
    countNum = counts.countNum;

    if (countANA !== countNum) {
      console.log(`❌ td.personal[${targetIndex}] ANA/数字カウント不一致: ANA=${countANA}, NUM=${countNum}`, targetTd);
      return false;
    }

    if (tdText.includes("株主優待割引運賃")) {
      console.log(`❌ td.personal[${targetIndex}] 株主優待割引運賃含む`, targetTd);
      return false;
    }
  }

  // SKY 判定（将来拡張用）
  if (tdText.includes("SKY")) {
    console.log(`ℹ️ td.personal[${targetIndex}] SKY 判定: 現状処理なし`, targetTd);
  }

  console.log(`✅ tr 有効: td.personal[${targetIndex}] 条件クリア`, tr);
  return true;
}

