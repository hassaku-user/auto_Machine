document.addEventListener("DOMContentLoaded", () => {
  const saveButton = document.getElementById("save");
  const insertNameInput = document.getElementById("insertname");
  const targetModeRadios = document.querySelectorAll("input[name=targetMode]");
  const startInput = document.getElementById("startDateTime");
  const endInput   = document.getElementById("endDateTime");
  const memberInput = document.getElementById("memberWordsInput");

  const targetUrl = "https://opraws-prod.e-koukuuken.com/s/appli/application/search/?search%5Bshortcut%5D=&search%5Bdate%5D=none&search%5B%40date_from%5D%5BDate_Year%5D=2023&search%5B%40date_from%5D%5BDate_Month%5D=10&search%5B%40date_from%5D%5BDate_Day%5D=23&search%5B%40date_to%5D%5BDate_Year%5D=2023&search%5B%40date_to%5D%5BDate_Month%5D=10&search%5B%40date_to%5D%5BDate_Day%5D=23&search%5Bstatus%5D%5B1%5D=1&search%5Bstatus%5D%5B2%5D=2&search%5Bcondition_connect%5D=or&search%5Bconditions%5D%5B0%5D%5Bitem%5D=%E5%BE%80%E8%B7%AF%E4%BE%BF&search%5Bconditions%5D%5B0%5D%5Bvalue%5D=SKY&search%5Bconditions%5D%5B0%5D%5Bexpression%5D=%E3%81%A7%E5%A7%8B%E3%81%BE%E3%82%8B&search%5Bconditions%5D%5B1%5D%5Bitem%5D=%E5%BE%A9%E8%B7%AF%E4%BE%BF&search%5Bconditions%5D%5B1%5D%5Bvalue%5D=SKY&search%5Bconditions%5D%5B1%5D%5Bexpression%5D=%E3%81%A7%E5%A7%8B%E3%81%BE%E3%82%8B&search%5Bconditions%5D%5B2%5D%5Bitem%5D=%E5%BE%80%E8%B7%AF%E4%BE%BF&search%5Bconditions%5D%5B2%5D%5Bvalue%5D=ANA&search%5Bconditions%5D%5B2%5D%5Bexpression%5D=%E3%81%A7%E5%A7%8B%E3%81%BE%E3%82%8B&search%5Bconditions%5D%5B3%5D%5Bitem%5D=%E5%BE%A9%E8%B7%AF%E4%BE%BF&search%5Bconditions%5D%5B3%5D%5Bvalue%5D=ANA&search%5Bconditions%5D%5B3%5D%5Bexpression%5D=%E3%81%A7%E5%A7%8B%E3%81%BE%E3%82%8B&search%5Bsort%5D=reservation_date&search%5Bservice_type%5D=ALL";

  // =========================
  // 1回の get で全設定を取得
  // =========================
  chrome.storage.local.get(
    { 
      excludeWordsAirline: [], 
      excludeWordsMember: [],  // 従来は checkbox
      insertText: "", 
      targetMode: "first", 
      startDateTime: "", 
      endDateTime: "" 
    }, 
    (data) => {
      // Airline checkbox 復元
      data.excludeWordsAirline.forEach(word => {
        const checkbox = document.querySelector(`input[value="${word}"][data-scope="airline"]`);
        if (checkbox) checkbox.checked = true;
      });

      // Member をカンマ区切りテキストに復元
      memberInput.value = (data.excludeWordsMember || []).join(",");

      // 人名復元
      insertNameInput.value = data.insertText || "";

      // ラジオボタン復元
      const modeRadio = document.querySelector(`input[name=targetMode][value="${data.targetMode}"]`);
      if (modeRadio) modeRadio.checked = true;

      // 日付範囲復元
      if (data.startDateTime) startInput.value = data.startDateTime.replace(" ", "T");
      if (data.endDateTime)   endInput.value   = data.endDateTime.replace(" ", "T");

      console.log("ℹ️ 設定復元:", data);
    }
  );

  saveButton.addEventListener("click", () => {
    const checkedAll = Array.from(document.querySelectorAll("input[type=checkbox]:checked"));

    // scopeごとに分ける
    const checkedAirline = checkedAll
      .filter(cb => cb.dataset.scope === "airline")
      .map(cb => cb.value.toUpperCase());

    // Member はテキスト入力から取得
    const memberText = memberInput.value;
    const checkedMember = memberText
      .split(",")           // カンマで分割
      .map(w => w.trim())   // 前後空白削除
      .filter(w => w)       // 空文字除外
      .map(w => w.toUpperCase());

    const insertName = insertNameInput.value.trim();
    const selectedMode = document.querySelector("input[name=targetMode]:checked")?.value || "first";

    // 日付範囲
    let start = startInput.value ? startInput.value.replace("T", " ") : "";
    let end   = endInput.value   ? endInput.value.replace("T", " ") : "";

    // 保存
    chrome.storage.local.set(
      { 
        excludeWordsAirline: checkedAirline,
        excludeWordsMember: checkedMember,
        insertText: insertName, 
        targetMode: selectedMode, 
        startDateTime: start, 
        endDateTime: end 
      },
      () => {
        console.log("💾 保存しました:", { 
          excludeWordsAirline: checkedAirline,
          excludeWordsMember: checkedMember,
          insertText: insertName, 
          targetMode: selectedMode, 
          startDateTime: start, 
          endDateTime: end 
        });
      }
    );

    // 新しいタブで固定URLを開く
    chrome.tabs.create({ url: targetUrl });
  });
});
