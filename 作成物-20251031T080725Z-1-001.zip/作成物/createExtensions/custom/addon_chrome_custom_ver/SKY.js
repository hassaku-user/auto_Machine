﻿	function setFlightInformationSky() {
		var strLimitDate = '';
		var strLimitDateText = '';
		var data_callback = '';
		var dtmLimitDate2 = '';
		var strSeat = '';
		strLimitDateText = $('.timeLimit').text();
		strLimitDate = fixSkyDate(strLimitDateText);
		strLimitDate = formatDate(strLimitDate);
		
		curTable = $('#resInfo table');
		if (typeof(curTable) != 'undefined') {
				strValue = "";
				strText = "";
				
				dtmFlightDate = fixSkyDate(getCellValueInTable(curTable, 2, 1));
				if (strLimitDate != formatDate(dtmFlightDate)) {
					dtmLimitDate2 = fixSkyDate(strLimitDateText);
				} else {
					dtmLimitDate2 = new Date(dtmFlightDate.getFullYear(), dtmFlightDate.getMonth(), dtmFlightDate.getDate());
					dtmLimitDate2.setDate(dtmLimitDate2.getDate() - 1);
				}
				ticketType = getCellValueInTable(curTable, 2, 7);
				dtmFlightDate = formatDate(dtmFlightDate);
				dtmLimitDate2 = formatDate(dtmLimitDate2);
				//value=//2009/03/31/JAL/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				//text =//3月30日（月）/JAL/548/札幌(千歳)/東京(羽田)
				vntDepartureTime = getJalDepTime(getCellValueInTable(curTable, 2, 4));
				vntArrivalTime = getJalDepTime(getCellValueInTable(curTable, 2, 6));				
 				strValue = "";
                strValue += dtmFlightDate;
                strValue += "/" + "SKY";
                strValue += "/" + getCellValueInTable(curTable, 2, 2);
                strValue += "/" + fixJalAirportName(getCellValueInTable(curTable, 2, 3));
                strValue += "/" + fixJalAirportName(getCellValueInTable(curTable, 2, 5));
                strValue += "/" + vntDepartureTime.replace(':','/'); 
                strValue += "/" + vntArrivalTime.replace(':','/');
                
                //strValue += "/" + getHourString(vntDepartureTime);
                //strValue += "/" + getMinuteString(vntDepartureTime);
                //strValue += "/" + getHourString(vntArrivalTime);
                //strValue += "/" + getMinuteString(vntArrivalTime);
                strValue += "/" + getCellValueInTable(curTable, 2, 8);
                strValue += "/" + dtmLimitDate2;
                strValue += "/" + strSeat;
                strValue += "/" + ticketType;
                //2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/クラスJ

                //3月30日（月）/SKY/548/札幌(千歳)/東京(羽田)/20/55/22/30/

                strText = "";
                // strText += Application2.LastName + Application2.FirstName;
                strText +=  getCellValueInTable(curTable, 2, 1);
                strText += "/" + "SKY";
                strText += "/" + getCellValueInTable(curTable, 2, 2);
                strText += "/" + fixJalAirportName(getCellValueInTable(curTable, 2, 3));
                strText += "/" + fixJalAirportName(getCellValueInTable(curTable, 2, 5));
				
				var count_adult = 0,
					count_child = 0,
					count_infant = 0,
					psgTable = $('#resConf table'),
					rowCount = $(psgTable).find('tr').length;
				if (typeof(psgTable) != 'undefined') {
					for(var i = 2; i <= rowCount; i++){
						var name = getCellValueInTable(psgTable, i, 2)
						if (typeof(name) != 'undefined' && name != '') {
							var age = parseInt(getCellValueInTable(psgTable, i, 3));
							if (age > 11) {
								count_adult = count_adult + 1;
							} else if (age >= 3) {
								count_child = count_child + 1;
							} else if (age < 3) {
								count_infant = count_infant + 1;
							}
						}
					}
					console.log("TRAVELLER INPUT: " + count_adult + "/" + count_child + "/" + count_infant);
				}
				strValue += "/" + count_adult + "/" + count_child + "/" + count_infant;
				
				line_no = sessionStorage.getItem('line_no');
				carrier = sessionStorage.getItem('carrier');
				data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
				
				console.log(data_callback);
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				line_no = $.trim(sessionStorage.getItem('line_no'));
				setTimeout(function(){
					setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
				}, CMS_TIMEOUT_INMILISECONDS);
		}
	}
	
	function setFlightInformationSkySL() {
		var strLimitDate = '';
		var strLimitDateText = '';
		var data_callback = '';
		var dtmLimitDate2 = '';
		var strSeat = '';
		strLimitDateText = $('.limit').text();
		strLimitDate = fixSkyDate(strLimitDateText);
		strLimitDate = formatDate(strLimitDate);
		var curTable = $('form[name="incft"] table');
		if (typeof(curTable) != 'undefined') {
				strValue = "";
				strText = "";
				dtmFlightDate = fixSkyDate(getCellValueInTable(curTable, 2, 2));
				if (strLimitDate != formatDate(dtmFlightDate)) {
					dtmLimitDate2 = fixSkyDate(strLimitDateText);
				} else {
					dtmLimitDate2 = new Date(dtmFlightDate.getFullYear(), dtmFlightDate.getMonth(), dtmFlightDate.getDate());
					dtmLimitDate2.setDate(dtmLimitDate2.getDate() - 1);
				}
				ticketType = getCellValueInTable(curTable, 2, 6);
				
				dtmFlightDate = formatDate(dtmFlightDate);
				dtmLimitDate2 = formatDate(dtmLimitDate2);
				
				//value=//2009/03/31/JAL/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
				//text =//3月30日（月）/JAL/548/札幌(千歳)/東京(羽田)
				vntDepartureTime = getJalDepTime(getCellValueInTable(curTable, 2, 3));
				vntArrivalTime = getJalDepTime(getCellValueInTable(curTable, 2, 4));	
			
 				strValue = "";
                strValue += dtmFlightDate;
                strValue += "/" + "SKY";
                strValue += "/" + getCellValueInTable(curTable, 2, 5);
                strValue += "/" + fixJalAirportName(getCellValueInTable(curTable, 2, 3));
                strValue += "/" + fixJalAirportName(getCellValueInTable(curTable, 2, 4));
                strValue += "/" + vntDepartureTime.replace(':','/'); 
                strValue += "/" + vntArrivalTime.replace(':','/');
                
                //strValue += "/" + getHourString(vntDepartureTime);
                //strValue += "/" + getMinuteString(vntDepartureTime);
                //strValue += "/" + getHourString(vntArrivalTime);
                //strValue += "/" + getMinuteString(vntArrivalTime);
                strValue += "/" + getCellValueInTable(curTable, 2, 7);
                strValue += "/" + dtmLimitDate2;
                strValue += "/" + strSeat;
                strValue += "/" + ticketType;
                //2009/03/31/ANA/062/札幌(千歳)/東京(羽田)/12/30/14/05/0370/クラスJ

                //3月30日（月）/SKY/548/札幌(千歳)/東京(羽田)/20/55/22/30/

                strText = "";
                // strText += Application2.LastName + Application2.FirstName;
                strText +=  getCellValueInTable(curTable, 2, 2);
                strText += "/" + "SKY";
                strText += "/" + getCellValueInTable(curTable, 2, 5);
                strText += "/" + fixJalAirportName(getCellValueInTable(curTable, 2, 3));
                strText += "/" + fixJalAirportName(getCellValueInTable(curTable, 2, 4));
				
				var count_adult = 0,
					count_child = 0,
					count_infant = 0,
					psgTable = $('form[name="reserveForm"] table:first'),
					rowCount = $(psgTable).find('tr').length;
					rowCount = rowCount - 2; //do not include 2 last row
				if (typeof(psgTable) != 'undefined') {
					for(var i = 2; i <= rowCount; i++){
						var name = getCellValueInTable(psgTable, i, 2);
						if (typeof(name) != 'undefined' && name != '') {
							var age = parseInt(getCellValueInTable(psgTable, i, 4));
							if (age > 11) {
								count_adult = count_adult + 1;
							} else if (age >= 3) {
								count_child = count_child + 1;
							} else if (age < 3) {
								count_infant = count_infant + 1;
							}
						}
					}
					console.log("TRAVELLER INPUT: " + count_adult + "/" + count_child + "/" + count_infant);
				}
				strValue += "/" + count_adult + "/" + count_child + "/" + count_infant;
				
				line_no = sessionStorage.getItem('line_no');
				carrier = sessionStorage.getItem('carrier');
				data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
				
				console.log(data_callback);
				cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				line_no = $.trim(sessionStorage.getItem('line_no'));
				setTimeout(function(){
					setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
					console.log('_merchant_flight_info_callback:'+ data_callback );
				}, 5000);
		} else {
			console.log('Err: table flight info not found' );
		}
	}

	function setFlightConfirmSkySL(){
		var curTable = $('form[name="reserveForm"] table')[1];
		//var td1 = getCellValueInTable(curTable, 0, 0);
		//var curRow = curTable.find('tr:nth-child(0)').first();
		//for (var i = 0; i < curTable.rows.length; i++){
		//	for (var j = 0; j < curTable.rows.item(i).cells.length; j++)
		//		console.log("Cell " + j + ": " + curTable.rows.item(i).cells.item(j).innerText);
		//}
		//var rsv_no = curTable.rows.item(0).cells.item(0).innerText;
		var rsv_no1 = curTable.rows.item(0).cells.item(1).innerText.toString();
		var test = rsv_no1.split("	");
		console.log('***rsv_no1******' + test);
		rsv_no = test[1].trim();
		if (rsv_no != '') {
			var cms_app_id = sessionStorage.getItem('cms_app_id');
			var line_no = sessionStorage.getItem('line_no');
			setTimeout(function(){
					setValue(cms_app_id + '_merchant_confirm_info_callback_rsv' + line_no, rsv_no + "_" + line_no + "_" + cms_app_id);
					console.log('_merchant_confirm_info_callback_rsv ' + rsv_no );
				}, CMS_TIMEOUT_INMILISECONDS);
			
		} else {
			console.log('Err: table confirm flight info not found' );
		}
	}
	$( document ).ready(function() {
		var domain_name = document.domain;
		var loc = window.location;
		
		if(domain_name=="www.res.skymark.co.jp"){
			if(loc.toString().indexOf("res.skymark.co.jp/reserve2/vacantseatref") != -1){
				setTimeout(function(){
					getItem('application_adult_count','adult','select');
					getItem('application_child_a_count','childA','select');
					getItem('application_child_b_count','child','select');
					getItem('application_infant_count','infant','select');
				}, CMS_TIMEOUT_INMILISECONDS);
			} else if (loc.toString().indexOf("res.skymark.co.jp/reserve2/reserveConf") != -1) {
				setFlightInformationSky();
				console.log('setFlightInformationSky done');
			} else if (loc.toString().indexOf("res.skymark.co.jp/reserve2/?m=confirm") != -1) {
				setTimeout(function(){
					getItem('application_flight_certification_year','year','select');
					getItem('application_flight_certification_month','month','select');
					getItem('application_flight_certification_day','day','select');
					getItem('application_flight_certification_flight_no','flightNo','select');
					getItem('application_flight_certification_ticket_reservation_no','reserveNo','select');
					getItem('application_flight_certification_traveller_last_name_rome','form[name=sky2] input[name=secondname]','inputName');
					getItem('application_flight_certification_traveller_first_name_rome','form[name=sky2] input[name=firstname]','inputName');
				}, CMS_TIMEOUT_INMILISECONDS);
			}
		}
		
		if(domain_name=="www.res.skymark.co.jp"){
			if(loc.toString().indexOf("res.skymark.co.jp/reserve2/addFlightInfo") != -1){
				$('input:radio[name="telContact"][value="H"]').attr('checked',true);
				$('input:checkbox[name="callerSame"][value="ON"]').attr('checked',true);
				setTimeout(function(){
					getItem('application_sky_email',"mailAddressPC","name");
					getItem('application_sky_email',"mailAddressMB","name");
					getItem("application_tel1","tel","name");
					
					getItem('application_adult_list',"adult","setTravellerSky");
					getItem('application_child_a_list',"child_a","setTravellerSky");
					getItem('application_child_b_list',"child_b","setTravellerSky");
					getItem('application_infant_list',"infant","setTravellerSky");
				}, CMS_TIMEOUT_INMILISECONDS);
				console.log(getItem("application_email") + "radio2");
			} else if(loc.toString().indexOf('res.skymark.co.jp/reserve2/main') != -1) {
				setTimeout(function(){
					line_no = $.trim(sessionStorage.getItem('line_no'));
					cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
				},500);
				setTimeout(function(){
						getItem('application_flight_year' + line_no,"year", 'setConfirmSky');
	    	    		getItem('application_flight_month' + line_no,"month", 'setConfirmSky');
	    	    		getItem('application_flight_day' + line_no,"day", 'setConfirmSky');
	    	    		getItem('application_flight_no' + line_no,"flightNo", 'name');
	    	    		getItem('application_ticket_reservation_no' + line_no,"reserveNo", 'name');
	    	    		getItem('application_last_name_rome' + line_no,"secondname", 'setConfirmSky');
	    	    		getItem('application_first_name_rome' + line_no,"firstname", 'setConfirmSky');
	    	    		clearAll(cms_app_id, line_no);
	    	    	}, CMS_TIMEOUT_INMILISECONDS);
	    	    console.log('setANAConfirmation done');
			}
		}
		
		//SKY Satellite
		//console.log(loc);
		//console.log(domain_name);
		if (domain_name=="www.res.skymark.co.jp") {		
			if (loc.toString().indexOf("res.skymark.co.jp/satellite1/") != -1) {
				setTimeout(function(){
					getItem("glb_cmslink","glb_cmslink","setLoginSkySatellite");
				}, CMS_TIMEOUT_INMILISECONDS);
			} else if (loc.toString().indexOf("res.skymark.co.jp/satellite/login") != -1) {
				var carrier = sessionStorage.getItem('carrier');
				if(carrier == 'SKY-CF'){
					setTimeout(function(){		
						getItem("flight_info1","search_from_flight_info1","setSkyConfirmSatellite");
					}, CMS_TIMEOUT_INMILISECONDS);
				} else {
					setTimeout(function(){		
						getItem("flight_info1","search_from_flight_info1","setSkySatellite");
						getItem("flight_info2","search_from_flight_info2","setSkySatellite");
					}, CMS_TIMEOUT_INMILISECONDS);
				}
			} else if (loc.toString().indexOf("res.skymark.co.jp/satellite/vacantseat") != -1) {
				setTimeout(function(){		
					getItem('application_adult_count','adult','select');
					getItem('application_child_a_count','childA','select');
					getItem('application_child_b_count','child','select');
					getItem('application_infant_count','infant','select');
				}, CMS_TIMEOUT_INMILISECONDS);
			} else if (loc.toString().indexOf("res.skymark.co.jp/satellite/addflightinfo") != -1) {
				$('input:radio[name="tel_kind"][value="H"]').attr('checked',true);
				setTimeout(function(){
					getItem("application_tel1","tel","name");
					getItem('application_adult_list',"adult","setTravellerSkySatellite");
					getItem('application_child_a_list',"child_a","setTravellerSkySatellite");
					getItem('application_child_b_list',"child_b","setTravellerSkySatellite");
					getItem('application_infant_list',"infant","setTravellerSkySatellite");
					console.log(getItem('application_adult_list'));
					//$("[name='caller']").val("HINATA");
				}, CMS_TIMEOUT_INMILISECONDS);
			} else if (loc.toString().indexOf("res.skymark.co.jp/satellite/inputreserve") != -1) {
				//ここが直前
				$("[type='checkbox'").prop('checked', true);
				$('input[name="conf_check"]').attr('value',true);
			} else if (loc.toString().indexOf("res.skymark.co.jp/satellite/kessai") != -1) {
				//ここが決済画面（アラート出したい）
				var carrier = sessionStorage.getItem('carrier');
				alert("決済画面の為終了※決済は押さない");
				if(carrier == 'SKY-CF'){
					var caller = $("[name='caller']").val();
					if( typeof(caller) != 'undefined'){
						//$("[name='caller']").val('MASUDA');
						var reserveType = $("[name='reserveType']").val();//button 予約の取消=> value=DELALL
						if(reserveType == "HOLDPAY"){
							setTimeout(function(){		
								getItem("flight_info1","caller","setSkyConfirmSatellite");
								//$('form')[1].submit();
								//$("input:submit[value=確認]").trigger('click');
							}, 500);
							setTimeout(function(){		
								//$('form')[1].submit();
								$("input:submit[value=確認]").trigger('click');
							}, 2000);
						}
					} else {
						var btn_pr = $("[name='print']").val();
						if( typeof(btn_pr) != 'undefined'){
							setFlightConfirmSkySL();
							console.log('setFlightConfirmSkySL Print done');
							$("[name='print']").trigger('click');
						}
					}
					//$("[type='submit']").trigger('click');
					
				} else {
					setFlightInformationSkySL();
					console.log('setFlightInformationSkySL done');
				}
			} else if (loc.toString().indexOf("res.skymark.co.jp/satellite/main") != -1) {
				//ここで概要出したい（チケット選択）
				
				//var btdel = $("[name='deleteAll']").val();
				//if( typeof(btdel) != 'undefined'){
				//	var old_scrt = $("[name='deleteAll']").attr("onclick");
				//	old_scrt += "; window.location.hash='cancel';"
				//	$("[name='deleteAll']").attr("onclick", old_scrt);
				//	console.log('********main****** old_scrt: ' + old_scrt);
				//}
				
				var btname = $("[name='holdpay']").val();
				//if(btname =="予約決済"){
				console.log('********main****** btname: ' + btname);
				if( typeof(btname) == 'undefined'){
					//console.log('********main****** if');
					//setFlightConfirmSkySL();
					//console.log('setFlightConfirmSkySL done');
					var btn_pr = $("[name='print']").val();
					if( typeof(btn_pr) != 'undefined'){
						setFlightConfirmSkySL();
						console.log('setFlightConfirmSkySL main Print done');
						$("[name='print']").trigger('click');
					}
				} else {
					console.log('********main****** else');
					$("[name='holdpay']").trigger('click');
				}
				
			} else if (loc.toString().indexOf("res.skymark.co.jp/satellite/reserve_sale") != -1) {
				var caller = $("[name='caller']").val();
				if( typeof(caller) != 'undefined'){
					var reserveType = $("[name='reserveType']").val();//button 予約の取消=> value=DELALL
					if(reserveType == "HOLDPAY"){
						setTimeout(function(){		
							getItem("flight_info1","caller","setSkyConfirmSatellite");
							//$('form')[1].submit();
							//$("input:submit[value=確認]").trigger('click');
						}, CMS_TIMEOUT_INMILISECONDS);
					}
				}
				var reserveHold = $("[name='reserveHold']").val();
				if( typeof(reserveHold) != 'undefined'){
					$("[name='reserveHold']").trigger('click');
				}
			}
		} else {
			if (loc.toString().indexOf("opraws-dev.e-koukuuken.com/testth/sky-booking.html") != -1) {
				setFlightInformationSkySL();
				console.log('setFlightInformationSkySL done');
			}
		}
	});