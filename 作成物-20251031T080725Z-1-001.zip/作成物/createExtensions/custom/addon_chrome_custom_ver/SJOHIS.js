/*
 * SJO (HIS) airport
 * Check auto submit
 * Check operator edit after auto fill
 * Check affection to other pages in same domain
 * Clear all value after set in form(click button)
 * Auther: ThanhNV 20220221
 * */
function setFlightInformation_SJO() {
	//予約番号
	//ref-number
	var reserveNo = "";
	var div = $(".txt-number .font-big").text();
	if (div != null) {
		reserveNo = $.trim(div);
	}

	//予約期限
	dtmLimitDate = new Date();
	dtmLimitDate.setDate(dtmLimitDate.getDate() + 1);
	dtmLimitDate = formatDate(dtmLimitDate);

	var strLimitDate = '';
	var strLimitDateText = '';
	var data_callback = '';
	var data_callback1 = '';

	curTable = $('.tab').eq(0);
	if ( typeof (curTable) != 'undefined' && curTable.length >= 1) {

		var flightDate = DATE_MIN_VAL;
		var flightNo = "";
		var depAirport = "";
		var arrAirport = "";
		var depHour = 0;
		var depMinute = 0;
		var arrHour = 0;
		var arrMinute = 0;
		var seat = "";
		var ticketType = "";

		var i = 0;
		var s = "";
		var result = "";

		    //one
			//チケット IJ621
			s = getCellValueInTable(curTable, 2, 1);
			flightNo = s.match(/[0-9]{3}/);
			
			dep_info = getCellValueInTable(curTable, 2, 2);
			des_info = getCellValueInTable(curTable, 2, 3);
			dep_date =  dep_info.match("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})");
			flightDate = dep_date[0].replace(/-/g,"/");
			dep_time =  dep_info.match("([0-9]{1,2}):([0-9]{1,2})");
			
			des_date  =  des_info.match("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})");
			des_time =  des_info.match("([0-9]{1,2}):([0-9]{1,2})");
			
			let tmp =  dep_time[0].split(":");
			depHour = tmp[0];
			depMinute = tmp[1];
			
			tmp =  des_time[0].split(":");
			arrHour = tmp[0];
			arrMinute = tmp[1];
			
			tmp = dep_info.replace(/(\s|\d|-|:)/gm,"");
			depAirport = tmp.substring(5, 11);
			console.log(depAirport + '**************' + tmp);
			tmp = des_info.replace(/(\s|\d|-|:)/gm,"");
			arrAirport = tmp.substring(5, 11);
			console.log(arrAirport + '**************' + tmp);
			let count_line = 1;
			var cnt_r = curTable.find('tr').length;
			
            if (cnt_r > 2) {
				count_line = 2;
				//two
				//チケット IJ622
				s = getCellValueInTable(curTable, 3, 1);
				flightNo2 = s.match(/[0-9]{3}/);
				
				dep_info = getCellValueInTable(curTable, 3, 2);
				des_info = getCellValueInTable(curTable, 3, 3);
				
				dep_date2  =  dep_info.match("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})");
				flightDate2 = dep_date2[0].replace(/-/g,"/");
				dep_time2 =  dep_info.match("([0-9]{1,2}):([0-9]{1,2})");
				
				des_date2  =  des_info.match("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})");
				des_time2 =  des_info.match("([0-9]{1,2}):([0-9]{1,2})");
				
				tmp = dep_info.replace(/(\s|\d|-|:)/gm,"");
				depAirport2 = tmp.substring(5, 11);
				console.log(depAirport2 + '**************' + tmp);
				tmp = des_info.replace(/(\s|\d|-|:)/gm,"");
				arrAirport2 = tmp.substring(5, 11);
				console.log(arrAirport2 + '**************' + tmp);
				
				tmp =  dep_time2[0].split(":");
				depHour2 = tmp[0];
				depMinute2 = tmp[1];
				
				tmp =  des_time2[0].split(":");
				arrHour2 = tmp[0];
				arrMinute2 = tmp[1];
				
			}
			//2009/03/31/SJO/622/札幌(千歳)/東京(羽田)/12/30/14/05/0370/2009/03/31/プレミアム
			strValue = "";
			strValue += flightDate.toString();
			strValue += "/" + "SJO" + "/" + flightNo;
			strValue += "/" + fixJalAirportName(depAirport);
			strValue += "/" + fixJalAirportName(arrAirport);
			strValue += "/" + depHour.toString();
			strValue += "/" + depMinute.toString();
			strValue += "/" + arrHour.toString();
			strValue += "/" + arrMinute.toString();
			strValue += "/";// + reserveNo.toString();
			strValue += "/";// + dtmLimitDate.toString();
			strValue += "/";// + seat;
			strValue += "/";// + ticketType;
			strValue += "/" + count_line.toString();// + count_line;
			
			let strText = "";
			strText += count_line.toString();
			strText += "/" +dep_date[0].toString();
			strText += "/" + "SJO" + "/" + flightNo;
			strText += "/" + fixJalAirportName(depAirport);
			strText += "/" + fixJalAirportName(arrAirport);
			
			if(count_line == 2){
				strValue += ";" + flightDate2.toString();
				strValue += "/" + "SJO" + "/" + flightNo2;
				strValue += "/" + fixJalAirportName(depAirport2);
				strValue += "/" + fixJalAirportName(arrAirport2);
				strValue += "/" + depHour2.toString();
				strValue += "/" + depMinute2.toString();
				strValue += "/" + arrHour2.toString();
				strValue += "/" + arrMinute2.toString();
				strValue += "/";// + reserveNo.toString();
				strValue += "/";// + dtmLimitDate.toString();
				strValue += "/";// + seat;
				strValue += "/";// + ticketType;
				
				strText += ";" + dep_date2[0].toString();
				strText += "/" + "SJO" + "/" + flightNo2;
				strText += "/" + fixJalAirportName(depAirport2);
				strText += "/" + fixJalAirportName(arrAirport2);
			}
			
			line_no = sessionStorage.getItem('line_no');
			carrier = sessionStorage.getItem('carrier');
			data_callback = strValue + '|' + strText + '|' + line_no + '|' + carrier;
			
			console.log(data_callback);
			cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			
			setTimeout(function(){
				
				console.log('_merchant_flight_info_callback' + line_no);
				setValue(cms_app_id +'_merchant_flight_info_callback' + line_no, data_callback);
				if(count_line == 2){
					line_no = line_no + '_98';// round trip start by line
				}
				setValue('app_id_SJO_lineno', cms_app_id + "-" + line_no);
			}, CMS_TIMEOUT_INMILISECONDS);
			
	}
}


function writePerson(array_index)
{
    if(array_index)
    {
        n = array_index.length;
        for (i=0; i<=n; i++) {
            writeItem('application_traveller_list_' + array_index[i] + '_age');
            writeItem('application_traveller_list_' + array_index[i] + '_sex');
            writeItem('application_traveller_list_' + array_index[i] + '_birthday');
            writeItem('application_traveller_list_' + array_index[i] + '_first_name_rome');
            writeItem('application_traveller_list_' + array_index[i] + '_last_name_rome');
		}
    }
}

function writePersonInfant(){
    for (i=0; i<=1; i++)
    {
        writeItem('application_infant_list_' + i.toString() + '_age');
        writeItem('application_infant_list_' + i.toString() + '_sex');
        writeItem('application_infant_list_' + i.toString() + '_birthday');
        writeItem('application_infant_list_' + i.toString() + '_first_name_rome');
        writeItem('application_infant_list_' + i.toString() + '_last_name_rome');
    }
}

function writeItem(key){
  temp = $.trim(sessionStorage.getItem('cms_app_id')) + "_";
  key = temp + key;
  xdLocalStorage.getItem(key, function(data) {
    //console.log(data.value);
    orginalKey = key.replace(temp, '');
    if (!!data.value) {
        $("body").append("<input type='hidden' id='"+orginalKey+"' name='"+orginalKey+"' value='" + data.value + "'>");
    }
  });
}

$(document).ready(function() {
	var domain_name = document.domain;
	var loc = window.location;
    /*************
    @ThanhNV 20220221
    */
	var domain_name = document.domain;
	var loc = window.location;
	if (domain_name == "jp.ch.com") {
		//var value = $.cookie("hashstr");
		patt = new RegExp(/https:\/\/jp.ch.com\/Flights\/PassengerInfo/);
		res = patt.test(loc);
		if (res) { //input Passenger
			var body_str = $("body").text();
			var timeout = 60000;
			//if (body_str.indexOf("ご利用が多いお客様情報") > -1){//search sjo his
			if (body_str.indexOf("下記「連絡者」情報として登録します") > -1){//search sjo his
				timeout = 1000;
				console.log("*****timeout if*****" + timeout);
			} else if (body_str.indexOf("ご利用が多いお客様情報") > -1){//search sjo his
				timeout = 60000;
				console.log("*****timeout else if*****" + timeout);
			}
			//<div id="u-loading-layer">
			var loading = $("#u-loading-layer");
			if(loading == undefined){
				timeout = 5000;
				console.log("*****timeout loading*****" + timeout);
			}
			console.log("*****timeout*****" + timeout);
			setTimeout(function() {	
				//getItem('application_tel1', "LinkManMobile", 'data-name', 99);
				
				//getItem('application_traveller_list_0_birthday', "Birthday" , "data-name", 0);
				person_cnt = $.trim(sessionStorage.getItem('person_cnt'));
				name_rome = $.trim(sessionStorage.getItem('name_rome'));
				tmp = person_cnt.split('-');
				traveller_cnt = parseInt(tmp[0]);
				infant_cnt = parseInt(tmp[1]);
				person = traveller_cnt + infant_cnt;
				console.log("*****person*****" + person + "*****traveller_cnt*****" + traveller_cnt +"****infant_cnt*****"+infant_cnt);
				//for (i = 0; i < person; i++) {
				//	$(".c-list-name").eq(i).trigger('click');
				//}
				//$(".c-setLink input:checkbox").attr('checked', false);
				
				
				for (i = 0; i < traveller_cnt; i++) {
					//$(".passenger-item[data-index='" + i + "']").trigger('click');
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='FamilyName']").trigger('click');
					getItem('application_traveller_list_' + i.toString() + '_last_name_rome', "FamilyName", "data-name", i);
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='FamilyName']").focus();
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='PersonalName']").trigger('click');
					getItem('application_traveller_list_' + i.toString() + '_first_name_rome', "PersonalName" , "data-name", i);
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='PersonalName']").focus();
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Birthday']").trigger('click');
					getItem('application_traveller_list_' + i.toString() + '_birthday', "Birthday" , "data-name", i);
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Birthday']").change();
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Mobile']").trigger('click');
					getItem('application_tel1', "Mobile", 'data-name', i);
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Mobile']").focus();
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Gender']").trigger('click');
					getItem('application_traveller_list_' + i.toString() + '_sex', "Gender", 'data-name', i);
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Gender']").focus();
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Nationality']").trigger('click');
					getItem('application_traveller_list_' + i.toString() + '_national', "Nationality", 'data-name', i);
					//$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Nationality']").focus();
				}
				
				
				if(infant_cnt > 0){
					let j =0;
					for (let i = traveller_cnt; i < person; i++) {
						$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='FamilyName']").trigger('click');
						getItem('application_infant_list_' + j.toString() + '_last_name_rome', "FamilyName", "data-name", i);
						//$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='FamilyName']").focus();
						$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='PersonalName']").trigger('click');
						getItem('application_infant_list_' + j.toString() + '_first_name_rome', "PersonalName" , "data-name", i);
						//$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='PersonalName']").focus();
						$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='Birthday']").trigger('click');
						getItem('application_infant_list_' + j.toString() + '_birthday', "Birthday" , "data-name", i);
						$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='Birthday']").change();
						$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='Mobile']").trigger('click');
						getItem('application_tel1', "Mobile", 'data-name', i);
						//$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='Mobile']").focus();
						$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='Gender']").trigger('click');
						getItem('application_infant_list_' + j.toString() + '_sex', "Gender", 'data-name', i);
						//$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='Gender']").focus();
						$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='Nationality']").trigger('click');
						getItem('application_infant_list_' + j.toString() + '_national', "Nationality", 'data-name', i);
						//$(".passenger-item[data-index='"+ j +"'] .passenger-form .inp-item input[data-name='Nationality']").focus();
						j++;
					}
				}
				//getItem('application_tel1', "LinkManMobile", 'data-name', 99);
				//var f_name = $(".passenger-item[data-index='0'] .passenger-form .inp-item input[data-name='FamilyName']").val();
				//var l_name = $(".passenger-item[data-index='0'] .passenger-form .inp-item input[data-name='PersonalName']").val();
				//getItem('application_tel1', "LinkManMobile", 'data-name', 99);
				//$("[data-name='LinkManName']").val(f_name+''+l_name);
				//$("[data-name='LinkManName']").focus();
				
				//for (i = 0; i <= traveller_cnt; i++) {
				//	getItem('application_traveller_list_' + i.toString() + '_last_name_rome', "FamilyName", "data-name", i);
				//	$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='FamilyName']").focus();
				//	getItem('application_traveller_list_' + i.toString() + '_first_name_rome', "PersonalName" , "data-name", i);
				//	$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='PersonalName']").focus();
				//	getItem('application_traveller_list_' + i.toString() + '_birthday', "Birthday" , "data-name", i);
				//	$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Birthday']").focus();
				//	getItem('application_tel1', "Mobile", 'data-name', i);
				//	$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Mobile']").focus();
				//	getItem('application_traveller_list_' + i.toString() + '_sex', "Gender", 'data-name', i);
				//	$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Gender']").focus();
				//	getItem('application_traveller_list_' + i.toString() + '_sex', "Nationality", 'data-name', i);
				//	$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Nationality']").focus();
				//}
				
				//$("[data-name='LinkManName']").val(name_rome);
				//$("[data-name='LinkManName']").focus();
				//getItem('application_tel1', "LinkManMobile", 'data-name', 99);
				//$("[data-name='LinkManMobile']").val('0311111111');
				//$("[data-name='LinkManMobile']").blur();
				//$("[data-name='LinkManMobile']").change();
				////$("[data-name='LinkManMobile']").trigger('click');
				//$("[data-name='LinkManMobile']").focus();
				//$("[data-name='LinkManMobile']").trigger('keyup');
				//$("[data-name='LinkManMobile']").keyup();
				//
				//$("[data-name='LinkManEmail']").focus();
				
				
				
				//getItem('application_traveller_list_0_last_name_rome', "LinkManName", 'data-name', 99);
				//$("[data-name='LinkManName']").focus();
				
				//$(".c-list-name").eq(0).trigger('click');
				
				//$(".c-setLink input:checkbox").attr('checked', false);
				//getItem('application_tel1', "LinkManMobile", 'data-name', 99);
				//getItem('application_tel1', "order-btn .order-next", 'pnr_jjp_btn');
				
				//$('.order-btn.order-next').trigger('click');
				//
				//for (i = 0; i < person; i++) {
				//	$(".passenger-item[data-index='"+ i +"'] .passenger-form .inp-item input[data-name='Birthday']").trigger('click');
				//}
				
			}, timeout);
		}
		
		patt = new RegExp(/https:\/\/jp.ch.com\/btg/);
		res = patt.test(loc);
		if (res) { //Search Flight
			setTimeout(function() {	
			
				hash = window.location.hash;
				//$.cookie("hashstr", hash, { expires : 1 });//{ expires : 1 days }
				if(hash != ""){
					var fligh_info = hash.split('_');
					console.log("*****fligh_info*****" + fligh_info);
				}
				var body_str = $("body").text();
				if (body_str.indexOf("往復") > -1){//search sjo his
					var line_no = parseInt(fligh_info[1]);
					line_no = line_no + 1;
					if(fligh_info[3] != ''){
						$("#RETURN_TIME").val(fligh_info[3]);
					} else {
						$("#noReturn").attr('checked', true);
					}
					getItem("flight_info" + line_no,"search_from_flight_info","searchSJOHIS");
					$('#btnSearch').trigger('click');
				}
				
			}, 5000);
		
		}
		
		//https://jp.ch.com/order/order-confirmation/?key=dd02eaf1cbd34d2e95e25746a4edac10
		patt = new RegExp(/https:\/\/jp.ch.com\/order\/order-confirmation/);
		res = patt.test(loc);
		if (res) { //confirm passenger
			cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
			line_no = $.trim(sessionStorage.getItem('line_no'));
			//window.open('https://global-bpayment.ch.com/jp/flights/choose-channel/998f8d31-8916-41fa-b6c7-8bfacb831473' + cms_app_id + '_' + line_no);
			setTimeout(function() {
				setFlightInformation_SJO();
		    	console.log('************setFlightInformation_SJO done***************');
			}, 2000);
			
		}
		//https://jp.ch.com/order/order-confirmation/?key=dd02eaf1cbd34d2e95e25746a4edac10
		//patt = new RegExp(/https:\/\/jp.ch.com\/order\/GetPayGetTradeId/);
		//res = patt.test(loc);
		//if (res) { //get payment link
		//	cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
		//	line_no = $.trim(sessionStorage.getItem('line_no'));
		//	var href_next = $(".myDialogBtn").attr("href") + cms_app_id + '_' + line_no;
		//	$(".myDialogBtn").attr("href" , href_next);
		//	console.log('***********href_next*********' + href_next);
		//}
		
		
	
	}
	if(domain_name =="passport.ch.com"){
			
		var	hash_id = window.location.hash;
		//$.cookie("hash_id", hash_id, { expires : 1 }); //expires 1 days
		//window.open('https://global-bpayment.ch.com/flights/Fail?#3670762_0_SJO_2022-05-27_3-1_YAMADAMINA');
		//window.open('https://global-bpayment.ch.com/jp/flights/Fail/998f8d31-8916-41fa-b6c7-8bfacb831473?code=10' + hash_id);
		window.location.href = "https://jp.ch.com/btg/" + hash_id;
	}
	
	if(domain_name =="global-bpayment.ch.com"){
		
		patt = new RegExp(/https:\/\/global-bpayment.ch.com\/jp\/flights\/choose-channel/);
		res = patt.test(loc);
		if (res) { //get Resevertion
			//var hash_id = $.cookie("hash_id");
			//var hash_id = sessionStorage.getItem('hash_id');//#appid_lineno
			//alert('******get hash_id***********' + hash_id);
			//https://global-bpayment.ch.com/jp/flights/choose-channel/998f8d31-8916-41fa-b6c7-8bfacb831473
			setTimeout(function() {	
				var reserveNo = $('.w-main .col-orange').text();
				getItem("app_id_SJO_lineno","appId_cms","appId_cms",reserveNo);
				//getItem("app_id_SJO_lineno","appId_cms","");
				//var appid_lineno = $('#appId_cms').val();
				//tmp = appid_lineno.split("-");
				//cms_app_id = tmp[0];
				//line_no = tmp[1].split('_');
				//console.log( '******appid_lineno*********' + appid_lineno + '*********reserveNo*********' + reserveNo);
				////step01
				//reserveNo = reserveNo + "-" + tmp[1];
				//setValue(cms_app_id +'_sjo_callback_reserveNo' + line_no[0], reserveNo);
			}, 500);
			
		}
		
		patt = new RegExp(/https:\/\/global-bpayment.ch.com\/jp\/flights\/Fail/);
		res = patt.test(loc);
		if (res) {
			var	hash_id = window.location.hash;
			if(hash_id){
				$.cookie("hash_id", hash_id, { expires : 10 }); //expires 10 days
				//sessionStorage.setItem('hash_id', hash_id);//#appid_lineno
				console.log('*********set hash_id*********' + hash_id);
				 document.title = "Prepare Payment";
				$(".wp").empty();
				$(".wp").append('<a> Please do not close this page until complete booking and click 航空券注文確認-春秋公式サイト page to booking complete and close this page after that </a>');
			}
			
			setTimeout(function() {	
				var reserveNo = 'TEST';
				
				getItem("app_id_SJO_lineno","appId_cms","appId_cms",reserveNo);
				
			}, 500);
			
		}
	}
	
}); 
//https://bpayment.ch.com/jp/flights/choose-channel/1b53a0dd-9e71-4fee-9b96-8ec5cd78510e
//window.addEventListener('load', checkJSLoaded);
//function checkJSLoaded() {
//    console.log('**********page loading****************');
//	patt = new RegExp(/https:\/\/jp.ch.com\/order\/GetPayGetTradeId/);
//	res = patt.test(loc);
//	console.log(loc+'***********res*********' + res);
//	if (res) { //get payment link
//		cms_app_id = $.trim(sessionStorage.getItem('cms_app_id'));
//		line_no = $.trim(sessionStorage.getItem('line_no'));
//		var href_next = $(".myDialogBtn").attr("href") + cms_app_id + '_' + line_no;
//		$(".myDialogBtn").attr("href" , href_next);
//		console.log('***********href_next*********' + href_next);
//	}
//}
