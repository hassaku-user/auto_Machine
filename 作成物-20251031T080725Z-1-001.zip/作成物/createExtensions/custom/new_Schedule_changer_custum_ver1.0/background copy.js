
let idList = [];
let processList = [];
let currentIndex = 0;

// ベースURL
//const base_EK_URL = "＊＊＊＊＊"; // EK用ベースURL
//const base_AG_URL = "＊＊＊＊＊"; // AG用ベースURL
const base_EK_URL = "https://opraws-prod.e-koukuuken.com/s/appli/application/edit/"; // EK用ベースURL
const base_AG_URL = "https://opraws-prod.tabicapital.net/s/appli/application/edit/"; // AG用ベースURL

// --------------------------
// 進捗更新
// --------------------------
function updateProgress() {
    const percent = idList.length > 0 ? Math.round((currentIndex / idList.length) * 100) : 0;
    chrome.storage.local.set({
        currentIndex,
        statusText: `実行中: ${currentIndex} / ${idList.length}`,
        percent
    });
}

// --------------------------
// ボタンクリック処理（1件だけ）
// --------------------------
async function runProcessSequentially(tabId, procItem) {
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId, allFrames: true },
            world: "MAIN",
            func: (procItem) => {
                function getButtonIndex(procItem) {
                    const map = { "区間1":0, "区間2":1, "区間3":2, "区間4":3 };
                    return map[procItem] ?? -1;
                }
                const idx = getButtonIndex(procItem);
                if (idx === -1) return { ok:false, message:"該当なし", procItem };
                
                const buttons = document.querySelectorAll("input.check_button[value='予約確認']");
                if (buttons && buttons[idx]) {
                    buttons[idx].click();
                    return new Promise(resolve => {
                        window.addEventListener("load", () => resolve({ ok:true, clickedIndex: idx, procItem }), { once:true });
                        setTimeout(() => resolve({ ok:true, clickedIndex: idx, procItem }), 1500);
                    });
                } else {
                    return { ok:false, message:"ボタンが見つからない", procItem };
                }
            },
            args: [procItem]
        });

        console.log("クリック結果:", results);
    } catch(err) {
        console.error("executeScriptエラー:", err);
    }

    await new Promise(resolve => setTimeout(resolve, 1500));
}

// --------------------------
// タブを開く（ページロード完了待機）
// --------------------------
function openOrUpdateTab(targetURL) {
    return new Promise(resolve => {
        chrome.tabs.create({ url: targetURL, active: true }, tab => {
            const newTabId = tab.id;
            chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
                if (tabId === newTabId && changeInfo.status === "complete") {
                    chrome.tabs.onUpdated.removeListener(listener);
                    resolve(newTabId);
                }
            });
        });
    });
}

// --------------------------
// リセット
// --------------------------
function resetProgress() {
    idList = [];
    processList = [];
    currentIndex = 0;
    chrome.storage.local.set({
        idInput: "",
        processInput: "",
        currentIndex: 0,
        statusText: "未実行",
        percent: 0
    });
}

// --------------------------
// 次のID処理（1IDに1つの処理項目だけ）
// --------------------------
async function proceedNext() {
    chrome.storage.local.get(["idInput", "processInput", "currentIndex"], async ({ idInput, processInput, currentIndex: savedIndex }) => {
        if (!idInput || !processInput) return;

        if (idList.length === 0) {
            idList = idInput.split(/\r?\n|\u2028|\u2029/).map(s => s.trim()).filter(Boolean);
        }
        if (processList.length === 0) {
            processList = processInput.split(/\r?\n|\u2028|\u2029/).map(s => s.trim()).filter(Boolean);
        }

        if (idList.length !== processList.length) {
            chrome.notifications.create({
                type:"basic",
                iconUrl:"icon.png",
                title:"エラー",
                message:`IDリストと処理項目リストの件数が一致していません\nID:${idList.length}, 処理:${processList.length}`
            });
            chrome.storage.local.set({ statusText:"件数不一致で中断", percent:0 });
            return;
        }

        if (savedIndex !== undefined) currentIndex = savedIndex;
        if (currentIndex >= idList.length) {
            chrome.storage.local.set({ statusText:`実行完了`, percent:100 });
            chrome.notifications.create({ type:"basic", iconUrl:"icon.png", title:"完了", message:"全てのIDを処理しました" });
            return;
        }

        const rawID = idList[currentIndex];
        const procItem = processList[currentIndex];

        let targetURL = "";
        if (rawID.startsWith("EK")) targetURL = base_EK_URL + rawID.replace(/^EK0/, "");
        else if (rawID.startsWith("AG")) targetURL = base_AG_URL + rawID.replace(/^AG0/, "");
        else {
            console.warn("未対応IDタイプ:", rawID);
            currentIndex++;
            updateProgress();
            return;
        }

        currentIndex++;
        updateProgress();

        const tabId = await openOrUpdateTab(targetURL);
        await runProcessSequentially(tabId, procItem);
    });
}

// --------------------------
// checkMail 処理
// --------------------------
async function runCheckMailForID(rawID, processItem) {
    if (!rawID || !processItem) return;

    // 対象URLを作成
    let targetURL = "";
    if (rawID.startsWith("EK")) targetURL = base_EK_URL + rawID.replace(/^EK0/, "");
    else if (rawID.startsWith("AG")) targetURL = base_AG_URL + rawID.replace(/^AG0/, "");
    else return;

    // タブを開く
    const tabId = await openOrUpdateTab(targetURL);

    // tableからデータ取得
    const results = await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        world: "MAIN",
        func: () => {
            const tdElements = document.querySelectorAll("table.appli-basic td");
            return Array.from(tdElements).map(td =>
                td.innerHTML.split(/<br\s*\/?>/i).map(s => s.trim()).filter(Boolean)
            );
        }
    });

    const tdArray = results[0].result;

    const bulletPartsArray = tdArray.flatMap(tdLines =>
        tdLines
            .map(line => line.replace(/[\n\t]/g,'').trim())
            .filter(line => /^\s*・\d{4}-\d{2}-\d{2}/.test(line))
            .map(line => line.split("/").map(s => s.trim()))
    );

    // textarea#memo_text に処理項目対応行を追加
    await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        world: "MAIN",
        func: (bulletPartsArray, processItem) => {
            const memoText = document.getElementById("memo_text");
            if (!memoText) return;

            const indexMap = { "区間1": 0, "区間2": 1, "区間3": 2, "区間4": 3 };
            const idx = indexMap[processItem];
            if (idx === undefined || !bulletPartsArray[idx]) return;

            console.log(bulletPartsArray[idx]);
            const checkdate = bulletPartsArray[idx];
            let newLine = `${processItem}元  ${checkdate[1]} (${checkdate[2]})`;
            newLine = newLine.replace(/\s+/g, "\n") + "\n";

            memoText.value = newLine + memoText.value;
        },
        args: [bulletPartsArray, processItem]
    });

    // ----------------------------
    // 進捗更新と currentIndex インクリメント
    // ----------------------------
    chrome.storage.local.get(["currentIndex", "idInput"], ({ currentIndex, idInput }) => {
        const idList = idInput ? idInput.split(/\r?\n|\u2028|\u2029/).map(s => s.trim()).filter(Boolean) : [];
        if (!idList.length) return;

        currentIndex = (currentIndex ?? 0) + 1; // 1件進める
        const percent = Math.round((currentIndex / idList.length) * 100);

        let statusText = `checkMail: ${currentIndex} / ${idList.length} 件処理`;

        // 全件完了チェック
        if (currentIndex >= idList.length) {
            statusText = "checkMail: 全件処理完了";
        }

        chrome.storage.local.set({
            currentIndex,
            statusText,
            percent
        });
    });
}



// --------------------------
// メッセージ受信
// --------------------------
chrome.runtime.onMessage.addListener((message)=>{
    console.log("受信メッセージ:", message); // ← ここで内容を確認
    if(message.action==="next") proceedNext();
    else if(message.action==="reset") resetProgress();
    else if(message.action==="checkMail") {
        if(!message.rawID) return;
        runCheckMailForID(message.rawID, message.procItem);
    }
});
