export const base_EK_URL = "https://opraws-prod.e-koukuuken.com/s/appli/application/edit/"; // EK用ベースURL
export const EK_sendMail_URL = "https://opraws-prod.e-koukuuken.com/s/appli/application/edit2/"; //EK用メール送信画面URL
export const EK_checkMail_URL = "https://opraws-prod.e-koukuuken.com/s/appli/application/listMail/"; //EK用メール送信履歴確認URL

export const base_AG_URL = "https://opraws-prod.tabicapital.net/s/appli/application/edit/"; // AG用ベースURL
export const AG_sendMail_URL = "https://opraws-prod.tabicapital.net/s/appli/application/edit2/";//AG用メール送信画面URL
export const AG_checkMail_URL = "https://opraws-prod.tabicapital.net/s/appli/application/listMail/";//AG用メール送信履歴確認URL

export const base_AX_URL = "https://amex.tabicapital.net/s/appli/application/edit/";
export const AX_sendMail_URL = "https://amex.tabicapital.net/s/appli/application/edit2/";
export const AX_checkMail_URL = "https://amex.tabicapital.net/s/appli/application/listMail/";

export const EK_mailtext_URL = "https://opraws-prod.e-koukuuken.com/s/appli/application/mail/mail/"; // ← 実際のURLに置き換えてください
export const AG_mailtext_URL = "https://opraws-prod.tabicapital.net/s/appli/application/mail/mail/"; // ← 実際のURLに置き換えてください
export const AX_mailtext_URL = "https://opraws-prod.tabicapital.net/s/appli/application/mail/mail/"; // ← 実際のURLに置き換えてください


export const subjectInsStr = "Subject:【※重要】スケジュール変更のお知らせ【NAVITIMEトラベル】";

